// npm run use -- <book>   → choose which book npm run build / check / serve work on (writes ar-book.config.json)
// npm run use             → shows the books you have
import fs from 'node:fs';
import { rel, args, exists, config } from './lib/common.mjs';

const A = args();
const id = A._ && A._[0];
const books = fs.readdirSync(rel('books')).filter((f) => exists(rel('books', f, 'book.json')));
const now = config().book;
if (!id) {
  console.log('\n  いまある絵本（★ がいま作る絵本）');
  for (const b of books) console.log(`   ${b === now ? '★' : '　'} ${b}`);
  console.log('\n  切りかえるとき: npm run use -- 絵本の名前\n');
  process.exit(0);
}
if (!books.includes(id)) { console.error(`\n  books/${id} が見つかりません。いまある絵本: ${books.join(', ')}\n`); process.exit(1); }
fs.writeFileSync(rel('ar-book.config.json'), JSON.stringify({ book: id }, null, 2) + '\n');
console.log(`\n  ✅ これからは「${id}」を作ります（npm run build → publish/${id}/）\n`);
