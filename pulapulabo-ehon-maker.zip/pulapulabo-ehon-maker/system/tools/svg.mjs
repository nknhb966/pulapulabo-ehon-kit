// npm run svg                    → the book's pictures as SVG, to draw over in a vector app (Illustrator, Inkscape,
//                                  Affinity Designer, Figma …) (guide/09). out/<book>_svg/ and out/<book>_svg.zip
//   はじめに読んでね.txt   what each file is, and how to draw and put them back
//   _ガイド.svg・.png      the 5 rows for 奥行き and the story box
//   p1/_下絵.png           the page as printed, to place under the drawing (locked)
//   p1/_background.svg, p1/cat.svg, p1/cat@happy.svg …   every picture, 1600 × 1200 (a PNG picture stays PNG)
//   cover.svg, cast/…, items/…
// Put the drawn pictures back with: npm run put-svg -- <folder or ZIP>   (the same tool as put-png)
//
// npm run svg -- --book <id>       another book
// npm run svg -- --page p1,p3      only some pages
import { args, config, loadBook } from './lib/common.mjs';
import { makeShitae } from './lib/shitae.mjs';

const A = args();
const B = loadBook(A.book || config().book);
const only = typeof A.page === 'string' ? A.page.split(',').map((s) => s.trim()).filter(Boolean) : null;
if (only) for (const id of only) if (!B.pages.some((p) => p.id === id)) { console.error(`\n  ページ「${id}」がありません。ページ: ${B.pages.map((p) => p.id).join(', ')}\n`); process.exit(1); }
await makeShitae(B, { kind: 'svg', only });
