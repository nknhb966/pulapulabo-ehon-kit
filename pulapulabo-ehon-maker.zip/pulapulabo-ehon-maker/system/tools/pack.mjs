// npm run pack                  → builds the book, then makes two ZIP files in out/:
//   out/<book>_github.zip   what goes to GitHub (the contents of publish/<book>/, files at the top of the ZIP)
//                           — out/<book>_web.zip when the book is put somewhere else (book.json "url", not github.io)
//   out/<book>_source.zip   the book's own files (books/<book>/) to keep, for making changes later
//   out/<book>_preview.html the camera-less preview in ONE file (opens anywhere, also shown in a chat)
// npm run pack -- --book <id>   → another book
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { ROOT, rel, sys, args, config, publishDir, mkdirp, exists, loadBook } from './lib/common.mjs';
import { makeZip, filesOf } from './lib/zip.mjs';
import { oneFilePreview } from './lib/onefile.mjs';
import { hostOf } from './lib/cover.mjs';

const A = args();
const id = A.book || config().book;
if (!id) { console.error('どの絵本か決まっていません。npm run pack -- --book 名前'); process.exit(1); }

const r = spawnSync(process.execPath, [sys('tools', 'build.mjs'), '--book', id], { stdio: 'inherit', cwd: ROOT });
if (r.status !== 0) process.exit(r.status || 1);
const pub = publishDir(id);
if (!exists(path.join(pub, 'index.html'))) { console.error(`publish/${id}/index.html がありません。`); process.exit(1); }

mkdirp(rel('out'));
const web = hostOf(loadBook(id).book) === 'web';
const gh = rel('out', `${id}_${web ? 'web' : 'github'}.zip`), src = rel('out', `${id}_source.zip`);
fs.rmSync(rel('out', `${id}_${web ? 'github' : 'web'}.zip`), { force: true });   // (only one of the two: the one for where the book is put)
fs.writeFileSync(gh, makeZip(filesOf(pub)));
fs.writeFileSync(src, makeZip(filesOf(rel('books', id), `${id}/`)));
const one = rel('out', `${id}_preview.html`);
fs.writeFileSync(one, oneFilePreview(pub));
const mb = (f) => (fs.statSync(f).size / 1024 / 1024).toFixed(1);
console.log(`📦 ZIP を作りました
   ${path.relative(ROOT, gh)}   ${mb(gh)} MB   ← ${web ? '展開して、中身を 公開する場所（サーバー）の フォルダに そのまま置く' : '展開して、中身を GitHub にアップロード'}（guide/06_公開と印刷.md）
   ${path.relative(ROOT, src)}   ${mb(src)} MB   ← 絵本の元データ。保存しておくと、あとで直せます
   ${path.relative(ROOT, one)}   ${mb(one)} MB   ← カメラなしの プレビュー（1つの ファイル。開くだけで 動きが 見られる）
`);
