// 2ページ「おちゃかい」：主人公（ミミ・おつきさま）と、あつまる ともだちの動き。
// さわったときの反応や遊びは page.json に書いてあり、ここの動きを "move" で名前で使います。
// どの動きも「ためて → 大きく動いて → 気持ちが見える」ひと続き。何秒かかるかを返します（その間は もう一度さわっても反応しない）。
// はやさは「少し ゆっくり〜ふつう」（小さな子が 目で追える はやさ。1回まわるのに 1秒くらい）。

// しゃがむ（ためる）：たてに ちぢんで もどる
const squash = (pg, id, k = 0.12, dur = 0.4) => {
  const b = pg.C(id).body;
  pg.tween(dur, (t) => { const u = Math.sin(Math.PI * t); b.scale.set(1 + u * k * 0.5, 1 - u * k, 1); }, () => b.scale.set(1, 1, 1));
};

export default {
  moves: {
    // ミミ「おちゃかいだよ！」：その場で とことこ（右・左に ゆれながら 3歩）→ 大ジャンプ（2.9 秒）
    catRun(pg, id) {
      const b = pg.C(id).body;
      pg.hop(id, 0.025, 0.5, 3);
      pg.tween(1.5, (t) => { b.rotation.z = Math.sin(t * Math.PI * 3) * 0.08; }, () => { b.rotation.z = 0; });
      pg.later(1550, () => squash(pg, id, 0.14, 0.4));
      pg.later(1900, () => pg.hop(id, 0.09, 0.9));
      return 2.9;
    },
    // ミミ「みんな まだかな？」：つまさき立ちで のびあがって、きょろきょろ（2.0 秒）
    catLook(pg, id) {
      const b = pg.C(id).body;
      pg.tween(2.0, (t) => {
        const up = Math.sin(Math.PI * t); b.scale.set(1 - up * 0.04, 1 + up * 0.1, 1);
        b.rotation.y = Math.sin(t * Math.PI * 2) * 0.55;
      }, () => { b.scale.set(1, 1, 1); b.rotation.y = 0; });
      return 2.0;
    },
    // ミミ（みんな そろった）：右へ ぴょん、左へ ぴょん、くるんと回って 大ジャンプ（3.2 秒）
    catDance(pg, id) {
      const c = pg.C(id), b = c.body, bs = pg.base(c);
      const step = (dx, at) => pg.later(at, () => { const x0 = b.position.x; pg.tween(0.5, (t) => { b.position.x = x0 + (bs.x + dx - x0) * t; }); pg.hop(id, 0.04, 0.5); });
      step(0.02, 0); step(-0.02, 550); step(0, 1100);
      pg.later(1600, () => pg.spin(id, 'y', 1, 0.9));
      pg.later(2400, () => pg.hop(id, 0.09, 0.8));
      return 3.2;
    },
    // おつきさま：ゆったり ゆれて、ふくらむように かがやく（2.6 秒）
    moonSmile(pg, id) {
      const b = pg.C(id).body;
      pg.tween(2.6, (t) => {
        b.rotation.z = Math.sin(t * Math.PI * 2) * 0.1 * (1 - t * 0.4);
        const s = 1 + Math.sin(Math.PI * t) * 0.08; b.scale.set(s, s, 1);
      }, () => { b.rotation.z = 0; b.scale.set(1, 1, 1); });
      pg.later(800, () => pg.burst(id, 10, 0.6, ['#fff6c9', '#ffffff']));
      return 2.6;
    },
    // うさぎ「おもち もってきたよ」：うしろに そって ためて → ぺったん、ぺったん（もちつき。1.95 秒）
    rabbitPound(pg, id) {
      const b = pg.C(id).body;
      const pound = (at) => pg.later(at, () => pg.tween(0.6, (t) => {
        b.rotation.z = t < 0.5 ? (t / 0.5) * 0.18 : 0.18 - ((t - 0.5) / 0.5) * 0.3;
        b.scale.y = t > 0.8 ? 1 - Math.sin((t - 0.8) / 0.2 * Math.PI) * 0.08 : 1;
      }, () => { b.rotation.z = 0; b.scale.y = 1; }));
      pound(0); pound(700);
      pg.later(1400, () => pg.hop(id, 0.04, 0.55));
      return 1.95;
    },
    // ふくろう「まにあった」：ばさばさ はばたいて 少し うかんで、ふわっと おりる（1.8 秒）
    owlFlap(pg, id) {
      const c = pg.C(id), b = c.body, bs = pg.base(c);
      pg.tween(1.8, (t) => {
        b.scale.x = 1 - Math.abs(Math.sin(t * Math.PI * 4)) * 0.15;
        b.position.y = bs.y + Math.sin(Math.PI * t) * 0.035;
      }, () => { b.scale.x = 1; b.position.y = bs.y; });
      return 1.8;
    },
    // ふくろう「うとうと…」：ゆっくり こっくり、こっくり（2.6 秒）
    owlDoze(pg, id) {
      const b = pg.C(id).body;
      pg.tween(2.6, (t) => { b.rotation.x = Math.max(0, Math.sin(t * Math.PI * 2)) * 0.35; }, () => { b.rotation.x = 0; });
      return 2.6;
    },
    // ほしのこ（キラキラ、きたよ）：くるんと 1回 ゆっくり まわって、ぽんっと ふくらむ（2.0 秒）
    starTwirl(pg, id) {
      pg.spin(id, 'z', 1, 1.4);
      pg.later(1400, () => { pg.pulse(id, 1.25, 0.6); pg.burst(id, 12, 0.8); });
      return 2.0;
    },
  },
};
