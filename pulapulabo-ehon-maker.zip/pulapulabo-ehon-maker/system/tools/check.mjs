// npm run check  → checks the book without building it
import { args, config, loadBook } from './lib/common.mjs';
import { checkBook } from './lib/check.mjs';
const A = args();
const id = A.book || (A._ && A._[0]) || config().book;
const B = loadBook(id);
const { errors, warns } = await checkBook(B);
console.log(`\n📖 「${id}」をチェックしました`);
warns.forEach((w) => console.log('  ⚠️ ', w));
errors.forEach((e) => console.log('  ❌', e));
console.log(errors.length ? `\n${errors.length}こ 直すところがあります。\n` : `\n✅ だいじょうぶです${warns.length ? `（⚠️ は ためしに見てから決めて OK）` : ''}\n`);
process.exit(errors.length ? 1 : 0);
