// Things for the whole scene of a page (written in page.json, see guide/05):
//   idle      : a piece that is always a little alive (float / breathe / sway / fly)
//   weather   : snow / rain / petals / leaves / fireflies / bubbles / stars, all the time
//   moods     : endings for different kinds of stories (night / celebrate / spring / sea / rainbow)
//   lights    : windows and lamps that light up, and the page getting darker or brighter ("dark")
//   travel    : a piece walking along points, or jumping out of a box to its own place
import * as THREE from 'three';
import { CALM } from './book.js';

const PH = 0.75;
const px = ([x, y]) => [x / 1600 - 0.5, PH / 2 - y / 1600];         // page pixels → page units
const rnd = (a, b) => a + Math.random() * (b - a);
const pick = (a) => a[Math.floor(Math.random() * a.length)];
// a point above the page: x across, y into the page, h up toward the sky
const air = (pg, x, y, h) => new THREE.Vector3(x, y, 0.01).add(pg.up.clone().multiplyScalar(h));

// ---------- idle moves (piece "idle") ----------
// they move the piece's "still" group, so touch moves on top of them still look right
export const IDLE = {
  float: (c, t, k) => { c.still.position.y = (Math.sin(t * 1.7) * 0.5 + 0.5) * 0.008 * k; },                  // ふわふわ
  breathe: (c, t, k) => { const s = Math.sin(t * 1.9) * 0.028 * k; c.still.scale.set(c.flipX * (1 - s * 0.35), 1 + s, 1); }, // すやすや
  sway: (c, t, k) => { c.still.rotation.z = Math.sin(t * 1.3) * 0.05 * k; },                                     // ゆらゆら
  // 飛び回る: small loops in front of its place, each piece on its own path (ほたる・ちょう・はち)
  fly: (c, t, k) => {
    const fx = 1.2 + 0.35 * Math.sin(c.phase * 2.3), fy = 1.1 + 0.6 * Math.cos(c.phase * 1.7);
    c.still.position.set(Math.sin(t * fx) * 0.045 * k, (0.02 + Math.sin(t * fy + 1) * 0.028) * k, 0.02 + Math.sin(t * 1.1) * 0.006 * k);
  },
};

// ---------- weather (page.json "weather") ----------
export const WEATHER = {
  snow:      { rate: 14, make: (pg) => pg.fx.emit(air(pg, rnd(-0.5, 0.5), rnd(-0.3, 0.3), rnd(0.28, 0.4)), { x: rnd(-0.02, 0.02), y: 0, z: 0 }, pick(['#ffffff', '#eef6ff']), rnd(0.012, 0.022), rnd(4, 6), 0.99, -0.06, 0) },
  rain:      { rate: 40, make: (pg) => { const v = pg.up.clone().multiplyScalar(-0.9); pg.fx.emit(air(pg, rnd(-0.5, 0.5), rnd(-0.3, 0.3), rnd(0.3, 0.42)), { x: 0.05, y: v.y, z: v.z }, '#bfe3ff', rnd(0.006, 0.009), 0.55, 1, -0.6, 0); } },
  petals:    { rate: 7, make: (pg) => pg.fx.emit(air(pg, rnd(-0.5, 0.5), rnd(-0.3, 0.3), rnd(0.28, 0.4)), { x: rnd(-0.06, 0.06), y: 0, z: 0 }, pick(['#ffc1d4', '#fff3f6', '#ffd1e1']), rnd(0.016, 0.024), rnd(4, 5.5), 0.985, -0.05, 1) },
  leaves:    { rate: 6, make: (pg) => pg.fx.emit(air(pg, rnd(-0.5, 0.5), rnd(-0.3, 0.3), rnd(0.28, 0.4)), { x: rnd(-0.07, 0.07), y: 0, z: 0 }, pick(['#f2a03a', '#e8743a', '#d8b23a', '#a8c45a']), rnd(0.018, 0.026), rnd(4, 5.5), 0.985, -0.06, 1) },
  fireflies: { rate: 3, make: (pg) => pg.fx.emit(air(pg, rnd(-0.48, 0.48), rnd(-0.3, 0.2), rnd(0.02, 0.14)), { x: rnd(-0.03, 0.03), y: rnd(-0.02, 0.02), z: rnd(-0.01, 0.02) }, pick(['#d8ff6a', '#f2ff9a']), rnd(0.02, 0.028), rnd(2.5, 4), 0.995, 0.004, 1) },
  bubbles:   { rate: 4, make: (pg) => pg.fx.emit(air(pg, rnd(-0.48, 0.48), rnd(-0.3, 0.3), 0), { x: rnd(-0.01, 0.01), y: 0, z: 0 }, pick(['#e8f8ff', '#ffffff']), rnd(0.016, 0.026), rnd(3, 4.5), 0.99, 0.05, 1) },
  stars:     { rate: 6, make: (pg) => pg.fx.emit(air(pg, rnd(-0.5, 0.5), rnd(-0.2, 0.3), rnd(0.18, 0.4)), { x: 0, y: 0, z: 0 }, pick(['#fff2b0', '#ffffff', '#bfe3ff']), rnd(0.014, 0.022), rnd(1.2, 2), 1, 0, 1) },
};
export function weatherTick(pg, kind, dt) {
  const w = WEATHER[kind]; if (!w || !pg.open) return;
  pg._wx = (pg._wx || 0) + dt * w.rate;
  while (pg._wx >= 1) { pg._wx -= 1; w.make(pg); }
}

// ---------- endings for different moods (done "effect") ----------
export const MOODS = {
  // おやすみ：流れ星がいくつも流れ、月明かりのきらきらが降る
  night(pg) {
    for (let k = 0; k < (CALM.on ? 3 : 6); k++) pg.later(300 + k * 650, () => {
      const x0 = rnd(-0.45, 0.1), h0 = rnd(0.3, 0.4), dir = new THREE.Vector3(0.42, 0, 0).add(pg.up.clone().multiplyScalar(-0.18));
      pg.sfx('sui');
      pg.tween(0.9, (t) => {
        const p = air(pg, x0, 0.1, h0).add(dir.clone().multiplyScalar(t));
        pg.fx.emit(p, { x: 0, y: 0, z: 0 }, '#fff6c8', 0.022 * (1 - t * 0.5), 0.6, 1, 0, 0);
      });
    });
    pg.tween(5, () => { if (Math.random() < 0.5) pg.fx.emit(air(pg, rnd(-0.5, 0.5), rnd(-0.2, 0.3), rnd(0.2, 0.4)), { x: 0, y: 0, z: 0 }, pick(['#fff2b0', '#ffffff']), 0.016, 1.6, 1, -0.01, 1); });
  },
  // 星空いっぱい（いちばん大きな おやすみ）：流れ星が たくさん流れ、星が ふりそそぎ、さいごに 大きな金色の流れ星
  starry(pg) {
    MOODS.night(pg);
    for (let k = 0; k < (CALM.on ? 3 : 8); k++) pg.later(1500 + k * 520, () => {
      const x0 = rnd(-0.45, 0.25), h0 = rnd(0.28, 0.42), dir = new THREE.Vector3(rnd(0.3, 0.45), 0, 0).add(pg.up.clone().multiplyScalar(-0.16));
      pg.tween(1.0, (t) => pg.fx.emit(air(pg, x0, 0.1, h0).add(dir.clone().multiplyScalar(t)), { x: 0, y: 0, z: 0 }, pick(['#fff6c8', '#ffe08a', '#c8f0ff']), 0.02 * (1 - t * 0.5), 0.7, 1, 0, 0));
    });
    pg.tween(7, () => { if (Math.random() < 0.7) pg.fx.emit(air(pg, rnd(-0.5, 0.5), rnd(-0.2, 0.3), rnd(0.25, 0.42)), { x: 0, y: -pg.up.y * 0.02, z: -pg.up.z * 0.02 }, pick(['#fff2b0', '#ffffff', '#ffe08a']), 0.014, 2.2, 1, 0, 0); });
    pg.later(CALM.on ? 4200 : 5600, () => {
      const x0 = -0.4, dir = new THREE.Vector3(0.8, 0, 0).add(pg.up.clone().multiplyScalar(-0.12));
      pg.sfx('kirarin');
      pg.tween(1.6, (t) => { for (let k = 0; k < 2; k++) pg.fx.emit(air(pg, x0, 0.12, 0.4).add(dir.clone().multiplyScalar(t)), { x: rnd(-0.01, 0.01), y: 0, z: 0 }, '#ffd84a', 0.032 * (1 - t * 0.4), 0.9, 1, 0, 0); });
    });
  },
  // おいわい：紙ふぶき
  celebrate(pg) {
    const cols = ['#ff5a6a', '#ffcf3a', '#5fc46a', '#3fa9e0', '#b07ae8', '#ff9fd0'];
    pg.sfx('waiwai');
    pg.tween(3, () => {
      for (let k = 0; k < 3; k++) pg.fx.emit(air(pg, rnd(-0.5, 0.5), rnd(-0.3, 0.3), rnd(0.32, 0.42)), { x: rnd(-0.05, 0.05), y: rnd(-0.02, 0.02), z: 0 }, pick(cols), rnd(0.014, 0.022), rnd(2.5, 3.5), 0.98, -0.12, 1);
    });
  },
  // 春：花が咲くように花びらがはじけ、ふわふわ舞う
  spring(pg) {
    pg.sfx('powa');
    const ids = Object.keys(pg.cards).filter((id) => pg.C(id).body.visible);
    for (let k = 0; k < 6; k++) pg.later(k * 220, () => {
      const p = ids.length ? pg.top(pick(ids), 0.9) : air(pg, rnd(-0.4, 0.4), rnd(-0.2, 0.2), 0.1);
      pg.fx.burst(p, 18, 1.0, ['#ffc1d4', '#fff3f6', '#ffd1e1', '#fff2a8']);
    });
    pg.tween(3.5, () => { if (Math.random() < 0.6) WEATHER.petals.make(pg); });
  },
  // 海：あわが下からたくさんのぼる
  sea(pg) {
    pg.sfx('shuwa');
    pg.tween(3.5, () => { for (let k = 0; k < 2; k++) WEATHER.bubbles.make(pg); });
    pg.later(300, () => pg.fx.burst(air(pg, 0, 0, 0.15), 24, 1.2, ['#e8f8ff', '#bfe8ff', '#ffffff']));
  },
  // 虹：空に虹がかかる
  rainbow(pg) {
    pg.sfx('chime');
    const tex = rainbowTexture();
    const m = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.45), new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, opacity: 0 }));
    const holder = new THREE.Group(); holder.add(m); m.position.set(0, 0.2, 0); holder.position.set(0, 0.15, 0.002);
    pg.root.add(holder); pg._extras.push(holder);
    pg.tween(6, (t) => {
      holder.rotation.x = pg.viewTheta * 0.9;
      m.material.opacity = Math.min(1, t * 5, (1 - t) * 4) * 0.85;
      if (!CALM.on && Math.random() < 0.3) pg.fx.emit(air(pg, rnd(-0.4, 0.4), 0.15, rnd(0.2, 0.45)), { x: 0, y: 0, z: 0 }, '#ffffff', 0.016, 1, 1, 0, 1);
    }, () => { pg.root.remove(holder); });
  },
};
let RAINBOW = null;
function rainbowTexture() {
  if (RAINBOW) return RAINBOW;
  const c = document.createElement('canvas'); c.width = 512; c.height = 256;
  const g = c.getContext('2d');
  const cols = ['#ff5a5a', '#ffa03a', '#ffe14a', '#6fd06a', '#4ab0f0', '#6a6ae8', '#b07ae8'];
  cols.forEach((col, i) => { g.strokeStyle = col; g.lineWidth = 16; g.globalAlpha = 0.9; g.beginPath(); g.arc(256, 256, 236 - i * 15, Math.PI, 0); g.stroke(); });
  RAINBOW = new THREE.CanvasTexture(c); RAINBOW.colorSpace = THREE.SRGBColorSpace;
  return RAINBOW;
}

// ---------- lights ----------
let WARM = null;
function warmTexture() {
  if (WARM) return WARM;
  const c = document.createElement('canvas'); c.width = c.height = 128;
  const g = c.getContext('2d'); const grd = g.createRadialGradient(64, 64, 4, 64, 64, 64);
  grd.addColorStop(0, 'rgba(255,240,170,0.95)'); grd.addColorStop(0.4, 'rgba(255,200,90,0.45)'); grd.addColorStop(1, 'rgba(255,170,60,0)');
  g.fillStyle = grd; g.fillRect(0, 0, 128, 128);
  WARM = new THREE.CanvasTexture(c); WARM.colorSpace = THREE.SRGBColorSpace;
  return WARM;
}
// a window or lamp lights up (its <id>@on picture if there is one, and a warm glow behind it); on = false turns it off
export function light(pg, id, on = true) {
  const c = pg.C(id); if (!c) return;
  if (pg.tex[`${id}@on`]) pg.swap(id, on ? `${id}@on` : c.m.tex[0]);
  if (!c.lamp) {
    const s = Math.max(c.w, c.h) * 1.6;
    c.lamp = new THREE.Mesh(new THREE.PlaneGeometry(s, s), new THREE.MeshBasicMaterial({ map: warmTexture(), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0 }));
    c.lamp.position.set(c.m.pivot === 'left' ? c.w / 2 : c.m.pivot === 'right' ? -c.w / 2 : 0, c.m.pivot === 'top' ? -c.h / 2 : c.h / 2, -0.004);
    c.body.add(c.lamp);
  }
  c.lit = on;
  const lamp = c.lamp, from = lamp.material.opacity, to = on ? 0.9 : 0;
  pg.tween(0.5, (t) => { lamp.material.opacity = from + (to - from) * t; tint(pg, c); });
}
// the whole page gets darker or brighter: 0 = day … 0.6 = night. Lit pieces stay bright.
const NIGHT = new THREE.Color('#4a5288'), WHITE = new THREE.Color('#ffffff');
function tint(pg, c) {
  const k = c.lit ? 0 : (pg._dark || 0) / 0.6;
  c.mesh.material.color.copy(WHITE).lerp(NIGHT, Math.min(1, k));
}
export function darken(pg, amount = 0.45, dur = 1.5) {
  amount = Math.max(0, Math.min(0.6, amount));
  if (!pg._darkPlane) {
    pg._darkPlane = new THREE.Mesh(new THREE.PlaneGeometry(1, PH), new THREE.MeshBasicMaterial({ color: '#0b1030', transparent: true, depthWrite: false, opacity: 0 }));
    pg._darkPlane.position.z = 0.0006; pg.root.add(pg._darkPlane);
  }
  const from = pg._dark || 0;
  const set = (v) => { pg._dark = v; pg._darkPlane.material.opacity = v; Object.values(pg.cards).forEach((c) => tint(pg, c)); };
  if (dur <= 0) set(amount); else pg.tween(dur, (t) => set(from + (amount - from) * t));
}

// ---------- travel: walking along points, or jumping out of a box ----------
// pieces placed directly on the page (not "parent" pieces) can move around the page
export function canTravel(pg, id) { const c = pg.C(id); return !!(c && !c.m.parent); }
// walk: through points (page pixels: where the bottom of the piece goes); hop a little on each step
export function walk(pg, id, points, { speed = 0.16, flip = false, back = false } = {}) {
  const c = pg.C(id); if (!canTravel(pg, id) || !points || !points.length) return 0;
  const home = c.pivotHome;
  const atHome = c.pivot.position.distanceTo(home) < 0.002;
  let path = points.map((q) => { const [x, y] = px(q); return new THREE.Vector3(x, y, home.z); });
  if (back && !atHome) path = [...path.slice(0, -1).reverse(), home.clone()];
  path = [c.pivot.position.clone(), ...path];
  const seg = []; let total = 0;
  for (let i = 1; i < path.length; i++) { const d = path[i].distanceTo(path[i - 1]); seg.push(d); total += d; }
  if (total < 1e-4) return 0;
  const dur = Math.max(0.8, total / speed), b = c.body;
  // a picture drawn from the side ("faces": "left" / "right") always turns the way it walks (one drawn facing left is left as it is when walking left)
  const face = c.m.faces === 'left' ? -1 : 1; flip = flip || c.m.faces === 'left' || c.m.faces === 'right';
  pg.tween(dur, (t) => {
    let dist = t * total, i = 0;
    while (i < seg.length - 1 && dist > seg[i]) { dist -= seg[i]; i++; }
    const k = seg[i] ? dist / seg[i] : 1;
    c.pivot.position.lerpVectors(path[i], path[i + 1], Math.min(1, k));
    b.position.y = pg.base(c).y + Math.abs(Math.sin(t * dur * 9)) * 0.012;
    if (flip && Math.abs(path[i + 1].x - path[i].x) > 1e-4) { c.flipX = (path[i + 1].x < path[i].x ? -1 : 1) * face; c.still.scale.x = c.flipX * Math.abs(c.still.scale.x); }
  }, () => { b.position.y = pg.base(c).y; });
  return dur;
}
// reveal: a hidden piece jumps out of another piece (the box opens: its <box>@open picture if there is one)
export function reveal(pg, boxId, itemId) {
  const box = pg.C(boxId), item = pg.C(itemId);
  if (!box || !item || !item.hidden) return false;
  if (pg.tex[`${boxId}@open`]) pg.swap(boxId, `${boxId}@open`);
  pg.sfx('pon');
  if (!canTravel(pg, itemId)) { pg.rise(itemId, -item.h, 0.85); pg.later(400, () => pg.burst(itemId, 18, 1.1)); return true; }
  const from = new THREE.Vector3(); box.pivot.getWorldPosition(from); pg.root.worldToLocal(from); from.z = item.pivotHome.z;
  const to = item.pivotHome.clone(), b = item.body;
  item.pivot.position.copy(from); b.scale.setScalar(0.3); pg.show(itemId);
  pg.tween(0.8, (t) => {
    item.pivot.position.lerpVectors(from, to, t);
    b.position.y = pg.base(item).y + Math.sin(Math.PI * t) * 0.12;
    b.scale.setScalar(0.3 + 0.7 * Math.min(1, t * 1.6));
  }, () => { b.position.y = pg.base(item).y; b.scale.setScalar(1); pg.burst(itemId, 18, 1.1); pg.sfx('kirarin'); });
  return true;
}
