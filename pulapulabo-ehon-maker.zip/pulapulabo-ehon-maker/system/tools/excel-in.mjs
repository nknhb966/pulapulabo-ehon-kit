// npm run excel-in                → out/<book>_表.xlsx (npm run excel) → the book's book.json, page.json and read.json
// npm run excel-in -- <file.xlsx> → another table file
// npm run excel-in -- --book <id>
// The json files as they were are kept in out/<book>_json_backup/ (the last ones before this).
import fs from 'node:fs';
import path from 'node:path';
import { ROOT, rel, args, config, loadBook, mkdirp, exists } from './lib/common.mjs';
import { readXlsx } from './lib/xlsx.mjs';
import { sheetsToBook } from './lib/table.mjs';
import { formatJSON } from './lib/jsonfmt.mjs';

const A = args();
const B = loadBook(A.book || config().book);
const file = A._ && A._[0] ? path.resolve(process.env.INIT_CWD || process.cwd(), String(A._[0])) : rel('out', `${B.id}_表.xlsx`);
if (!exists(file)) { console.error(`\n  ${path.relative(ROOT, file)} が ありません。先に npm run excel で 表を作ります。\n`); process.exit(1); }
let res;
try { res = sheetsToBook(readXlsx(fs.readFileSync(file)), B); }
catch (e) {
  console.error(`\n  ❌ ${e.message}\n     表を直して 保存してから、もう一度 npm run excel-in をしてください（json は 変えていません）。\n`);
  process.exit(1);
}
// keep the json as it was
const bk = rel('out', `${B.id}_json_backup`);
fs.rmSync(bk, { recursive: true, force: true });
const keep = (f) => { if (!exists(f)) return; const to = path.join(bk, path.relative(B.dir, f)); mkdirp(path.dirname(to)); fs.copyFileSync(f, to); };
keep(path.join(B.dir, 'book.json')); keep(path.join(B.dir, 'read.json'));
for (const p of B.pages) keep(path.join(p.dir, 'page.json'));
// write
fs.writeFileSync(path.join(B.dir, 'book.json'), formatJSON(res.book));
if (res.read) fs.writeFileSync(path.join(B.dir, 'read.json'), formatJSON(res.read));
for (const p of res.pages) {
  const dir = path.join(B.dir, 'pages', p.id);
  mkdirp(path.join(dir, 'layers'));
  fs.writeFileSync(path.join(dir, 'page.json'), formatJSON(p.def));
}
const gone = B.pages.filter((p) => !res.pages.some((q) => q.id === p.id)).map((p) => p.id);
console.log(`
  ✅ 表から「${res.book.title}」の json を作りました（${res.pages.length}ページ: ${res.pages.map((p) => p.id).join('・')}）
     前の json は ${path.relative(ROOT, bk)}/ に しまいました${res.newPages.length ? `
  ・新しい ページ: ${res.newPages.join('・')}。pages/<ページ>/layers/ に 絵（_background と 飛び出す絵）を入れます（guide/03）` : ''}${gone ? (gone.length ? `
  ・表に ない ページ（${gone.join('・')}）は、絵本から はずしました（フォルダは 残っています）` : '') : ''}

  次にすること: npm run check → npm run build
`);
