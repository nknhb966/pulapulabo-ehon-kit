// 道具と手: a game played with a tool from the bag (net, poi, hammer …), or with a hand when there is none.
//   "tool": { "id": "net", "from": "dango", "who": "owl", "say": "…", "hand": "…", "use": "scoop" }
//   - "id"   : the tool (a もちもの). With it, a touch catches a little farther from the target (少し やさしく).
//   - "from" : a もちもの that is handed over for the tool when the game starts (it leaves the bag).
//              "who" says "say" (or the kit's words) and gives the tool.
//   - "hand" : the words when there is no tool (or the kit's words). The game is the same, played by hand.
//   - "use"  : how the tool moves at a touch: "scoop" (すくう: net, poi) or "whack" (たたく: hammer).
// Each touch shows the tool (or the hand) doing its move where the finger touched.
import * as THREE from 'three';
import { ICONS, has, getItem, giveItem, itemOf, shown } from './story.js';
import { trx, tr } from './lang.js';
import { easeInOut } from './fx.js';
import { BOOK } from './book.js';

const HAND = 0.075, TOOL = 0.11;   // how far from a target a touch still catches (page widths)

// the hand that catches when there is no tool: the main character's (the first one in "cast").
//   book.json "hand": "cat" / "dog" / "bear" / "rabbit" / "bird" / "human", or { "kind": "cat", "color": "#…", "pad": "#…" };
//   books/<id>/items/hand.svg — the book's own picture. Without either, the kind comes from the main character's words
//   (id, name, look, about: ねこ → cat …).
const HANDS = {
  human: { color: '#ffd9b8', pad: '#e8a080', line: '#7a4a2a' },
  cat: { color: '#fffaf0', pad: '#ffb3c8', line: '#4a3328' },
  dog: { color: '#d9a066', pad: '#6a4030', line: '#4a3328' },
  bear: { color: '#9a6a44', pad: '#4a2e22', line: '#3b2a20' },
  rabbit: { color: '#fffaf0', pad: '#ffb3c8', line: '#4a3328' },
  bird: { color: '#ffd84a', pad: '#f2a23a', line: '#6a4a20' },
};
const WORDS = [['human', /おとこのこ|おんなのこ|男の子|女の子|こども|子ども|にんげん|人間|おじいさん|おばあさん|おとうさん|おかあさん|human|boy|girl/i],
  ['cat', /ねこ|ネコ|猫|cat|ちゃトラ|キジトラ|サバトラ|しろトラ|三毛|みけねこ|ミケネコ|にゃん/i], ['dog', /いぬ|イヌ|犬|dog|きつね|キツネ|たぬき|タヌキ/i], ['bear', /くま|クマ|熊|bear|パンダ|panda/i],
  ['rabbit', /うさぎ|ウサギ|兎|rabbit|りす|リス|ねずみ|ネズミ|ハムスター/i], ['bird', /とり|トリ|鳥|ひよこ|ヒヨコ|ペンギン|ふくろう|フクロウ|bird/i]];
export function handOf() {
  let h = BOOK.hand;
  if (typeof h === 'string') h = { kind: h };
  if (!h || !HANDS[h.kind]) {
    const c = (BOOK.cast || [])[0] || {};
    const text = [c.id, c.name, c.look, c.about].join(' ');
    const w = WORDS.find(([, re]) => re.test(text));
    h = { ...(h || {}), kind: w ? w[0] : 'human' };
  }
  return { kind: h.kind, ...HANDS[h.kind], ...(h.color ? { color: h.color } : {}), ...(h.pad ? { pad: h.pad } : {}) };
}
function handSVG({ kind, color, pad, line }) {
  const head = '<svg xmlns="http://www.w3.org/2000/svg" width="240" height="240" viewBox="0 0 120 120">';
  const paw = (toes, big, claws = '') => `${head}<path d="M60 16 C84 16 100 36 100 62 C100 90 82 106 60 106 C38 106 20 90 20 62 C20 36 36 16 60 16Z" fill="${color}" stroke="${line}" stroke-width="5"/>${claws}${toes}${big}</svg>`;
  const bean = (x, y, rx, ry) => `<ellipse cx="${x}" cy="${y}" rx="${rx}" ry="${ry}" fill="${pad}"/>`;
  const bigPad = `<path d="M60 64 C73 64 84 72 84 83 C84 94 73 98 60 94 C47 98 36 94 36 83 C36 72 47 64 60 64Z" fill="${pad}"/>`;
  switch (kind) {
    case 'cat': return paw(bean(36, 52, 8, 10) + bean(51, 38, 8, 10) + bean(69, 38, 8, 10) + bean(84, 52, 8, 10), bigPad);
    case 'dog': return paw(bean(35, 50, 10, 12) + bean(51, 34, 10, 12) + bean(69, 34, 10, 12) + bean(85, 50, 10, 12), bigPad);
    case 'bear': return paw(bean(34, 48, 10, 11) + bean(50, 34, 10, 11) + bean(70, 34, 10, 11) + bean(86, 48, 10, 11), bigPad,
      `<g fill="${line}"><path d="M30 34 l4 -12 l5 11Z"/><path d="M46 20 l5 -12 l4 12Z"/><path d="M66 20 l4 -12 l5 12Z"/><path d="M82 34 l5 -11 l4 12Z"/></g>`);
    case 'rabbit': return `${head}<ellipse cx="60" cy="62" rx="32" ry="44" fill="${color}" stroke="${line}" stroke-width="5"/>${bean(46, 40, 6, 8)}${bean(60, 32, 6, 8)}${bean(74, 40, 6, 8)}<ellipse cx="60" cy="74" rx="14" ry="18" fill="${pad}"/></svg>`;
    case 'bird': return `${head}<g stroke="${line}" stroke-width="4" stroke-linejoin="round"><path d="M18 74 C26 40 56 20 98 22 C86 34 84 40 92 44 C78 50 78 56 86 62 C72 66 70 72 76 78 C58 84 36 88 18 74Z" fill="${color}"/><path d="M40 70 C52 58 66 50 84 44 M44 78 C56 70 66 66 78 62" fill="none" stroke="${pad}" stroke-width="5" stroke-linecap="round"/></g></svg>`;
    default: return `${head}<g stroke="${line}" stroke-width="5" stroke-linejoin="round" fill="${color}"><path d="M30 70 Q24 44 34 40 Q42 38 44 56 L46 30 Q47 20 55 20 Q63 21 62 31 L62 50 L64 24 Q66 14 74 15 Q82 17 80 28 L78 52 L84 34 Q88 26 95 29 Q101 33 97 42 L88 74 Q82 102 58 104 Q36 104 30 70 Z"/></g><path d="M50 84 Q60 90 72 84" stroke="${pad}" stroke-width="4" fill="none" stroke-linecap="round"/></svg>`;
  }
}

// the kit's own pictures of tools, for books without their own picture
const SVG = {
  net: '<svg xmlns="http://www.w3.org/2000/svg" width="240" height="240" viewBox="0 0 160 160"><path d="M84,70 L148,150" stroke="#4a3360" stroke-width="15" stroke-linecap="round"/><path d="M84,70 L148,150" stroke="#c98a50" stroke-width="9" stroke-linecap="round"/><path d="M12,48 Q14,118 50,132 Q84,122 88,48Z" fill="#f2fbff" stroke="#4a3360" stroke-width="4"/><g stroke="#9cc4e8" stroke-width="3" fill="none"><path d="M22,62 Q50,76 80,62 M20,82 Q50,98 80,82 M28,104 Q50,116 72,104 M32,50 Q34,100 48,128 M50,50 L50,130 M68,50 Q66,100 54,128"/></g><ellipse cx="50" cy="46" rx="40" ry="16" fill="none" stroke="#4a3360" stroke-width="11"/><ellipse cx="50" cy="46" rx="40" ry="16" fill="none" stroke="#3a7ac0" stroke-width="6"/></svg>',
  poi: '<svg xmlns="http://www.w3.org/2000/svg" width="240" height="240" viewBox="0 0 120 120"><path d="M62 62 L102 108" stroke="#e8756a" stroke-width="10" stroke-linecap="round"/><circle cx="44" cy="42" r="32" fill="#ffffff" stroke="#e8756a" stroke-width="8"/><circle cx="44" cy="42" r="24" fill="#eaf6ff"/></svg>',
  hammer: '<svg xmlns="http://www.w3.org/2000/svg" width="240" height="240" viewBox="0 0 120 120"><path d="M60 56 L98 110" stroke="#f2c230" stroke-width="11" stroke-linecap="round"/><rect x="14" y="20" width="76" height="40" rx="18" transform="rotate(-35 52 40)" fill="#ff6a5a" stroke="#b83a30" stroke-width="5"/><path d="M28 30 L36 52" stroke="#ffb0a8" stroke-width="5" stroke-linecap="round" transform="rotate(-35 52 40)"/></svg>',
};
const KIND = { net: 'net', ami: 'net', mushiami: 'net', poi: 'poi', hammer: 'hammer', piko: 'hammer' };
const TEX = {};
function texOf(key, src) {
  if (TEX[key]) return TEX[key];
  const t = new THREE.Texture(); t.colorSpace = THREE.SRGBColorSpace;
  const im = new Image(); im.onload = () => { t.image = im; t.needsUpdate = true; }; im.src = src;
  return (TEX[key] = t);
}
const svgURI = (s) => `data:image/svg+xml;charset=utf-8,${encodeURIComponent(s)}`;
// the picture of a tool: the book's own (items/<id>.svg or a piece with the same id), else the kit's
function toolTex(id) {
  if (id && ICONS[id]) return texOf(`i:${id}`, ICONS[id]);
  if (id && KIND[id]) return texOf(`k:${KIND[id]}`, svgURI(SVG[KIND[id]]));
  if (ICONS.hand) return texOf('i:hand', ICONS.hand);   // the book's own hand (items/hand.svg)
  const h = handOf();
  return texOf(`h:${h.kind}:${h.color}:${h.pad}`, svgURI(handSVG(h)));
}
const useOf = (g) => (g.tool && g.tool.use) || (g.type === 'pop' && (g.style || 'rise') === 'rise' ? 'whack' : 'scoop');

// at the start of the game (and when the page is shown again): tool or hand?  → seconds to wait for the giving scene
export function toolStart(pg, g) {
  const T = g.tool; if (!T || !T.id) return 0;
  toolTex(null); toolTex(T.id);   // the pictures are ready before the first touch
  if (has(T.id)) { pg.gs.tool = T.id; if (!pg.gs.toldTool) { pg.gs.toldTool = true; pg.toast(trx('{y}を つかって あそぼう！', { y: shown(itemOf(T.id).name) }), 2600); } return 0; }
  if (T.from && has(T.from)) {
    // the giving scene: the thing goes to "who", and the tool comes back
    const by = T.who && pg.C(T.who) ? T.who : null;
    const words = T.say || trx('{x}を ありがとう！ {y}を どうぞ', { x: shown(itemOf(T.from).name), y: shown(itemOf(T.id).name) });
    giveItem(T.from);
    if (by) { handOver(pg, T.from, by); pg.later(700, () => { pg.hop(by, 0.05); pg.say(by, words); }); } else pg.toast(words, 2600);
    pg.later(2300, () => { getItem(T.id); pg.gs.tool = T.id; });
    pg.gs.toldTool = true;
    return 2.9;
  }
  pg.gs.tool = null;
  if (!pg.gs.toldHand) { pg.gs.toldHand = true; pg.toast(T.hand ? shown(T.hand) : tr(useOf(g) === 'whack' ? 'てで ポンと たたこう！' : 'てで そっと つかまえよう！'), 2600); }
  return 0;
}
export const reach = (pg) => (pg.gs.tool ? TOOL : HAND);
export const hasTool = (g) => !!(g.tool && g.tool.id);

// the tool (or the hand) does its move where the finger touched
export function toolSwing(pg, g, at) {
  if (!hasTool(g) || !at) return;
  const tool = pg.gs.tool, use = useOf(g);
  const mat = new THREE.SpriteMaterial({ map: toolTex(tool), transparent: true, depthTest: false, depthWrite: false });
  const s = new THREE.Sprite(mat); s.renderOrder = 20;
  const size = tool ? 0.1 : 0.08;
  s.scale.set(0.001, 0.001, 1);
  const p0 = at.clone().add(pg.up.clone().multiplyScalar(0.03));
  s.position.copy(p0); pg.root.add(s); pg._extras.push(s);
  const dur = use === 'whack' ? 0.55 : 0.7;
  pg.tween(dur, (t) => {
    if (use === 'whack') {   // up, then down onto the spot, a small bounce
      const k = t < 0.45 ? 0.6 * (1 - easeInOut(t / 0.45)) : -0.25 * Math.sin(Math.PI * (t - 0.45) / 0.55);
      mat.rotation = k; s.position.copy(p0).add(pg.up.clone().multiplyScalar(0.02 * Math.max(0, k)));
    } else {                 // a sweep from one side up to the other
      mat.rotation = -0.5 + 0.9 * easeInOut(t);
      s.position.copy(p0).add(pg.up.clone().multiplyScalar(0.035 * Math.sin(Math.PI * t)));
    }
    const k = size * Math.min(1, 0.6 + t * 4);   // comes up quickly, without a jump
    s.scale.set(k, k, 1);
    mat.opacity = t < 0.1 ? t / 0.1 : t < 0.75 ? 1 : 1 - (t - 0.75) / 0.25;
  }, () => { pg.root.remove(s); mat.dispose(); });
}

// a もちもの handed over: its picture comes down onto the one who gets it, with a sparkle
export function handOver(pg, itemId, toId) {
  const c = pg.C(toId); if (!c || !ICONS[itemId]) return;
  const mat = new THREE.SpriteMaterial({ map: texOf(`i:${itemId}`, ICONS[itemId]), transparent: true, depthTest: false, depthWrite: false });
  const s = new THREE.Sprite(mat); s.renderOrder = 20; s.scale.set(0.07, 0.07, 1);
  pg.root.add(s); pg._extras.push(s);
  pg.tween(0.9, (t) => {
    const p = pg.top(toId, 1.0).add(pg.up.clone().multiplyScalar(0.08 * (1 - easeInOut(t))));
    s.position.copy(p); mat.opacity = t < 0.15 ? t / 0.15 : t < 0.8 ? 1 : 1 - (t - 0.8) / 0.2;
  }, () => { pg.root.remove(s); mat.dispose(); pg.burst(toId, 12, 0.9, ['#fff2a8', '#ffffff']); pg.sfx('pon'); });
}
