// npm run sheet                 → out/<book>_parts_p<n>.png : every picture of each page side by side
//                                 (background, pop-up pieces, hidden ones and swap pictures — things the printed page does not show)
// npm run sheet -- --book <id>
import path from 'node:path';
import sharp from 'sharp';
import { ROOT, rel, args, config, loadBook, mkdirp } from './lib/common.mjs';
import { listPictures, rasterize, BACKGROUND } from './lib/layers.mjs';
import { renderSVG, escXML } from './lib/svg.mjs';

const A = args();
const B = loadBook(A.book || config().book);
const TW = 480, TH = 360, LAB = 44, COLS = 4, GAP = 12;
mkdirp(rel('out'));

const checker = await (async () => {
  const s = 24, cells = [];
  for (let y = 0; y < TH; y += s) for (let x = 0; x < TW; x += s) if (((x + y) / s) % 2 === 0) cells.push(`<rect x="${x}" y="${y}" width="${s}" height="${s}" fill="#e4e4e4"/>`);
  return renderSVG(`<svg xmlns="http://www.w3.org/2000/svg" width="${TW}" height="${TH}"><rect width="${TW}" height="${TH}" fill="#f6f6f6"/>${cells.join('')}</svg>`, TW);
})();

for (const p of B.pages) {
  const L = path.join(p.dir, 'layers');
  const pics = listPictures(L);
  const def = Object.fromEntries((p.def.pieces || []).map((d) => [d.id, d]));
  const order = (p.def.pieces || []).map((d) => d.id);
  pics.sort((a, b) => (BACKGROUND.includes(a.name) ? -1 : BACKGROUND.includes(b.name) ? 1 : (order.indexOf(a.base) - order.indexOf(b.base)) || (a.alt ? 1 : 0) - (b.alt ? 1 : 0)));
  const tiles = [];
  for (const f of pics) {
    const raw = await rasterize(f.file, TW, TH);
    const img = await sharp(raw, { raw: { width: TW, height: TH, channels: 4 } }).png().toBuffer();
    const d = def[f.base] || {};
    const tags = [BACKGROUND.includes(f.name) ? '背景' : null, f.alt ? `swap: ${f.alt}` : null, d.hidden ? 'hidden' : null, d.parent ? `parent: ${d.parent}` : null, !BACKGROUND.includes(f.name) && !def[f.base] ? '⚠ pieces にない' : null].filter(Boolean).join(' / ');
    const label = renderSVG(`<svg xmlns="http://www.w3.org/2000/svg" width="${TW}" height="${LAB}"><rect width="${TW}" height="${LAB}" fill="#2b2b3a"/><text x="10" y="29" font-size="20" fill="#fff">${escXML(f.fileName)}</text><text x="${TW - 10}" y="29" font-size="16" fill="#ffd36b" text-anchor="end">${escXML(tags)}</text></svg>`, TW);
    const pic = await sharp(checker).composite([{ input: img }]).png().toBuffer();   // (sharp keeps only one composite per chain)
    tiles.push(await sharp(pic).extend({ bottom: LAB, background: '#2b2b3a' }).composite([{ input: label, top: TH, left: 0 }]).png().toBuffer());
  }
  const rows = Math.ceil(tiles.length / COLS);
  const W = COLS * TW + (COLS + 1) * GAP, H = rows * (TH + LAB) + (rows + 1) * GAP;
  const out = rel('out', `${B.id}_parts_${p.id}.png`);
  await sharp({ create: { width: W, height: H, channels: 3, background: '#ffffff' } })
    .composite(tiles.map((t, i) => ({ input: t, left: GAP + (i % COLS) * (TW + GAP), top: GAP + Math.floor(i / COLS) * (TH + LAB + GAP) })))
    .png().toFile(out);
  console.log(`  ${path.relative(ROOT, out)}  （${tiles.length} 枚）`);
}
