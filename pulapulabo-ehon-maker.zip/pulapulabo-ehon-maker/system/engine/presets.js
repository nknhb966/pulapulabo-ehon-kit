// Ready-made behaviour, written in page.json instead of code:
//   "touch": what happens when a thing is touched (move, sound, word, line, picture swap, effect,
//            feeling mark, walking, lights, something jumping out of a box, もちもの and choices:
//            "get" puts a thing in the bag, "need" / "if" decide whether it happens, "else" happens instead)
//            + "wait" / "lock" (how long it can't be touched again), "after" (the reaction once the page is cleared)
//   "goal":  the page's game and what happens when it is cleared (goals.js)
// A page can also have script.js for anything special; the script wins where both say something.
import * as THREE from 'three';
import { isCast, markColor, fireworkColor, castIds, voice, CALM } from './book.js';
import { addHalo, blinkHalo } from './glow.js';
import { easeInOut } from './fx.js';
import { GOALS, goalHint, goalProgress, goalUpdate } from './goals.js';
import { walk, light, reveal, canTravel } from './scene.js';
import { holds, remember, itemOf, has, giveItem, join, MEM } from './story.js';
import { handOver } from './tool.js';

// ---------- small helpers ----------
export const pick = (v, i) => (Array.isArray(v) ? v[i % v.length] : v);
export const altKey = (pg, id, alt) => (pg.tex[`${id}@${alt}`] ? `${id}@${alt}` : alt);
export function nextIdx(pg, key) { pg.gs.idx = pg.gs.idx || {}; const i = pg.gs.idx[key] || 0; pg.gs.idx[key] = i + 1; return i; }
// "calm" mode (ひかえめモード): slower turns and smaller shakes
const slow = () => (CALM.on ? 1.6 : 1), small = () => (CALM.on ? 0.5 : 1);

// ---------- moves ----------
// A move gets (pg, id, hit, spec): spec is the touch's own settings, for the options
//   "power": how big (1 = usual, 0.5 = half, 2 = double)   "dir": "left" / "right"   "turns": how many turns   "with": the other piece
// A move may return how many seconds it takes: until then the piece can't be touched again.
// はやさ：小さな子が目で追える「少し ゆっくり」（1回はねる 0.7秒、1回まわる 1.2秒）。どの動きも、最後は なめらかに もとの位置へ もどる。
const pw = (spec) => (spec && typeof spec.power === 'number' ? spec.power : 1);
const dirOf = (spec, def = 1) => (spec && spec.dir === 'left' ? -1 : spec && spec.dir === 'right' ? 1 : def);
// the way the picture faces ("faces": "left" / "right"): とぶ・はねる・ころぶ go that way unless "dir" says otherwise
const faceOf = (pg, id) => { const c = pg.C(id), f = c && c.m.faces; return f === 'left' ? -1 : 1; };
const turnsOf = (spec) => (spec && spec.turns > 0 ? spec.turns : 1);
const turnTime = (n) => 1.2 * (1 + (n - 1) * 0.45);
const other = (pg, spec) => (spec && spec.with && pg.C(spec.with) ? spec.with : null);
export const MOVES = {
  hop: (pg, id, hit, spec) => pg.hop(id, 0.05 * pw(spec), 0.7),
  bigHop: (pg, id, hit, spec) => pg.hop(id, 0.09 * (CALM.on ? 0.7 : 1) * pw(spec), 0.8),
  jump2: (pg, id, hit, spec) => pg.hop(id, 0.05 * pw(spec), 0.55, 2),
  wobble: (pg, id, hit, spec) => pg.wobble(id, 0.08 * small() * pw(spec), 1.1, 4),
  // ぶるぶる：4回 ゆれて、だんだん とまる（こまかすぎない はやさ）
  shake: (pg, id, hit, spec) => {
    const c = pg.C(id), b = c.body, bs = pg.base(c), a = 0.007 * small() * pw(spec);
    pg.tween(0.9, (t) => { b.position.x = bs.x + Math.sin(t * Math.PI * 8) * a * (1 - t); }, () => { b.position.x = bs.x; });
  },
  spin: (pg, id, hit, spec) => { const n = turnsOf(spec), d = turnTime(n) * slow(); pg.spin(id, 'y', n, d); return d; },
  turn: (pg, id, hit, spec) => { const n = turnsOf(spec), d = turnTime(n) * slow(); pg.spin(id, 'z', n * dirOf(spec, 1), d); return d; },
  pulse: (pg, id, hit, spec) => pg.pulse(id, 1 + 0.18 * pw(spec), 0.7),
  // ゆらゆら ゆれる。"with": もう1つの絵が 左右反対に いっしょに ゆれる（カーテン）
  swing: (pg, id, hit, spec) => {
    const a = 0.4 * (CALM.on ? 0.6 : 1) * pw(spec);
    pg.swing(id, a, 2.0, 3);
    const o = other(pg, spec); if (o) pg.swing(o, -a, 2.0, 3);
    return 2.0;
  },
  topple: (pg, id) => pg.topple(id, 1.4),
  // ころころ ころがって もどる（"dir": "left" で左へ）
  roll: (pg, id, hit, spec) => {
    const c = pg.C(id), b = c.body, bs = pg.base(c), k = dirOf(spec, 1), d = 1.7 * slow();
    pg.tween(d, (t) => { const u = Math.sin(Math.PI * t); b.position.x = bs.x + k * u * 0.06; b.rotation.z = -k * u * Math.PI * 1.4; }, () => { b.position.x = bs.x; b.rotation.z = 0; });
    return d;
  },
  fly: (pg, id) => {
    const c = pg.C(id), b = c.body, bs = pg.base(c), d = 2.6 * slow();
    pg.tween(d, (t) => { const a = easeInOut(t) * Math.PI * 2; b.position.set(bs.x + Math.sin(a) * 0.06, bs.y + (1 - Math.cos(a)) * 0.03, bs.z + Math.sin(a * 2) * 0.01); }, () => b.position.set(bs.x, bs.y, bs.z));
    return d;
  },
  slideLeft: (pg, id) => slideToggle(pg, id, -0.1),
  slideRight: (pg, id) => slideToggle(pg, id, 0.1),
  rise: (pg, id) => pg.rise(id, -pg.C(id).h * 0.6, 0.85),
  // ドアのように ひらく（もう一度で しまる）。ちょうつがいは "pivot": "left"（左の はし）か "right"（右の はし）。
  // どちらも 手前（へやの中）に ひらく
  // ひらく／しめる（"pivot": "left" / "right" の ドア）。へやの ドアは 外へ（かべの むこうへ）ひらく。
  // "opens": "in" の 絵（たんす・れいぞうこ・とだな・はこ）は 手前へ ひらく。
  // 外へ ひらく ドアは、うしろに 立つ 外の けしき（"depth" の 絵）に ぶつからない ところまで ひらく
  open: (pg, id) => {
    const c = pg.C(id), b = c.body, from = b.rotation.y, right = c.m.pivot === 'right';
    let to = 0;
    if (Math.abs(from) < 0.1) {
      if (c.m.opens === 'in') to = right ? 1.45 : -1.45;
      else {
        let a = 1.3;
        for (const k of Object.values(pg.cards)) {
          if (!k.m.depth || k.m.parent !== c.m.parent || k.m.x > c.m.x + c.m.w || k.m.x + k.m.w < c.m.x) continue;
          a = Math.min(a, Math.asin(Math.max(0.2, Math.min(1, (k.m.depth - 14) / Math.max(1, c.m.w)))));
        }
        to = right ? -a : a;
      }
    }
    pg.tween(1.1, (t) => { b.rotation.y = from + (to - from) * easeInOut(t); });
  },

  // ---- とびだす・でてくる ----
  // かくれていたものが ぽーんと とび出して、くるっと回って もとに もどる（おべんとうの おにぎり）
  popBack: (pg, id, hit, spec) => {
    const c = pg.C(id), b = c.body, bs = pg.base(c), was = c.hidden;
    pg.show(id);
    pg.tween(1.2, (t) => { b.position.y = bs.y + Math.sin(Math.PI * t) * 0.12 * pw(spec); b.rotation.z = easeInOut(t) * Math.PI * 2; },
      () => { b.position.y = bs.y; b.rotation.z = 0; if (was) pg.hide(id); });
    return 1.2;
  },
  // あなから 出てきて、少しして もどる（はと時計の はと）
  peek: (pg, id, hit, spec) => {
    const c = pg.C(id), b = c.body, bs = pg.base(c), was = c.hidden, k = pw(spec);
    pg.show(id);
    const at = (u) => { b.position.z = bs.z + 0.03 * k * u; b.position.y = bs.y + 0.012 * k * u; };
    pg.tween(0.5, (t) => at(easeInOut(t)));
    pg.later(1200, () => pg.tween(0.45, (t) => at(1 - easeInOut(t)), () => { b.position.set(bs.x, bs.y, bs.z); if (was) pg.hide(id); }));
    return 1.65;
  },
  // 手前に 出てくる／もどる（ひきだし）
  pullOut: (pg, id, hit, spec) => {
    const c = pg.C(id), b = c.body, bs = pg.base(c), z = 0.045 * pw(spec);
    pg.tween(0.5, (t) => { const k = easeInOut(t); b.position.z = bs.z + z * k; b.position.y = bs.y - 0.004 * k; });
    return 0.5;
  },
  pushIn: (pg, id) => {
    const c = pg.C(id), b = c.body, bs = pg.base(c), z0 = b.position.z, y0 = b.position.y;
    pg.tween(0.4, (t) => { const k = easeInOut(t); b.position.z = z0 + (bs.z - z0) * k; b.position.y = y0 + (bs.y - y0) * k; }, () => b.position.set(bs.x, bs.y, bs.z));
    return 0.4;
  },
  // 上から 落ちてきて、ぽんぽん はねる
  dropIn: (pg, id, hit, spec) => {
    const c = pg.C(id), b = c.body, bs = pg.base(c), h = 0.25 * pw(spec);
    pg.show(id);
    const bounce = (t) => { const n = 7.5625, d = 2.75; if (t < 1 / d) return n * t * t; if (t < 2 / d) return n * (t -= 1.5 / d) * t + 0.75; if (t < 2.5 / d) return n * (t -= 2.25 / d) * t + 0.9375; return n * (t -= 2.625 / d) * t + 0.984375; };
    pg.tween(1.3, (t) => { b.position.y = bs.y + h * (1 - bounce(t)); }, () => { b.position.y = bs.y; });
    return 1.3;
  },

  // ---- とぶ・ころぶ・ぶつかる ----
  // とび立って、ひとまわりして もどってくる（カラス・ちょう）
  flyOff: (pg, id, hit, spec) => {
    const c = pg.C(id), b = c.body, bs = pg.base(c), k = dirOf(spec, faceOf(pg, id)), p = pw(spec);
    pg.tween(2.2, (t) => {
      const u = Math.sin(Math.PI * t);
      b.position.set(bs.x + k * u * 0.08 * p, bs.y + u * 0.09 * p, bs.z + u * 0.05);
      b.rotation.z = Math.sin(t * Math.PI * 8) * 0.1 * u;   // ぱたぱた
    }, () => { b.position.set(bs.x, bs.y, bs.z); b.rotation.z = 0; });
    return 2.2;
  },
  // 前へ ぴょーんと とんで もどる（カエル）
  leap: (pg, id, hit, spec) => {
    const c = pg.C(id), b = c.body, bs = pg.base(c), k = dirOf(spec, faceOf(pg, id)), p = pw(spec);
    pg.tween(0.8, (t) => { const u = Math.sin(Math.PI * t); b.position.y = bs.y + u * 0.07 * p; b.position.x = bs.x + k * u * 0.03 * p; }, () => b.position.set(bs.x, bs.y, bs.z));
    return 0.8;
  },
  // "with" の絵と ゴツンと ぶつかる（2つが よって、はなれる）
  bonk: (pg, id, hit, spec) => {
    const a = pg.C(id), o = other(pg, spec), oc = o && pg.C(o), ba = pg.base(a), bo = oc && pg.base(oc);
    const k = oc ? Math.sign(oc.pvx - a.pvx) || 1 : dirOf(spec, 1), d = 0.035 * pw(spec);
    // よって（0.35 秒で ゴツン）→ はなれる（0.4 秒）
    pg.tween(0.75, (t) => {
      const u = t < 0.47 ? easeInOut(t / 0.47) : 1 - easeInOut((t - 0.47) / 0.53);
      a.body.position.x = ba.x + k * u * d; if (oc) oc.body.position.x = bo.x - k * u * d;
    }, () => { a.body.position.x = ba.x; if (oc) oc.body.position.x = bo.x; });
    pg.later(350, () => pg.burst(oc ? pg.top(id, 0.85).lerp(pg.top(o, 0.85), 0.5) : pg.top(id, 0.85), 14, 1, ['#ffe36b', '#ffffff']));
    return 0.8;
  },
  // ドテッと ころぶ（たおれたまま）／おきあがる／ころんで 少しして おきあがる
  tumble: (pg, id, hit, spec) => fall(pg, id, dirOf(spec, faceOf(pg, id))),
  getUp: (pg, id) => getUp(pg, id),
  trip: (pg, id, hit, spec) => { fall(pg, id, dirOf(spec, faceOf(pg, id))); pg.later(1500, () => getUp(pg, id)); return 2.1; },
  // 前に かたむく／もどる（いわを おす）
  lean: (pg, id, hit, spec) => {
    const b = pg.C(id).body, from = b.rotation.z, to = -0.1 * dirOf(spec, 1) * pw(spec);
    pg.tween(0.45, (t) => { b.rotation.z = from + (to - from) * easeInOut(t); });
    return 0.45;
  },
  unlean: (pg, id) => {
    const b = pg.C(id).body, from = b.rotation.z;
    pg.tween(0.45, (t) => { b.rotation.z = from * (1 - easeInOut(t)); });
    return 0.45;
  },

  // ---- ずれる・ながれる・ふるえる ----
  // ググッと 少し ずれる。もう一度で もどる（小石）
  nudge: (pg, id, hit, spec) => {
    const c = pg.C(id), b = c.body, bs = pg.base(c), dx = 0.014 * dirOf(spec, 1) * pw(spec);
    const out = Math.abs(b.position.x - bs.x) > Math.abs(dx) / 2, from = b.position.x, to = out ? bs.x : bs.x + dx;
    pg.tween(0.65, (t) => { b.position.x = from + (to - from) * easeInOut(t); b.rotation.z = Math.sin(t * Math.PI) * -0.08 * Math.sign(dx || 1); }, () => { b.rotation.z = 0; });
    return 0.65;
  },
  // もくもく ふくらみながら、ゆっくり ながれていって、また ゆっくり もどってくる（けむり・くも）
  drift: (pg, id, hit, spec) => {
    const c = pg.C(id), b = c.body, bs = pg.base(c), k = dirOf(spec, faceOf(pg, id)), p = pw(spec);
    pg.tween(4.0, (t) => {
      const u = Math.sin(Math.PI * t);
      const s = 1 + 0.2 * p * u; b.scale.set(s, s, 1);
      b.position.x = bs.x + k * 0.08 * p * (1 - Math.cos(Math.PI * 2 * t)) / 2;
    }, () => { b.scale.set(1, 1, 1); b.position.x = bs.x; });
    return 4.0;
  },
  // コンコン：ゆっくり 2回 かたむいて もどる（家・きりかぶ・とびらを たたく。shake より ゆっくり 大きめ）
  knock: (pg, id, hit, spec) => {
    const c = pg.C(id), b = c.body, bs = pg.base(c), p = pw(spec) * small();
    pg.tween(1.0, (t) => {
      const k = Math.sin(Math.PI * ((t * 2) % 1));   // two bumps, 0.5 s each
      b.rotation.z = -0.03 * p * k; b.position.x = bs.x + 0.007 * p * k;
    }, () => { b.rotation.z = 0; b.position.x = bs.x; });
    return 1.0;
  },
  // こまかく ふるえる（コオロギ・こわい）
  shiver: (pg, id, hit, spec) => {
    const c = pg.C(id), b = c.body, bs = pg.base(c), a = 0.004 * pw(spec);
    pg.tween(1.2, (t) => { b.position.x = bs.x + Math.sin(t * Math.PI * 14) * a * Math.sin(Math.PI * t); }, () => { b.position.x = bs.x; });
    return 1.2;
  },

  // ---- 気持ち ----
  // うんうん（うなずく）
  nod: (pg, id, hit, spec) => {
    const b = pg.C(id).body, p = pw(spec);
    pg.tween(1.1, (t) => { b.rotation.x = Math.max(0, Math.sin(t * Math.PI * 2)) * 0.28 * p; }, () => { b.rotation.x = 0; });
    return 1.1;
  },
  // いやいや（首を よこに ふる）
  shakeHead: (pg, id, hit, spec) => {
    const b = pg.C(id).body, p = pw(spec);
    pg.tween(1.2, (t) => { b.rotation.y = Math.sin(t * Math.PI * 4) * 0.35 * p * Math.sin(Math.PI * t); }, () => { b.rotation.y = 0; });
    return 1.2;
  },
  // ぺこり（おじぎ）
  bow: (pg, id, hit, spec) => {
    const b = pg.C(id).body, p = pw(spec);
    pg.tween(1.5, (t) => { b.rotation.x = Math.sin(Math.PI * t) * 0.5 * p; }, () => { b.rotation.x = 0; });
    return 1.5;
  },
  // うろうろ（いったり きたり）
  pace: (pg, id, hit, spec) => {
    const c = pg.C(id), b = c.body, bs = pg.base(c), p = pw(spec);
    pg.tween(2.8, (t) => {
      b.position.x = bs.x + Math.sin(t * Math.PI * 4) * 0.035 * p;
      b.position.y = bs.y + Math.abs(Math.sin(t * Math.PI * 12)) * 0.008;
    }, () => { b.position.x = bs.x; b.position.y = bs.y; });
    return 2.8;
  },

  // ---- はずむ ----
  // びよーんと のびて ちぢむ
  stretch: (pg, id, hit, spec) => {
    const b = pg.C(id).body, p = pw(spec);
    pg.tween(1.1, (t) => {
      const e = Math.sin(t * Math.PI * 3) * (1 - t) * 0.3 * p;
      b.scale.set(1 - e * 0.5, 1 + e, 1);
    }, () => b.scale.set(1, 1, 1));
    return 1.1;
  },

  // ---- つみき ----
  // 上に つんだ絵（parent を この絵にした絵）が ガラガラ くずれて、少しして つみなおす
  crumble: (pg, id) => {
    const base = pg.C(id), kids = Object.values(pg.cards).filter((c) => c.m.parent === id && !c.hidden);
    pg.wobble(id, 0.05, 0.7);
    kids.forEach((c, i) => {
      const b = c.body, bs = pg.base(c), up = c.pivotHome.y;              // how high it stands on the base
      const side = c.pvx >= base.pvx ? 1 : -1, dx = side * (0.02 + 0.018 * i + Math.random() * 0.01);
      const rot = -side * (0.5 + Math.random() * 0.9);
      pg.tween(0.7, (t) => {
        b.position.x = bs.x + dx * t;
        b.position.y = bs.y - up * t * t + Math.sin(Math.PI * t) * 0.015;
        b.rotation.z = rot * t;
      });
      pg.later(1800 + i * 220, () => {
        const x0 = b.position.x, y0 = b.position.y, r0 = b.rotation.z;
        pg.tween(0.6, (t) => {
          const k = easeInOut(t);
          b.position.x = x0 + (bs.x - x0) * k; b.position.y = y0 + (bs.y - y0) * k + Math.sin(Math.PI * t) * 0.03; b.rotation.z = r0 * (1 - k);
        }, () => { b.position.set(bs.x, bs.y, bs.z); b.rotation.z = 0; });
      });
    });
    return 1.8 + kids.length * 0.22 + 0.65;
  },
  none: () => {},
};
function slideToggle(pg, id, dx) {
  const c = pg.C(id), bs = pg.base(c);
  pg.moveTo(id, Math.abs(bs.x) > 0.01 ? 0 : dx, undefined, undefined, 1.0, easeInOut);   // ゆっくり すべって とまる
  return 1.0;
}
function fall(pg, id, k) {
  const c = pg.C(id), b = c.body, bs = pg.base(c), r0 = b.rotation.z;
  pg.tween(0.8, (t) => { b.rotation.z = r0 + (-0.7 * k - r0) * Math.sin(Math.PI * t * 0.5); b.position.x = bs.x + 0.05 * k * t; b.position.y = bs.y + Math.sin(Math.PI * t) * 0.03; });
  return 0.8;
}
function getUp(pg, id) {
  const c = pg.C(id), b = c.body, bs = pg.base(c), r0 = b.rotation.z, x0 = b.position.x;
  pg.tween(0.6, (t) => { const k = easeInOut(t); b.rotation.z = r0 * (1 - k); b.position.x = x0 + (bs.x - x0) * k; }, () => { b.rotation.z = 0; b.position.x = bs.x; });
  return 0.6;
}

// how long each move takes (seconds), and the moves that look broken when restarted halfway:
// a touch with one of these can't be touched again until the move has finished (unless "wait" says otherwise)
const MOVE_TIME = { hop: 0.7, bigHop: 0.8, jump2: 1.1, wobble: 1.1, shake: 0.9, spin: 1.2, turn: 1.2, pulse: 0.7, swing: 2.0, topple: 1.4, roll: 1.7, fly: 2.6, slideLeft: 1.0, slideRight: 1.0, rise: 0.85, open: 1.1, none: 0 };
const LONG_MOVES = ['spin', 'turn', 'swing', 'topple', 'roll', 'fly', 'slideLeft', 'slideRight', 'rise', 'open'];
const autoWait = (spec) => (spec.move && LONG_MOVES.includes(spec.move) ? MOVE_TIME[spec.move] * (['spin', 'turn', 'roll', 'fly'].includes(spec.move) ? slow() : 1) + 0.05 : 0);

// ---------- effects ----------
export const EFFECTS = {
  sparkle: (pg, id) => pg.burst(id, 16, 1),
  leaves: (pg, id) => pg.leaves(pg.top(id, 0.7), 12),
  petals: (pg, id) => pg.leaves(pg.top(id, 0.7), 12, ['#ffc1d4', '#fff3f6', '#ffd1e1']),
  steam: (pg, id) => pg.puff(pg.top(id, 0.85), 14, '#ffffff', 0.02, 0.15, 0.04),
  bubbles: (pg, id) => pg.puff(pg.top(id, 0.9), 16, '#e8f8ff', 0.01, 0.18, 0.018),
  ripple: (pg, id, hit) => pg.ripple(hit ? hit.point : pg.top(id, 0.3)),
  firework: (pg, id) => {
    const p = pg.top(id, 1.0); const target = p.clone().add(pg.up.clone().multiplyScalar(0.25));
    pg.firework(target, fireworkColor(id), '#ffffff', 'peony', p);
  },
  glow: (pg, id) => {
    const c = pg.C(id);
    if (c.glowing) { c.glowFlash = pg.time; return; } // already glowing all the time ("glow": true): a bright flash
    addHalo(pg, id, Math.max(0.08, Math.min(0.2, c.w * 1.4)));
    c.halo.visible = true;
    pg.tween(2.2, (t) => { blinkHalo(c, pg.time); c.halo.material.opacity *= Math.min(1, t * 6, (1 - t) * 6); }, () => { c.halo.visible = false; });
  },
};

// ---------- one touch reaction ----------
// spec: { move, sound, word, color, say, who, swap, back, effect, show, hideAfter, mark, walk, light, reveal,
//         get, need, if, else, remember, on, then, wait, lock }
//   wait: seconds it can't be touched again (0 = any time). Without it, it can't be touched until everything has finished.
//   lock: a name; everything with the same lock name waits together.
//   on:   another piece does this reaction ("on": "pendulum" — touching the clock swings the pendulum)
//   then: what happens next, after "delay" seconds: { "delay": 1.5, "on": "dove", "show": "dove" } or a list of steps
//         (each step's delay counts from the step before it)
// opts.free: no waiting at all (used by the games, where tapping again is part of the play)
// opts.idx:  the counter used to take turns through lists of words / lines (default: the piece id)
// a move by name: the kit's moves, or this page's own moves (script.js "moves")
export const moveOf = (pg, name) => (pg.logic && pg.logic.moves && pg.logic.moves[name]) || MOVES[name];
// how long a reaction (and everything after it) keeps going, as far as the kit knows the moves
function seqTime(spec) {
  let t = 0, end = autoWait(spec);
  for (const st of [].concat(spec.then || [])) { t += st.delay || 0; end = Math.max(end, t + seqTime(st)); }
  return end;
}
export function react(pg, id, spec, hit, opts = {}) {
  if (!spec) return;
  if (!pg.C(id)) return;
  // "need": "key" (in the bag) / "if": { "gift": "cake" } (what was chosen, counted, …) / "give": "dango" (in the bag,
  // and handed over) — otherwise "else" (or nothing)
  if ((spec.need || spec.if || spec.give) && (!holds(spec, pg) || (spec.give && !has(spec.give)))) { if (spec.else) react(pg, id, spec.else, hit, { ...opts, idx: `${opts.idx || id}:else` }); return; }
  const key = `touch:${spec.lock || id}`;
  const lockKey = opts.lockKey || (!opts.free && typeof spec.wait !== 'number' ? key : null);
  if (!opts.free) {
    if (pg.isBusy(key)) return; // still moving: only the paw print shows
    const wait = typeof spec.wait === 'number' ? spec.wait : seqTime(spec);
    if (wait > 0) pg.busy(key, wait);
  }
  const target = spec.on && pg.C(spec.on) ? spec.on : id;
  const took = act(pg, target, spec, hit, opts.idx || id);
  if (lockKey && took > 0) pg.busy(lockKey, took + 0.05);   // a move that told how long it takes (a page's own move, walking)
  let t = 0;
  [].concat(spec.then || []).forEach((st, k) => {
    t += st.delay || 0;
    pg.later(t * 1000, () => react(pg, id, st, null, { free: true, idx: `${opts.idx || id}:then${k}`, lockKey }));
  });
}
// what one reaction does, on piece "id"; returns how long it keeps going when a move or walk says so
function act(pg, id, spec, hit, idxKey) {
  const c = pg.C(id); let took = 0;
  const who = spec.who || (isCast(id) ? id : null);
  const i = nextIdx(pg, `${idxKey}${id === idxKey ? '' : `>${id}`}`);
  // with a list of pictures ("swap": [ … ]), the words and lines go step by step with them and stay on the last one
  const step = Array.isArray(spec.swap) ? nextIdx(pg, `${idxKey}:swap`) : null;
  const at = (v) => (step === null || !Array.isArray(v) ? pick(v, i) : v[Math.min(step, v.length - 1)]);
  // "move": ["hop", "spin", "catJoy"] — a different move at each touch (in turn)
  const mv = spec.move && moveOf(pg, Array.isArray(spec.move) ? pick(spec.move, i) : spec.move);
  if (mv) { const r = mv(pg, id, hit, spec); if (typeof r === 'number') took = Math.max(took, r); }
  if (spec.sound) pg.sfx(spec.sound, who || id);
  if (spec.word) pg.ono(at(spec.word), hit && spec.wordAt === 'touch' ? hit.point : id, spec.color);
  // the bubble comes from the one who speaks ("who"), when that one is on this page
  const by = spec.who && spec.who !== id && pg.C(spec.who) ? spec.who : id;
  if (spec.say) pg.say(by, at(spec.say), by, who || id);
  // "swap": ["3", "2", "1", "0"] — a different picture at each touch, staying on the last one
  // "swap": "base" — back to its own picture
  if (Array.isArray(spec.swap)) pg.swap(id, altKey(pg, id, at(spec.swap)));
  else if (spec.swap) {
    const main = c.m.tex[0], alt = spec.swap === 'base' ? main : altKey(pg, id, spec.swap);
    const showing = pg.texOf(id) !== main;
    if (spec.back === 0 || spec.back === 'toggle') pg.swap(id, showing ? main : alt);
    else if (spec.back === false) { clearTimeout(c._backT); pg.swap(id, alt); }   // stays
    else {
      pg.swap(id, alt);
      clearTimeout(c._backT); c._backT = pg.later((spec.back || 2.5) * 1000, () => pg.swap(id, main));
    }
  }
  if (spec.effect && EFFECTS[spec.effect]) EFFECTS[spec.effect](pg, id, hit);
  if (spec.show && pg.C(spec.show) && pg.C(spec.show).hidden) {
    pg.rise(spec.show, -pg.C(spec.show).h, 0.85);
    if (spec.hideAfter) pg.later(spec.hideAfter * 1000, () => pg.hide(spec.show));
  }
  if (spec.mark) pg.mark(id, pick(spec.mark, i));
  // "walk": [[x, y], …] page pixels; the next touch walks back home (it can't be touched while walking)
  if (spec.walk && canTravel(pg, id)) {
    const w = Array.isArray(spec.walk) ? { points: spec.walk } : spec.walk;
    took = Math.max(took, walk(pg, id, w.points, { flip: !!w.flip, back: true }) || 0);
  }
  // "light": true (this one) / "window" / ["w1", "w2"]: lights turn on, and off the next time
  if (spec.light) (spec.light === true ? [id] : [].concat(spec.light)).forEach((l) => pg.C(l) && light(pg, l, !pg.C(l).lit));
  // "reveal": "kitten" — the box opens and the hidden kitten jumps out to its own place
  if (spec.reveal) reveal(pg, id, spec.reveal);
  // "get": "key" — into the bag (もちもの);  "remember": { "gift": "cake" } — remembered for later pages
  if (spec.get) pg.getItem(spec.get);
  // "give": "dango" — handed over to this one (it leaves the bag);  "join": "kitten" — comes along to the next pages
  if (spec.give && giveItem(spec.give)) handOver(pg, spec.give, id);
  if (spec.join) join(spec.join);
  if (spec.remember) for (const [k, v] of Object.entries(spec.remember)) remember(k, v, itemOf(v).name);
  return took;
}

// ---------- page narration from the story lines ----------
// story item: "text"  or  { "text": "...", "read": "...", "act": "ma:hop" }
function parseAct(a) {
  if (!a) return [];
  return (Array.isArray(a) ? a : [a]).map((x) => (typeof x === 'string' ? { id: x.split(':')[0], move: x.split(':')[1] || 'hop' } : x));
}
function defaultNarration(pg, def) {
  return (def.story || []).map((s, line) => {
    const item = typeof s === 'string' ? { text: s } : s;
    const acts = parseAct(item.act);
    return { text: item.text, line, voice: voice('n'), onstart: acts.length ? () => acts.forEach((a, k) => pg.later(400 + k * 400, () => pg.C(a.id) && moveOf(pg, a.move) && moveOf(pg, a.move)(pg, a.id))) : null };
  });
}

// "progress": { "label": "...", "cast": true } → one dot per character, in their colours
function castProgress(p) {
  if (p && p.cast) { const ids = castIds(); return { ...p, colors: ids.map(markColor), total: p.total || ids.length }; }
  return p;
}

// ---------- what other pages left behind ----------
// hidden pieces with "if" / "need" come out when it holds (なかま, かぞえた数, もちもの …);
// pieces that are shown, with "if" / "need", are not there when it does not hold (もっていない おべんとう・金魚の ふくろ …);
// pieces wear the look chosen on another page (dressup with "keep": true)
// pictures with "need" / "if": shown or hidden at once, as things are now (after もどす the page is not opened again)
function whenNow(pg) {
  for (const c of Object.values(pg.cards)) {
    const w = c.m.when; if (!w) continue;
    if (!c.m.hidden) { if (holds(w)) pg.show(c.id); else pg.hide(c.id); }
    else if (holds(w)) pg.show(c.id);
  }
}
// the page is being shown: printed pictures with "need" / "if" are there or not before it stands up (no flicker)
function whenHide(pg) {
  for (const c of Object.values(pg.cards)) { const w = c.m.when; if (w && !c.m.hidden) { if (!holds(w)) pg.hide(c.id); else if (c.hidden) pg.show(c.id); } }
}
function pageOpen(pg) {
  let k = 0;
  for (const c of Object.values(pg.cards)) {
    const w = c.m.when;
    if (w && !c.m.hidden) { if (holds(w)) { if (c.hidden) pg.show(c.id); } else pg.hide(c.id); continue; }
    if (w && c.hidden && holds(w)) pg.later(200 + k++ * 220, () => { if (c.hidden) { pg.rise(c.id, -c.h, 0.85); pg.later(600, () => pg.burst(c.id, 10, 0.8, ['#fff2a8', '#ffffff'])); } });
    if (c.id in MEM.looks) { const look = MEM.looks[c.id], key = look ? `${c.id}@${look}` : c.m.tex[0]; if (pg.tex[key] && pg.texOf(c.id) !== key) pg.swap(c.id, key); }
  }
}

// ---------- build the page logic ----------
export function makeLogic(def, script) {
  script = script || {};
  const g = def.goal && GOALS[def.goal.type] ? def.goal : null;
  const G = g ? GOALS[g.type] : null;
  const touch = def.touch || {};
  const ambient = {};
  // "after": the reaction once the page is cleared (instead of the one before)
  for (const [id, spec] of Object.entries(touch)) ambient[id] = (pg, hit) => (pg.done && spec.after ? react(pg, id, spec.after, hit, { idx: `${id}:after` }) : react(pg, id, spec, hit));
  const L = {
    name: def.name ?? script.name ?? '',
    hint: def.hint ?? script.hint ?? (g ? goalHint(g) : 'いろいろ さわってみてね'),
    progress: castProgress(def.progress !== undefined ? def.progress : (script.progress !== undefined ? script.progress : (g ? goalProgress(g) : null))),
    twinkle: def.twinkle ?? script.twinkle,
    twinkleArea: def.twinkleArea ?? script.twinkleArea,
    sky: !!(def.skyFireworks || script.sky),
    maxParticles: def.maxParticles ?? script.maxParticles,
    moves: script.moves || {},  // this page's own moves (script.js), usable as "move" in page.json
    weather: def.weather,       // snow / rain / petals / leaves / fireflies / bubbles / stars
    ambience: def.ambience,     // a quiet sound all the time: waves / wind / rain / stream / insects / birds / fire
    dark: def.dark || 0,        // the page starts darker (0 … 0.6)
    init(pg) {
      pg.gs = {};
      if (pg._opened) whenNow(pg);   // (もどす: the page is not opened again)
      if (G) { G.init(pg, g); const p = L.progress; if (p) pg.progress(0, p.total || 0); }
      if (script.init) script.init(pg);
    },
    update(pg, dt) {
      if (G) goalUpdate(pg, g, dt);
      if (script.update) script.update(pg, dt);
    },
    // story time is over: the games that start now (a question, things popping up), and the hint clock
    play(pg) {
      pg.gs.lastMove = pg.time;
      if (G && G.play) G.play(pg, g);
      if (script.play) script.play(pg);
    },
    // a finger pressed on a piece: true when the game wants the finger's movement ("rub")
    grab(id, pg, hit) { return !!(G && G.grab && G.grab(pg, g, id, hit)); },
    rub(id, pg, hit, px) { if (G && G.rub) G.rub(pg, g, id, hit, px); },
    release(id, pg, hit) { if (G && G.release) G.release(pg, g, id, hit); },
    tap(id, pg, hit) {
      if (script.tap && script.tap(id, pg, hit)) return true;
      if (G && G.tap(pg, g, id, hit)) return true;
      if (def.skyFireworks && (id === 'sky' || (id === 'plate' && hit.point.y > -0.02))) {
        const ids = castIds(); const col = ids.length ? fireworkColor(ids[Math.floor(Math.random() * ids.length)]) : '#ffd84a';
        const target = id === 'sky' ? hit.point.clone() : hit.point.clone().add(pg.up.clone().multiplyScalar(0.22));
        pg.firework(target, col, '#ffffff', 'peony', new THREE.Vector3(target.x, -0.08, 0.01), () => pg.ono(Math.random() < 0.5 ? 'ドーン！' : 'パーン！', target.clone().add(pg.up.clone().multiplyScalar(0.08)), col));
        return true;
      }
      return false;
    },
    ambient: { ...ambient, ...(script.ambient || {}) },
    narration(pg) { return script.narration ? script.narration(pg) : defaultNarration(pg, def); },
    opening(pg) { whenHide(pg); },
    // the page is shown (again): what other pages left behind comes out, then the game and the page's own script
    open(pg) {
      pg._opened = true;
      pageOpen(pg);
      if (G && G.open) G.open(pg, g);
      if (script.open) script.open(pg);
    },
  };
  return L;
}
