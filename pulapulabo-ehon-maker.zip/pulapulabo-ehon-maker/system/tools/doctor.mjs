// npm run doctor — このパソコン（または AI の作業場所）で キットの道具が 動くかを たしかめる
//   Node.js の版・道具（node_modules）・絵の変換・SVG の絵・プログラムのまとめ（esbuild）・PDF
import fs from 'node:fs';
import { rel } from './lib/common.mjs';

const ok = [], ng = [];
const test = async (name, fn, help) => {
  try { await fn(); ok.push(name); console.log(`  ✅ ${name}`); }
  catch (e) { ng.push(name); console.log(`  ❌ ${name}: ${String(e && e.message || e).split('\n')[0]}`); if (help) console.log(`     → ${help}`); }
};
console.log('\n🩺 キットの道具を たしかめます');
const major = +process.versions.node.split('.')[0];
await test(`Node.js ${process.versions.node}（20 以上）`, () => { if (major < 20) throw new Error('古い版です'); }, 'Node.js 20 以上を入れてください（guide/02 の準備）');
const hasModules = fs.existsSync(rel('node_modules', 'sharp'));
await test('道具（node_modules）が ある', () => { if (!hasModules) throw new Error('まだ 入っていません'); }, 'npm ci を実行します（ネットが いります）。ChatGPT では「ChatGPT 用（道具入り）」の ZIP を使います');
if (hasModules) {
  await test('絵の変換（sharp）', async () => { const sharp = (await import('sharp')).default; await sharp({ create: { width: 4, height: 4, channels: 4, background: '#ff0000' } }).png().toBuffer(); },
    'この場所の しくみ（OS・CPU）に 合う道具が ありません。npm ci で入れなおします');
  await test('SVG の絵（resvg）', async () => { const { Resvg } = await import('@resvg/resvg-js'); new Resvg('<svg xmlns="http://www.w3.org/2000/svg" width="4" height="4"><rect width="4" height="4" fill="red"/></svg>').render().asPng(); },
    'この場所の しくみに 合う道具が ありません。npm ci で入れなおします');
  await test('プログラムを まとめる（esbuild）', async () => { const esbuild = await import('esbuild'); await esbuild.transform('let a = 1', {}); },
    'chmod +x node_modules/@esbuild/*/bin/esbuild を ためすか、npm ci で入れなおします');
  await test('PDF（pdf-lib）', async () => { const { PDFDocument } = await import('pdf-lib'); await (await PDFDocument.create()).save(); });
}
console.log(ng.length ? `\n${ng.length}こ 動かない ものが あります。上の → を ためしてください。\n` : '\n✅ ぜんぶ 動きます。npm run build で 絵本が 作れます。\n');
process.exit(ng.length ? 1 : 0);
