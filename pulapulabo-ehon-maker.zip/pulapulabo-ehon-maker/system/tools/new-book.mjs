// npm run new-book -- my-book   → copies the sample (books/sample-svg) to books/my-book and makes it the book to build
// The pictures can then be redrawn as SVG files, or replaced by PNG files from a drawing app (guide/03).
import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';
import { rel, args, exists, readJSON } from './lib/common.mjs';

const A = args();
// one line reader (answers typed or pasted ahead are kept in order)
let rl = null, waiting = null;
const lines = [];
function reader() {
  if (rl) return;
  rl = readline.createInterface({ input: process.stdin });
  rl.on('line', (l) => { if (waiting) { const w = waiting; waiting = null; w(l); } else lines.push(l); });
  rl.on('close', () => { if (waiting) { const w = waiting; waiting = null; w(''); } });
}
const ask = (q) => { reader(); process.stdout.write(q); if (lines.length) return Promise.resolve(lines.shift().trim()); return new Promise((r) => { waiting = (l) => r(String(l).trim()); }); };

let id = (A._ && A._[0]) || A.name;
if (!id && process.stdin.isTTY) id = await ask('\n  絵本の名前（半角の小文字・数字・- だけ。例: my-book）: ');
if (rl) rl.close();
if (!id || !/^[a-z0-9-]+$/.test(id)) {
  console.error('\n  使い方: npm run new-book -- my-book\n  （名前は 半角の小文字・数字・- だけ。この名前が GitHub のリポジトリ名と公開 URL にもなります）\n');
  process.exit(1);
}
const dst = rel('books', id);
if (exists(dst)) { console.error(`\n  books/${id} はもうあります。別の名前にしてください。\n`); process.exit(1); }
const from = typeof A.from === 'string' ? A.from : 'sample-svg';
if (!exists(rel('books', from))) { console.error(`\n  見本 books/${from} が見つかりません。\n`); process.exit(1); }

fs.cpSync(rel('books', from), dst, { recursive: true });   // everything: pages, cast/, items/, lang/, cover.svg, read.json
const bj = path.join(dst, 'book.json');
const b = readJSON(bj); b.title = 'あたらしい えほん'; b.subtitle = 'AR えほん';
// who made it and where it will be published are this book's own (written later in book.json)
if ('author' in b) b.author = '';
if ('github' in b) b.github = '';
delete b.url; delete b.date;
if (b.adultNote) b.adultNote = '';
// "languages", lang/ (the translations), cover.svg and items/ stay as in the sample, so building it unchanged
// makes the same book as the sample; draw / write them for your own book later (npm run check tells which are still the sample's)
fs.writeFileSync(bj, JSON.stringify(b, null, 2) + '\n');
// the new title and subtitle in the copied translations (so the copy builds without "訳のない文")
const NEW = { en: { [b.title]: 'A New Picture Book', [b.subtitle]: 'An AR picture book' }, pt: { [b.title]: 'Um Novo Livro Ilustrado', [b.subtitle]: 'Um livro ilustrado em RA' } };
for (const [l, words] of Object.entries(NEW)) {
  const f = path.join(dst, 'lang', `${l}.json`);
  if (!exists(f)) continue;
  const tr = readJSON(f);
  for (const [k, v] of Object.entries(words)) if (!tr[k]) tr[k] = v;
  fs.writeFileSync(f, JSON.stringify(tr, null, 2) + '\n');
}
fs.writeFileSync(rel('ar-book.config.json'), JSON.stringify({ book: id }, null, 2) + '\n');
console.log(`
  ✅ books/${id} を作りました（${from} のコピー）。
     これからは npm run build で この絵本が作られます（できあがりは publish/${id}/）。

  コピーしたもの: book.json・read.json・pages/・cast/（はじめる画面の絵）・items/（もちものの絵）・lang/（英語・ポルトガル語の訳）・cover.svg（表紙の絵）
  題名は「あたらしい えほん」、作者名と GitHub のアカウント名は空にしました。

  次にすること
    1. まず何も変えずに npm run build → npm run serve で、見本と同じものができるか確かめる
    2. guide/02_新しい絵本を作る.md を見ながら、book.json と pages/ の中を書きかえる
       絵は SVG のまま描きかえても、お絵かきアプリの PNG に置きかえてもかまいません（guide/03）
       見本の絵を下絵の PNG にするときは npm run png（guide/09）
    3. 表紙（cover.svg）・もちものの絵（items/）・はじめる画面の絵（cast/）も、この絵本に合わせて描きかえます
       英語・ポルトガル語の訳は、文章を書きかえたら npm run lang で足します（いらないときは book.json の "languages" を ["ja"] に）
`);
