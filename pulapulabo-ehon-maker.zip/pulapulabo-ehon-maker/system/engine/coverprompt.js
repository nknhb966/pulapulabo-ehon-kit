// 表紙を うつしたとき (camera only): a card over the printed cover that asks to turn to page 1.
// The card shows page 1 small, with an arrow at the paper's right edge that slowly shows the page turning. Nothing to touch.
// Sizes are in the cover's own units: the printed A4 cover is 1 wide and 2100 / 2970 high, centred on 0.
import * as THREE from 'three';
import { LANG, tr } from './lang.js';
import { easeInOut } from './fx.js';

export const COVER_LINES = ['ページを めくって、', 'この ページを うつしてね'];

const CW = 1280, CH = 600;                // the card's canvas
const W = 0.56, H = W * CH / CW;          // the card over the cover picture
const X = -0.02, Y = 0.03, Z = 0.025;      // its centre (a little above the paper)
const ARROW = 0.13, AX0 = 0.41, AX1 = 0.33, AY = 0.03;   // the arrow slides from AX0 to AX1, then starts again
const IN = 0.7, BOB = 2.6, LOOP = 2.4;     // seconds: the card comes up, floats up and down, one arrow sweep

function rrect(g, x, y, w, h, r) {
  g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
}
const plane = (w, h) => new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ transparent: true, depthWrite: false, opacity: 0 }));

// the arrow: an arc from the right to the left, like the page being lifted and turned over
function drawArrow() {
  const c = document.createElement('canvas'); c.width = c.height = 256;
  const g = c.getContext('2d'); g.lineCap = 'round'; g.lineJoin = 'round';
  const path = () => { g.beginPath(); g.moveTo(212, 176); g.quadraticCurveTo(150, 30, 66, 128); };
  const head = () => { g.beginPath(); g.moveTo(40, 92); g.lineTo(56, 160); g.lineTo(104, 126); g.closePath(); };
  g.strokeStyle = '#fff8e8'; g.lineWidth = 46; path(); g.stroke(); g.lineWidth = 18; head(); g.stroke(); g.fillStyle = '#fff8e8'; g.fill();
  g.strokeStyle = '#e8756a'; g.lineWidth = 26; path(); g.stroke(); g.fillStyle = '#e8756a'; head(); g.fill();
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

export class CoverPrompt {
  constructor({ thumb, font }) {
    this.font = font;
    this.group = new THREE.Group();
    this.card = plane(W, H); this.card.position.set(X, Y, Z); this.card.renderOrder = 3;
    this.arrow = plane(ARROW, ARROW); this.arrow.position.set(AX0, AY, Z); this.arrow.renderOrder = 3;
    this.arrow.material.map = drawArrow();
    this.group.add(this.card, this.arrow);
    this.canvas = document.createElement('canvas'); this.canvas.width = CW; this.canvas.height = CH;
    this.tex = new THREE.CanvasTexture(this.canvas); this.tex.colorSpace = THREE.SRGBColorSpace;
    this.card.material.map = this.tex;
    this.img = new Image(); this.img.onload = () => this.draw(); if (thumb) this.img.src = thumb;
    this.t = 0; this.drawn = null;
  }
  // the words to say (the same as on the card)
  text(lang) { return COVER_LINES.map((l) => tr(l, lang)).join(' '); }
  // the card comes up again (each time the cover is found after it was lost)
  show() { if (this.drawn !== LANG.now) this.draw(); this.t = 0; this.update(0); }
  draw() {
    const g = this.canvas.getContext('2d'); g.clearRect(0, 0, CW, CH);
    rrect(g, 14, 14, CW - 28, CH - 28, 56); g.fillStyle = '#fff8e8'; g.fill(); g.lineWidth = 14; g.strokeStyle = '#e9c47a'; g.stroke();
    g.save(); g.setLineDash([22, 16]); g.globalAlpha = 0.6; rrect(g, 44, 44, CW - 88, CH - 88, 36); g.lineWidth = 5; g.stroke(); g.restore();
    // page 1, small, a little tilted, with its number
    const tw = 440, th = 330, tx = 64, ty = (CH - th) / 2;
    g.save(); g.translate(tx + tw / 2, ty + th / 2); g.rotate(-0.05);
    g.fillStyle = 'rgba(60,40,80,0.18)'; g.fillRect(-tw / 2 + 10, -th / 2 + 14, tw, th);
    g.fillStyle = '#ffffff'; g.fillRect(-tw / 2 - 12, -th / 2 - 12, tw + 24, th + 24);
    if (this.img.complete && this.img.naturalWidth) g.drawImage(this.img, -tw / 2, -th / 2, tw, th);
    g.beginPath(); g.arc(-tw / 2 + 4, -th / 2 + 4, 42, 0, Math.PI * 2); g.fillStyle = '#e8756a'; g.fill(); g.lineWidth = 8; g.strokeStyle = '#fff3d9'; g.stroke();
    g.fillStyle = '#fff8e8'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = `900 50px ${this.font}`; g.fillText('1', -tw / 2 + 4, -th / 2 + 7);
    g.restore();
    // the words: the biggest letters that let each line fit
    const lines = COVER_LINES.map((l) => tr(l)), x0 = tx + tw + 50, maxW = CW - x0 - 60;
    let fs = 72;
    for (; fs > 30; fs -= 2) { g.font = `900 ${fs}px ${this.font}`; if (lines.every((l) => g.measureText(l).width <= maxW)) break; }
    g.textAlign = 'left'; g.textBaseline = 'middle'; g.fillStyle = '#3b2e5a';
    const lh = fs * 1.45;
    lines.forEach((l, i) => g.fillText(l, x0, CH / 2 + (i - (lines.length - 1) / 2) * lh));
    this.tex.needsUpdate = true; this.drawn = LANG.now;
  }
  // the card comes up softly, then floats; the arrow sweeps from the right edge to the left, over and over
  update(dt) {
    this.t += dt;
    const k = easeInOut(Math.min(1, this.t / IN));
    const s = 0.86 + 0.14 * k;
    this.card.scale.set(s, s, 1); this.card.material.opacity = k;
    this.card.position.z = Z + 0.004 * Math.sin((Math.PI * 2 * this.t) / BOB);
    const u = (this.t % LOOP) / LOOP;
    this.arrow.position.x = AX0 + (AX1 - AX0) * easeInOut(u);
    this.arrow.material.opacity = k * Math.sin(Math.PI * u);
  }
}
