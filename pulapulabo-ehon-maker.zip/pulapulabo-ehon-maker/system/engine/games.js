// More page games ("goal" in page.json), next to the ones in goals.js:
//   carry : はこぶ — move "items" with a finger to where they go ("to")
//   copy  : まねっこ — the "targets" shine in turn; touch them in the same order
//   pairs : ペアさがし — turn the "cards" two at a time and find the same pictures
//   hold  : ながおし — keep pressing the "target" (a balloon gets big, a fishing rod pulls up …)
//   trace : なぞって つなぐ — go along the "points" with a finger (or touch them in turn) and draw the shape
// The numbers that depend on the readers' age come from book.js AGE (copyRounds, holdSeconds).
import * as THREE from 'three';
import { CALM } from './book.js';
import { react, pick, nextIdx, altKey } from './presets.js';
import { goalDone, param, progressed } from './goals.js';
import { setCount } from './story.js';
import { easeInOut } from './fx.js';

const PX = 1 / 1600, PH = 0.75;
const pagePoint = ([x, y]) => new THREE.Vector3(x * PX - 0.5, PH / 2 - y * PX, 0);
const near2 = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const groundOf = (hit) => (hit ? hit.ground || hit.point : null);
const toldOnce = (pg, key, text, ms = 2600) => { if (pg.gs[key]) return; pg.gs[key] = true; pg.toast(text, ms); };

// ---------- texts, progress dots and hints for these games ----------
export function moreHint(g) {
  switch (g.type) {
    case 'carry': return 'ゆびで おして はこんでね';
    case 'copy': return 'ひかった じゅんばんに タッチしてね';
    case 'pairs': return 'おなじ えを 2まい さがしてね';
    case 'hold': return 'ながく おしてね';
    case 'trace': return 'てんを じゅんばんに なぞってね';
    default: return null;
  }
}
export function moreProgress(g, dots) {
  switch (g.type) {
    case 'carry': return dots('はこんだ', g.items.length);
    case 'copy': return dots('できた', param(g, 'rounds', 'copyRounds').length);
    case 'pairs': return dots('ペア', pairsOf(g).length);
    case 'trace': return dots('つないだ', g.points.length - 1 + (g.close ? 1 : 0));
    default: return null;
  }
}
export function moreHintTargets(pg, g) {
  const gs = pg.gs;
  switch (g.type) {
    case 'carry': return g.items.filter((id) => !gs.carried[id]);
    case 'copy': return gs.phase === 'input' ? [gs.seq[gs.pos]] : [];
    case 'pairs': return g.cards.filter((id) => !gs.matched[id]).slice(0, 2);
    case 'hold': return [g.target];
    case 'trace': if (gs.dots && gs.dots[gs.next]) pulseDot(pg, gs.dots[gs.next]); return typeof g.points[gs.next] === 'string' ? [g.points[gs.next]] : [];
    default: return [];
  }
}

// ---------- はこぶ ----------
//   "items": ["onigiri", "ball"], "to": "me" or { "onigiri": "me", "ball": "basket" }
//   "react": { "onigiri": { … } } — when it arrives (on the one it went to); "stay": true — it stays there (else it goes in)
//   "count": "carried" — the number carried, for other pages
const destOf = (g, id) => (typeof g.to === 'string' ? g.to : (g.to || {})[id]);
function carryHome(pg, c, dur = 0.6) {
  const p0 = c.pivot.position.clone(), home = c.pivotHome;
  pg.tween(dur, (t) => { c.pivot.position.lerpVectors(p0, home, easeInOut(t)); if (c.shadow) c.shadow.position.set(c.pivot.position.x, c.pivot.position.y, c.shadow.position.z); },
    () => { c.pivot.position.copy(home); if (c.shadow) c.shadow.position.set(home.x, home.y, c.shadow.position.z); });
}
const carry = {
  init(pg) { pg.gs.carried = {}; pg.gs.drag = null; },
  grab(pg, g, id, hit) {
    if (pg.gs.done || !g.items.includes(id) || pg.gs.carried[id] || !hit) return false;
    const c = pg.C(id), at = groundOf(hit);
    pg.gs.drag = { id, off: new THREE.Vector3(c.pivot.position.x - at.x, c.pivot.position.y - at.y, 0), near: null };
    pg.hop(id, 0.025, 0.4); pg.sfx('pon'); progressed(pg);
    return true;
  },
  rub(pg, g, id, hit) {
    const d = pg.gs.drag, at = groundOf(hit); if (!d || !at) return;
    const c = pg.C(d.id);
    c.pivot.position.x = Math.max(-0.48, Math.min(0.48, at.x + d.off.x));
    c.pivot.position.y = Math.max(-PH / 2 + 0.02, Math.min(PH / 2 - 0.02, at.y + d.off.y));
    if (c.shadow) c.shadow.position.set(c.pivot.position.x, c.pivot.position.y, c.shadow.position.z);
    const to = destOf(g, d.id), T = to && pg.C(to);
    const close = T && near2(c.pivot.position, T.pivot.position) < (g.reach || 0.1);
    if (close && d.near !== to) { d.near = to; pg.pulse(to, 1.08, 0.5); pg.sfx('twinkle'); }
    if (!close) d.near = null;
    if (!CALM.on && Math.random() < 0.15) pg.fx.burst(pg.top(d.id, 0.3), 2, 0.4, ['#fff2a8', '#ffffff']);
  },
  release(pg, g) {
    const d = pg.gs.drag; if (!d) return;
    pg.gs.drag = null;
    const c = pg.C(d.id), to = destOf(g, d.id), T = to && pg.C(to);
    if (!T || near2(c.pivot.position, T.pivot.position) >= (g.reach || 0.1)) { carryHome(pg, c); return; }
    // it arrived: onto the one it went to, then (unless "stay") into it
    pg.gs.carried[d.id] = true; progressed(pg);
    const p0 = c.pivot.position.clone(), p1 = T.pivot.position.clone(); p1.z = p0.z;
    pg.tween(0.5, (t) => { c.pivot.position.lerpVectors(p0, p1, easeInOut(t)); if (c.shadow) c.shadow.position.set(c.pivot.position.x, c.pivot.position.y, c.shadow.position.z); }, () => {
      if (!g.stay) { pg.tween(0.35, (t) => c.body.scale.setScalar(1 - t), () => { pg.hide(d.id); c.body.scale.setScalar(1); }); if (c.shadow) c.shadow.visible = false; }
    });
    const r = g.react && g.react[d.id];
    pg.later(450, () => {
      if (r) react(pg, to, r, null, { free: true }); else { pg.hop(to, 0.05); pg.sfx(g.sound || 'mogu'); }
      pg.ono(pick(g.word || ['とどいた！', 'やったね！'], nextIdx(pg, 'carry')), pg.top(to, 1.05), g.color || '#e8756a');
      pg.burst(to, 14, 1.0);
    });
    const n = Object.keys(pg.gs.carried).length;
    pg.progress(n, g.items.length);
    if (g.count) setCount(g.count, n);
    if (n === g.items.length) pg.later(1500, () => goalDone(pg, g));
  },
  tap(pg, g, id) {
    if (!g.items.includes(id) || pg.gs.done || pg.gs.carried[id]) return false;
    pg.wobble(id, 0.05, 0.6); toldOnce(pg, 'toldCarry', 'ゆびで おしたまま うごかしてね');
    return true;
  },
};

// ---------- まねっこ ----------
//   "targets": ["bell1", "bell2", "bell3"] — each has its own note; "rounds": [3, 4] — how many to remember each round
const NOTE_COL = ['#ff8a7a', '#ffcf3a', '#7ad68a', '#6ab8f0', '#c49af0', '#ff9fd0'];
function shine(pg, g, id) {
  const i = g.targets.indexOf(id);
  pg.pulse(id, 1.18, 0.6); pg.sfx('note', i);
  pg.burst(id, CALM.on ? 6 : 12, 0.8, [NOTE_COL[i % NOTE_COL.length], '#ffffff']);
}
function copyShow(pg, g) {
  const gs = pg.gs, len = param(g, 'rounds', 'copyRounds')[gs.round];
  if (!gs.seq || gs.seq.length !== len) {
    gs.seq = [];
    for (let k = 0; k < len; k++) { let id; do { id = g.targets[Math.floor(Math.random() * g.targets.length)]; } while (g.targets.length > 1 && id === gs.seq[k - 1]); gs.seq.push(id); }
  }
  gs.phase = 'show'; gs.pos = 0;
  toldOnce(pg, `toldWatch${gs.round}`, 'よく みててね', 1800);
  gs.seq.forEach((id, k) => pg.later(1300 + k * 1000, () => shine(pg, g, id)));
  pg.later(1300 + gs.seq.length * 1000 + 300, () => { gs.phase = 'input'; gs.lastMove = pg.time; pg.toast('おなじ じゅんばんで タッチしてね', 2400); });
}
const copy = {
  init(pg) { pg.gs.round = 0; pg.gs.phase = 'wait'; pg.gs.seq = null; },
  play(pg, g) { copyShow(pg, g); },
  tap(pg, g, id) {
    if (!g.targets.includes(id) || pg.gs.done) return false;
    const gs = pg.gs;
    if (gs.phase !== 'input') { pg.wobble(id, 0.03, 0.4); return true; }
    if (id !== gs.seq[gs.pos]) {
      gs.phase = 'show-again';
      pg.wobble(id, 0.06, 0.8); pg.sfx('undo'); pg.ono(g.wrongWord || 'あれれ？', id, '#7a5aa0');
      pg.later(900, () => { pg.toast('もういちど みてね', 1800); copyShow(pg, g); });
      return true;
    }
    shine(pg, g, id); gs.pos++; progressed(pg);
    if (gs.pos < gs.seq.length) return true;
    const rounds = param(g, 'rounds', 'copyRounds');
    gs.round++; gs.seq = null; gs.phase = 'wait';
    pg.progress(gs.round, rounds.length);
    pg.ono(pick(g.word || ['できた！', 'すごい！'], nextIdx(pg, 'copy')), pg.top(id, 1.1), g.color || '#e8b21f'); pg.sfx('kirarin');
    if (gs.round >= rounds.length) pg.later(1000, () => goalDone(pg, g)); else pg.later(1200, () => copyShow(pg, g));
    return true;
  },
};

// ---------- ペアさがし ----------
//   "cards": ["c1", "c2", "c3", "c4"] — hidden pieces (not printed), shown face down when the game starts
//   "pairs": [["c1", "c3"], ["c2", "c4"]] — which pictures go together (without it: the same id without its number, apple1 + apple2)
//   The pictures are shuffled each time, so the places change.
function pairsOf(g) {
  if (g.pairs) return g.pairs;
  const by = {};
  for (const id of g.cards) (by[id.replace(/\d+$/, '')] = by[id.replace(/\d+$/, '')] || []).push(id);
  return Object.values(by).filter((p) => p.length >= 2);
}
let BACK = null;
function backTexture() {   // the back of a card: a soft colour with a star
  if (BACK) return BACK;
  const c = document.createElement('canvas'); c.width = 192; c.height = 256;
  const g = c.getContext('2d');
  g.fillStyle = '#fff8e8'; g.beginPath(); g.roundRect(4, 4, 184, 248, 22); g.fill();
  g.fillStyle = '#8f7ad6'; g.beginPath(); g.roundRect(16, 16, 160, 224, 16); g.fill();
  g.strokeStyle = 'rgba(255,255,255,0.35)'; g.lineWidth = 6;
  for (let k = -256; k < 256; k += 28) { g.beginPath(); g.moveTo(16 + k, 16); g.lineTo(176 + k, 240); g.stroke(); }
  g.fillStyle = '#ffe36b'; g.font = '900 96px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('★', 96, 132);
  BACK = new THREE.CanvasTexture(c); BACK.colorSpace = THREE.SRGBColorSpace;
  return BACK;
}
function turn(pg, id, tex) { pg.spin(id, 'y', 1, 0.8, () => { pg.C(id).mesh.material.map = tex; }); }
const pairs = {
  init(pg, g) {
    const gs = pg.gs; gs.open = []; gs.matched = {}; gs.face = {}; gs.group = {};
    const P = pairsOf(g), faces = [];
    P.forEach((p, k) => p.forEach((id) => faces.push({ tex: pg.C(id) && pg.tex[pg.C(id).m.tex[0]], k })));
    for (let i = faces.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [faces[i], faces[j]] = [faces[j], faces[i]]; }
    g.cards.forEach((id, i) => { const c = pg.C(id); if (!c || !faces[i]) return; gs.face[id] = faces[i].tex; gs.group[id] = faces[i].k; pg.show(id); c.mesh.material.map = backTexture(); });
  },
  tap(pg, g, id) {
    const gs = pg.gs;
    if (!g.cards.includes(id) || pg.gs.done) return false;
    if (gs.matched[id] || gs.open.includes(id) || gs.open.length >= 2) return true;
    gs.open.push(id); turn(pg, id, gs.face[id]); pg.sfx('pon'); progressed(pg);
    if (gs.open.length < 2) return true;
    const [a, b] = gs.open;
    if (gs.group[a] === gs.group[b]) {
      pg.later(900, () => {
        gs.matched[a] = gs.matched[b] = true; gs.open = [];
        [a, b].forEach((x) => { pg.hop(x, 0.04); pg.burst(x, 14, 1.0); });
        pg.sfx('kirarin'); pg.ono(pick(g.word || ['そろった！', 'おなじ！'], nextIdx(pg, 'pairs')), pg.top(b, 1.1), g.color || '#e8756a');
        const n = Object.keys(gs.matched).length / 2, total = pairsOf(g).length;
        pg.progress(n, total);
        if (n >= total) pg.later(900, () => goalDone(pg, g));
      });
    } else {
      pg.later(1300, () => { pg.sfx('undo'); [a, b].forEach((x) => turn(pg, x, backTexture())); pg.later(850, () => { gs.open = []; }); });
    }
    return true;
  },
};

// ---------- ながおし ----------
//   "target": "balloon", "seconds": 2.5 (age), "motion": "grow" (ふくらむ) / "pull" (ひっぱる) / "shake" (ぶるぶる)
//   "grow": 1.6 — how big at the end;  "swap": "big" — the picture at the end;  "word", "doneWord", "sound"
const hold = {
  init(pg) { pg.gs.p = 0; pg.gs.holding = false; },
  grab(pg, g, id) {
    if (id !== g.target || pg.gs.done || pg.gs.full) return false;
    pg.gs.holding = true; progressed(pg);
    if (!pg.labels.gauges.hold) pg.gauge('hold', 'bar', g.target, g.gauge || 'ぎゅー', '#ff8fb1', 1.12);
    return true;
  },
  release(pg) { pg.gs.holding = false; },
  update(pg, g, dt) {
    const gs = pg.gs; if (gs.done || gs.full || !pg.playing) return;
    const secs = param(g, 'seconds', 'holdSeconds');
    const was = gs.p;
    gs.p = gs.holding ? Math.min(1, gs.p + dt / secs) : Math.max(0, gs.p - dt / (secs * 2.5));
    if (gs.p === was && !gs.holding) return;
    const c = pg.C(g.target), b = c.body, bs = pg.base(c), p = gs.p, motion = g.motion || 'grow';
    if (motion === 'grow') { const k = 1 + ((g.grow || 1.5) - 1) * easeInOut(p); b.scale.set(k, k, 1); }
    else if (motion === 'pull') { b.position.y = bs.y + 0.06 * p; b.rotation.z = gs.holding ? 0.04 * Math.sin(pg.time * 18) * p : 0; }
    else { b.position.x = bs.x + (gs.holding ? 0.004 * p * Math.sin(pg.time * 40) : 0); }
    pg.setGauge('hold', p);
    if (gs.holding) {
      progressed(pg);
      if (pg.time - (gs.sndT || 0) > 0.45) { gs.sndT = pg.time; pg.sfx(g.sound || 'powa'); }
      if (pg.time - (gs.wordT || 0) > 1.2) { gs.wordT = pg.time; pg.onoAround(pick(g.word || ['ぎゅー', 'もうすこし！'], nextIdx(pg, 'hold')), g.target, g.color || '#e8756a'); }
    }
    if (p >= 1) {
      gs.full = true; gs.holding = false; pg.removeGauge('hold');
      if (g.swap) pg.swap(g.target, altKey(pg, g.target, g.swap));
      // back to its own size and place, smoothly (a small bounce on the way)
      const k0 = b.scale.x, y0 = b.position.y, x0 = b.position.x, r0 = b.rotation.z;
      pg.tween(0.8, (t) => {
        const e = easeInOut(t), bump = 0.06 * Math.sin(Math.PI * t);
        const k = k0 + (1 - k0) * e + bump; b.scale.set(k, k, 1);
        b.position.y = y0 + (bs.y - y0) * e; b.position.x = x0 + (bs.x - x0) * e; b.rotation.z = r0 * (1 - e);
      }, () => { b.scale.set(1, 1, 1); b.position.set(bs.x, bs.y, bs.z); b.rotation.z = 0; });
      pg.burst(g.target, 24, 1.3); pg.sfx('kirarin');
      pg.ono(g.doneWord || 'できた！', pg.top(g.target, 1.15), g.color || '#e8756a');
      pg.later(700, () => goalDone(pg, g));
    }
  },
  tap(pg, g, id) {
    if (id !== g.target || pg.gs.done) return false;
    pg.pulse(id, 1.05, 0.4); toldOnce(pg, 'toldHold', 'ゆびを はなさずに ながく おしてね');
    return true;
  },
};

// ---------- なぞって つなぐ ----------
//   "points": [[x, y], …] page pixels (1600 × 1200) or piece ids; "close": true — back to the first one at the end
//   "color": the line;  "show": "bear" — a hidden piece that comes out at the end (the shape: せいざ・え)
const DOT_R = 0.045;   // how close the finger must come to a point
let DOT = null;
function dotTexture() {
  if (DOT) return DOT;
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const g = c.getContext('2d'), grd = g.createRadialGradient(32, 32, 2, 32, 32, 30);
  grd.addColorStop(0, '#ffffff'); grd.addColorStop(0.35, '#fff3a0'); grd.addColorStop(1, 'rgba(255,230,120,0)');
  g.fillStyle = grd; g.fillRect(0, 0, 64, 64);
  DOT = new THREE.CanvasTexture(c); DOT.colorSpace = THREE.SRGBColorSpace;
  return DOT;
}
const pointOf = (pg, p) => (typeof p === 'string' ? (pg.C(p) ? pg.top(p, 0.5) : null) : pagePoint(p).setZ(0.002));
function pulseDot(pg, m) { const s0 = m.userData.size; pg.tween(0.8, (t) => m.scale.setScalar(s0 * (1 + 0.6 * Math.sin(Math.PI * t)))); }
function segment(pg, a, b, color) {
  const len = near2(a, b), mesh = new THREE.Mesh(new THREE.PlaneGeometry(1, 0.008), new THREE.MeshBasicMaterial({ color, transparent: true, depthWrite: false }));
  mesh.position.set(a.x, a.y, Math.max(a.z, b.z) + 0.0015); mesh.rotation.z = Math.atan2(b.y - a.y, b.x - a.x); mesh.renderOrder = 3;
  pg.root.add(mesh); pg._extras.push(mesh);
  pg.tween(0.35, (t) => { const l = Math.max(0.001, len * t); mesh.scale.x = l; mesh.position.set(a.x + (b.x - a.x) * t / 2, a.y + (b.y - a.y) * t / 2, mesh.position.z); });
}
function traceReach(pg, g, hit) {
  const gs = pg.gs, total = g.points.length + (g.close ? 1 : 0);
  if (!hit || gs.next >= total) return false;
  const i = gs.next % g.points.length, want = gs.pts[i];
  if (!want) return false;
  const onPiece = typeof g.points[i] === 'string';
  if (onPiece ? !(hit.id === g.points[i] || hit.point.distanceTo(want) < DOT_R * 1.5) : near2(groundOf(hit), want) > DOT_R) return false;
  if (gs.next > 0) segment(pg, gs.pts[gs.next - 1], want, g.color || '#ffe08a');
  const m = gs.dots[gs.next % g.points.length]; if (m) { m.material.color.set('#ffffff'); pulseDot(pg, m); }
  pg.sfx('note', gs.next % 6); progressed(pg);
  gs.next++;
  if (gs.next > 1) pg.progress(gs.next - 1, total - 1);
  if (gs.next >= total) {
    pg.later(500, () => {
      if (g.show && pg.C(g.show)) { pg.rise(g.show, -pg.C(g.show).h, 1.0); pg.later(700, () => pg.burst(g.show, 24, 1.3)); }
      pg.sfx('kirarin'); pg.ono(g.word || 'できた！', gs.pts[0].clone().add(pg.up.clone().multiplyScalar(0.06)), g.color || '#e8b21f');
      pg.later(900, () => goalDone(pg, g));
    });
  }
  return true;
}
const trace = {
  init(pg, g) {
    const gs = pg.gs; gs.next = 0;
    gs.pts = g.points.map((p) => pointOf(pg, p));
    gs.dots = gs.pts.map((p) => {
      if (!p) return null;
      const m = new THREE.Sprite(new THREE.SpriteMaterial({ map: dotTexture(), color: '#ffe9a0', transparent: true, depthWrite: false }));
      m.userData.size = 0.035; m.scale.setScalar(0.035); m.position.copy(p).setZ(p.z + 0.004); m.renderOrder = 4;
      pg.root.add(m); pg._extras.push(m);
      return m;
    });
    if (g.show && pg.C(g.show)) pg.hide(g.show);
  },
  play(pg) { const m = pg.gs.dots[0]; if (m) pulseDot(pg, m); },
  grab(pg, g, id, hit) { if (pg.gs.done || !hit) return false; return traceReach(pg, g, hit) || pg.gs.pts.some((p) => p && near2(groundOf(hit), p) < DOT_R * 1.5); },
  rub(pg, g, id, hit) { if (!pg.gs.done) traceReach(pg, g, hit); },
  tap(pg, g, id, hit) {
    if (pg.gs.done) return false;
    if (traceReach(pg, g, hit)) return true;
    if (id === 'plate' || id === null) { const m = pg.gs.dots[pg.gs.next % g.points.length]; if (m) pulseDot(pg, m); }
    return false;
  },
};

export const MORE_GAMES = { carry, copy, pairs, hold, trace };
