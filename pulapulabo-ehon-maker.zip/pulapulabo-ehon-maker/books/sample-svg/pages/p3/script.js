// 3ページ「くもを どかそう」：主人公（ミミ・おつきさま）、大きな くも、ともだちの動き。
// さわったときの反応や遊びは page.json に書いてあり、ここの動きを "move" で名前で使います。
// どの動きも「ためて → 大きく動いて → 気持ちが見える」ひと続き。何秒かかるかを返します（その間は もう一度さわっても反応しない）。
// はやさは「少し ゆっくり〜ふつう」（小さな子が 目で追える はやさ。1回まわるのに 1秒くらい）。

// しゃがむ（ためる）：たてに ちぢんで もどる
const squash = (pg, id, k = 0.12, dur = 0.4) => {
  const b = pg.C(id).body;
  pg.tween(dur, (t) => { const u = Math.sin(Math.PI * t); b.scale.set(1 + u * k * 0.5, 1 - u * k, 1); }, () => b.scale.set(1, 1, 1));
};

export default {
  moves: {
    // ミミ「フーッ！」：いきを すって（ふくらんで そる）→ フーッと はく（まえに のりだして、ゆっくり もどる。2.0 秒）
    catBlow(pg, id) {
      const b = pg.C(id).body;
      const ease = (t) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2);
      pg.tween(2.0, (t) => {
        if (t < 0.4) { const u = ease(t / 0.4); b.scale.set(1 + u * 0.08, 1 + u * 0.08, 1); b.rotation.z = u * 0.08; }
        else { const u = (t - 0.4) / 0.6, k = Math.sin(Math.PI * u), s = 1 + 0.08 * (1 - ease(u)); b.scale.set(s, s, 1); b.rotation.z = 0.08 * (1 - ease(u)) - 0.12 * k; }
      }, () => { b.scale.set(1, 1, 1); b.rotation.z = 0; });
      return 2.0;
    },
    // ミミ（おつきさまが でた）：右へ ぴょん、左へ ぴょん、くるんと回って 大ジャンプ（3.2 秒）
    catDance(pg, id) {
      const c = pg.C(id), b = c.body, bs = pg.base(c);
      const step = (dx, at) => pg.later(at, () => { const x0 = b.position.x; pg.tween(0.5, (t) => { b.position.x = x0 + (bs.x + dx - x0) * t; }); pg.hop(id, 0.04, 0.5); });
      step(0.02, 0); step(-0.02, 550); step(0, 1100);
      pg.later(1600, () => pg.spin(id, 'y', 1, 0.9));
      pg.later(2400, () => pg.hop(id, 0.09, 0.8));
      return 3.2;
    },
    // ミミ「おやすみなさい」：大きく のびをして、ゆっくり おじぎ（2.6 秒）
    catYawn(pg, id) {
      const b = pg.C(id).body;
      pg.tween(1.3, (t) => { const u = Math.sin(Math.PI * t); b.scale.set(1 - u * 0.05, 1 + u * 0.14, 1); }, () => b.scale.set(1, 1, 1));
      pg.later(1350, () => pg.tween(1.2, (t) => { b.rotation.x = Math.sin(Math.PI * t) * 0.4; }, () => { b.rotation.x = 0; }));
      return 2.6;
    },
    // うさぎ「えいっ！」：ぐっと しゃがんで、くもに むかって 大ジャンプ（1.5 秒）
    rabbitPush(pg, id) {
      squash(pg, id, 0.18);
      pg.later(350, () => pg.hop(id, 0.1, 0.8));
      pg.later(1150, () => squash(pg, id, 0.1, 0.3));
      return 1.5;
    },
    // うさぎ（おつきさまが でた）：ぴょーん、ぴょん、ぴょっ（だんだん小さく。1.75 秒）
    rabbitHop3(pg, id) {
      pg.hop(id, 0.08, 0.7);
      pg.later(700, () => pg.hop(id, 0.05, 0.55));
      pg.later(1250, () => pg.hop(id, 0.025, 0.45));
      return 1.75;
    },
    // ふくろう「いそげ いそげ」：ばさばさ はばたいて 少し うかんで、ふわっと おりる（1.8 秒）
    owlFlap(pg, id) {
      const c = pg.C(id), b = c.body, bs = pg.base(c);
      pg.tween(1.8, (t) => {
        b.scale.x = 1 - Math.abs(Math.sin(t * Math.PI * 4)) * 0.15;
        b.position.y = bs.y + Math.sin(Math.PI * t) * 0.035;
      }, () => { b.scale.x = 1; b.position.y = bs.y; });
      return 1.8;
    },
    // ふくろう（よかった よかった）：首を ゆっくり くるっ くるっと まわして、ぴょん（2.2 秒）
    owlTurn(pg, id) {
      const b = pg.C(id).body;
      pg.tween(1.6, (t) => { b.rotation.y = Math.sin(t * Math.PI * 2) * 0.9; }, () => { b.rotation.y = 0; });
      pg.later(1650, () => pg.hop(id, 0.04, 0.55));
      return 2.2;
    },
    // ほしのこ（キラキラ パワー！）：くるんと 1回 ゆっくり まわって、ぽんっと ふくらむ（2.0 秒）
    starTwirl(pg, id) {
      pg.spin(id, 'z', 1, 1.4);
      pg.later(1400, () => { pg.pulse(id, 1.25, 0.6); pg.burst(id, 12, 0.8); });
      return 2.0;
    },
    // 大きな くも（なんども タッチ）：おされて むにゅっと つぶれて、ぷるん（タッチに すぐ こたえる）
    cloudSquish(pg, id) {
      const b = pg.C(id).body;
      pg.tween(0.5, (t) => { const e = Math.sin(t * Math.PI * 2) * Math.exp(-3 * t) * 0.12; b.scale.set(1 + e, 1 - e, 1); }, () => b.scale.set(1, 1, 1));
    },
    // 大きな くも（クリア）：ぎゅっと ちぢんで → ふわーっと 空へ とんでいって、ちいさく なって きえる（2.0 秒）
    cloudAway(pg, id) {
      const c = pg.C(id), b = c.body, bs = pg.base(c);
      pg.sfx('boing');
      pg.tween(0.4, (t) => { const u = Math.sin(Math.PI * t); b.scale.set(1 + u * 0.1, 1 - u * 0.12, 1); });
      pg.later(400, () => pg.tween(1.6, (t) => {
        const k = t * t; b.position.set(bs.x + 0.25 * k, bs.y + 0.45 * k, bs.z); b.rotation.z = -t * 1.2;
        const s = 1 - 0.7 * t; b.scale.set(s, s, 1);
      }, () => { pg.hide(id); b.position.set(bs.x, bs.y, bs.z); b.rotation.z = 0; b.scale.set(1, 1, 1); }));
      return 2.0;
    },
    // おつきさま（でてきた）：ぽわーんと ふくらんで 光り、ゆっくり ゆれる（2.2 秒）
    moonRise(pg, id) {
      const b = pg.C(id).body;
      pg.tween(2.2, (t) => {
        const s = 1 + Math.sin(Math.PI * Math.min(1, t * 1.6)) * 0.18; b.scale.set(s, s, 1);
        b.rotation.z = Math.sin(t * Math.PI * 2) * 0.08 * t;
      }, () => { b.scale.set(1, 1, 1); b.rotation.z = 0; });
      pg.later(400, () => pg.burst(id, 24, 1.1, ['#fff6c9', '#ffffff', '#ffe08a']));
      return 2.2;
    },
    // おつきさま：ゆったり ゆれて、ふくらむように かがやく（2.6 秒）
    moonSmile(pg, id) {
      const b = pg.C(id).body;
      pg.tween(2.6, (t) => {
        b.rotation.z = Math.sin(t * Math.PI * 2) * 0.1 * (1 - t * 0.4);
        const s = 1 + Math.sin(Math.PI * t) * 0.08; b.scale.set(s, s, 1);
      }, () => { b.rotation.z = 0; b.scale.set(1, 1, 1); });
      pg.later(800, () => pg.burst(id, 10, 0.6, ['#fff6c9', '#ffffff']));
      return 2.6;
    },
  },
};
