// Reading script: what the voice actually says.
import { LANG, plain } from './lang.js';
import { fill, shown } from './story.js';
// Pages and bubbles show easy hiragana with spaces (for children); a speech engine reads that
// word by word with flat accents. The book's read.json (and each page's story "read") gives the
// natural spoken version: kanji where it helps the accent, no spaces, commas for pauses.
const READ = {};
const norm = (t) => t.replace(/[\s\u3000]+/g, '');

export function setReadMap(map) {
  for (const [k, v] of Object.entries(map || {})) READ[norm(k)] = v;
}
// fallback for any line without a script: drop the word spaces and decorations
function tidy(t) {
  return t.replace(/[\s\u3000]+/g, '').replace(/〜/g, 'ー').replace(/…/g, '、').replace(/[♪★☆「」]/g, '');
}
// (other languages: the translation as it is shown; ふりがな {漢字|かんじ} is read in kana —
//  also inside a reading script: "{間に合|まにあ}ったね" is read まにあったね)
// (in the voice's language, こえ — the words on the screen, もじ, may be another one)
export function spoken(text) {
  const l = LANG.voice;
  if (l !== 'ja') return shown(text, l).replace(/[♪★☆「」『』〜]/g, '');
  const r = READ[norm(text)];
  return r ? plain(fill(r, 'ja')) : tidy(plain(fill(text, 'ja')));
}
