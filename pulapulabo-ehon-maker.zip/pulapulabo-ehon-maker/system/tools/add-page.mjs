// npm run add-page                 → adds a page to the book being made: copies the last page (pages/pN → pages/pN+1)
//                                    and adds it to the end of "pages" in book.json
// npm run add-page -- --from p1    → copy another page instead of the last one
// npm run add-page -- --book <id>  → another book
import fs from 'node:fs';
import path from 'node:path';
import { rel, args, config, exists, readJSON } from './lib/common.mjs';

const A = args();
const id = A.book || config().book;
const dir = rel('books', id || '');
if (!id || !exists(path.join(dir, 'book.json'))) { console.error(`\n  books/${id} が見つかりません。npm run use で絵本を選んでください。\n`); process.exit(1); }
const bj = path.join(dir, 'book.json');
const book = readJSON(bj);
const pages = book.pages || [];
const from = A.from || pages[pages.length - 1];
if (!from || !exists(path.join(dir, 'pages', from))) { console.error(`\n  コピーするページ pages/${from} が見つかりません。\n`); process.exit(1); }

const used = new Set([...pages, ...(exists(path.join(dir, 'pages')) ? fs.readdirSync(path.join(dir, 'pages')) : [])]);
let n = pages.length + 1;
while (used.has(`p${n}`)) n++;
const name = `p${n}`;
fs.cpSync(path.join(dir, 'pages', from), path.join(dir, 'pages', name), { recursive: true });
book.pages = [...pages, name];
fs.writeFileSync(bj, JSON.stringify(book, null, 2) + '\n');
console.log(`
  ✅ ページ「${name}」を足しました（pages/${from} のコピー）。book.json の "pages" は ${JSON.stringify(book.pages)} です。

  次にすること
    1. pages/${name}/page.json の文章（story）・飛び出す絵（pieces）・しかけ（touch・goal）を書きかえる
    2. pages/${name}/layers/ の絵を、このページの場面に描きかえる
       背景は ほかのページと はっきり違う絵にします（カメラは背景のちがいで ページを見分けます）
    3. npm run check → npm run build
`);
