// The book currently loaded: title, characters, voices, colours, settings.
// Everything book-specific the engine needs comes from book.json through here.
export const BOOK = {
  title: '', subtitle: '', cast: [], byId: {},
  narrator: { pitch: 1.0, rate: 0.92 },
  settings: { readFirst: true, voiceOn: false },
};

// the readers' age (book.json "age": 3 / 5 / 7) → how easy the games are, unless a goal says otherwise
//   seconds: gather time · times: mash taps · hintAfter: seconds before a hint · stay: pop-up time
//   popTimes: pop / fall catches · growTimes: taps per grow stage · rub: finger movement to rub clean · strict: order starts again
//   copyRounds: how many to remember in each round of まねっこ · holdSeconds: how long to keep pressing (ながおし)
export const AGE = {
  3: { seconds: 12, times: 6, hintAfter: 6, stay: 2.6, popTimes: 5, growTimes: 2, rub: 500, strict: false, copyRounds: [2, 3], holdSeconds: 2 },
  5: { seconds: 8, times: 10, hintAfter: 10, stay: 1.8, popTimes: 6, growTimes: 3, rub: 800, strict: false, copyRounds: [3, 4], holdSeconds: 2.5 },
  7: { seconds: 6, times: 14, hintAfter: 15, stay: 1.3, popTimes: 8, growTimes: 4, rub: 1100, strict: true, copyRounds: [3, 4, 5], holdSeconds: 3 },
};
export const age = () => AGE[BOOK.age] || AGE[5];
// ひかえめモード: fewer flashes and particles, slower and smaller moves (switched on the start screen)
export const CALM = { on: false };

export function setBook(b) {
  Object.assign(BOOK, b);
  BOOK.narrator = { pitch: 1.0, rate: 0.92, ...(b.narrator || {}) };
  BOOK.settings = { readFirst: true, voiceOn: false, ...(b.settings || {}) };
  BOOK.byId = {};
  for (const c of BOOK.cast || []) BOOK.byId[c.id] = c;
}

// voice for a speaker id ('n' or unknown = narrator)
export const voice = (id) => (BOOK.byId[id] && BOOK.byId[id].voice) || BOOK.narrator;
// speech-bubble / text colour
export const castColor = (id) => (BOOK.byId[id] && BOOK.byId[id].color) || '#7a5aa0';
// firework colour for a character
export const fireworkColor = (id) => (BOOK.byId[id] && (BOOK.byId[id].firework || BOOK.byId[id].color)) || '#ffd84a';
// colour of the character's dot in the progress bar
export const markColor = (id) => (BOOK.byId[id] && (BOOK.byId[id].mark || BOOK.byId[id].color)) || '#ffe36b';
// meow sound settings
export const meowOf = (id) => (BOOK.byId[id] && BOOK.byId[id].meow) || null;
export const isCast = (id) => !!BOOK.byId[id];
export const castIds = () => (BOOK.cast || []).map((c) => c.id);
