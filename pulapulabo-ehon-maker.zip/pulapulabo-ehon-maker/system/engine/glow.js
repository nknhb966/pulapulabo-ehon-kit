// Soft glow behind a pop-up piece (the "glow" effect).
import * as THREE from 'three';

// soft yellow-green glow drawn BEHIND the piece (depth-tested), so the piece itself stays visible
let GLOW = null;
export function glowTexture() {
  if (GLOW) return GLOW;
  const c = document.createElement('canvas'); c.width = c.height = 128;
  const g = c.getContext('2d'); const grd = g.createRadialGradient(64, 64, 4, 64, 64, 64);
  grd.addColorStop(0, 'rgba(235,255,150,0.95)'); grd.addColorStop(0.35, 'rgba(200,255,90,0.45)'); grd.addColorStop(1, 'rgba(180,255,80,0)');
  g.fillStyle = grd; g.fillRect(0, 0, 128, 128);
  GLOW = new THREE.CanvasTexture(c); GLOW.colorSpace = THREE.SRGBColorSpace;
  return GLOW;
}
export function addHalo(pg, ff, size = 0.1) {
  const c = pg.C(ff);
  if (c.halo) return;
  const m = new THREE.Mesh(new THREE.PlaneGeometry(size, size), new THREE.MeshBasicMaterial({ map: glowTexture(), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
  m.position.set(0, c.h * 0.42, -0.006); // behind the bug, inside its own card
  c.body.add(m); c.halo = m;
}

// blink (flash: 0..1 extra brightness)
export function blinkHalo(c, time, phase = 0, flash = 0) {
  if (!c.halo) return;
  const k = Math.max(0.55 + 0.45 * Math.max(0, Math.sin((time + phase) * 4.2)), 0.6 + flash * 0.9);
  c.halo.material.opacity = k; c.halo.scale.setScalar(0.85 + 0.35 * k);
}
