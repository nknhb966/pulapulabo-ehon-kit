// The page's game ("goal" in page.json) and what happens when it is cleared ("done").
//   find    : かくれている ものを さがす        gather : じかんないに ぜんぶ タッチ      mash : なんども タッチ
//   order   : じゅんばんに タッチ              choose : えらぶ（クイズ）                pop  : でてきたら タッチ
//   fall    : おちてくる ものを キャッチ        grow   : そだてる（だんだん かわる）     dressup: きせかえ
//   rub     : こする・はらう
//   and in games.js: carry (はこぶ) · copy (まねっこ) · pairs (ペアさがし) · hold (ながおし) · trace (なぞって つなぐ)
// Numbers that make a game easier or harder come from the readers' age (book.json "age": 3 / 5 / 7)
// unless the goal says otherwise. When nothing happens for a while, the things to touch next shine (hint).
import * as THREE from 'three';
import { isCast, markColor, fireworkColor, castIds, age, CALM } from './book.js';
import { react, pick, altKey, nextIdx, moveOf } from './presets.js';
import { MOODS, walk, light, darken, canTravel, startLasting } from './scene.js';
import { cardMaterial } from './page.js';
import { remember, itemOf, holds, setCount, keepLook } from './story.js';
import { easeInOut } from './fx.js';
import { glowTexture } from './glow.js';
import { toolStart, toolSwing, reach, hasTool } from './tool.js';
import { MORE_GAMES, moreHint, moreProgress, moreHintTargets } from './games.js';

export const param = (g, key, ageKey = key) => g[key] ?? age()[ageKey];
export const progressed = (pg) => { pg.gs.lastMove = pg.time; };
// the time to touch them all (ぜんぶ タッチ・みんなで): the age's "seconds" is for 4 of them, as much more for each
// one more (5さい: 4つで 8びょう、6つで 12びょう); "seconds" written in the game: that
export const windowOf = (g, n) => g.seconds ?? Math.round(age().seconds * Math.max(1, n) / 4);
const noSwap = (spec) => { const o = { ...spec }; delete o.swap; return o; };

// ---------- texts and progress dots ----------
export function goalHint(g) {
  switch (g.type) {
    case 'find': return `かくれている ものを ${g.items.length}つ さがしてね`;
    case 'gather': return `${windowOf(g, g.targets.length)}びょうの うちに ぜんぶ タッチしてね`;
    case 'mash': return g.team ? 'みんなを タッチしてから、なんども タッチしてね' : 'なんども タッチしてね';
    case 'order': return 'じゅんばんに タッチしてね';
    case 'choose': return quizOf(g)[0].question || 'どれかな？ えらんで タッチしてね';
    case 'pop': return 'でてきたら タッチしてね';
    case 'grow': return 'なんども タッチして そだててね';
    case 'dressup': return g.answer ? 'おてほんと おなじに してね' : 'タッチして きせかえしてね';
    case 'rub': return 'ゆびで こすってね';
    case 'fall': return 'おちてくる ものを タッチしてね';
    default: return moreHint(g) || 'いろいろ さわってみてね';
  }
}
export function goalProgress(g) {
  const dots = (label, total, colors) => ({ label: g.label || label, total, colors });
  switch (g.type) {
    case 'find': return dots('みつけた', g.items.length);
    case 'choose': return quizTotal(g) > 1 ? dots('せいかい', quizTotal(g)) : null;
    case 'gather': return dots('タッチ', g.targets.length, g.targets.map((t) => (isCast(t) ? markColor(t) : '#ffe36b')));
    case 'mash': return g.team ? dots('みんな', g.team.length, g.team.map((t) => (isCast(t) ? markColor(t) : '#ffe36b'))) : null;
    case 'order': return dots('じゅんばん', g.targets.length);
    case 'pop': return dots('タッチ', param(g, 'times', 'popTimes'));
    case 'grow': return dots('そだつ', (g.stages || []).length);
    case 'dressup': return dots('きせかえ', Object.keys(g.answer || g.looks || {}).length);
    case 'rub': return dots('きれい', g.targets.length);
    case 'fall': return dots('キャッチ', param(g, 'times', 'popTimes'));
    default: return moreProgress(g, dots);
  }
}

// ---------- hints: after a while with no progress, the things to touch next shine ----------
function hintTargets(pg, g) {
  const gs = pg.gs;
  switch (g.type) {
    case 'find': return g.items.filter((it) => !gs.found[findKey(it)] && !waitsForMain(pg, it) && !(gs.place && gs.place[findKey(it)] && gs.place[findKey(it)].part)).map((it) => (gs.place && gs.place[findKey(it)] ? gs.place[findKey(it)].spot : it.spot));
    case 'gather': return g.targets.filter((t) => !gs.ready[t]);
    case 'mash': { const wait = (g.team || []).filter((t) => !gs.ready[t]); return wait.length ? wait : [g.target]; }
    case 'grow': return [g.target];
    case 'order': return [g.targets[gs.next]];
    case 'choose': { const q = quizOf(g)[gs.q || 0] || g; return (q.options || []).filter((o) => !(gs.got && gs.got[o])); }
    case 'pop': return Object.keys(gs.up);
    case 'dressup': return Object.keys(g.looks || {}).filter((id) => !lookMatches(pg, g, id));
    case 'rub': return g.targets.filter((t) => !gs.cleared[t]);
    case 'fall': return Object.keys(gs.up);
    default: return moreHintTargets(pg, g);
  }
}
function showHint(pg, g) {
  if (g.type === 'find') {   // a part of a big spot: that part shines, and the bit that shows moves ("main": it first)
    for (const it of g.items) {
      const pl = pg.gs.place[findKey(it)];
      if (pg.gs.found[findKey(it)] || !pl || !pl.part || waitsForMain(pg, it)) continue;
      if (!CALM.on) pg.burst(pg.pointOn(pl.spot, pl.center[0], pl.center[1], 0.02), 12, 0.8, ['#fff2a8', '#ffffff']);
      pg.hop(it.item, 0.03);
    }
  }
  const ids = hintTargets(pg, g).filter((id) => id && pg.C(id) && pg.C(id).body.visible);
  if (!ids.length) return;
  if (g.type === 'choose') ask(pg, quizOf(g)[pg.gs.q || 0] || g);
  ids.forEach((id, i) => pg.later(i * 160, () => { pg.pulse(id, 1.1, 0.6); if (!CALM.on) pg.burst(id, 8, 0.7, ['#fff2a8', '#ffffff']); }));
  pg.sfx('twinkle');
}

// ---------- when the page is cleared ----------
const skyPoint = (pg, x, h) => new THREE.Vector3(x, 0.1, 0.01).add(pg.up.clone().multiplyScalar(h));
// the big ending ("effect": "finale"): a barrage of fireworks, glitter over the sky, then one golden willow
export function finale(pg) {
  const ids = castIds().filter((id) => pg.C(id));
  const cols = [...ids.map(fireworkColor), '#ffe9a0', '#ffffff'];
  const kinds = ['peony', 'ring', 'peony', 'willow', 'ring', 'peony'];
  const shots = CALM.on ? 6 : 14;
  for (let i = 0; i < shots; i++) {
    pg.later(700 + i * (CALM.on ? 600 : 300) + Math.random() * 120, () => {
      const x = (i % 2 ? 1 : -1) * (0.08 + Math.random() * 0.32), h = 0.17 + Math.random() * 0.17;
      const c = cols[i % cols.length], c2 = cols[(i + 3) % cols.length];
      pg.firework(skyPoint(pg, x, h), c, c2, kinds[i % kinds.length], new THREE.Vector3(x * 0.8, -0.1, 0.01),
        i % 3 === 0 ? () => pg.ono(['ドーン！', 'パーン！', 'ドドーン！'][(i / 3) % 3], skyPoint(pg, x, h + 0.07), c) : null);
    });
  }
  if (!CALM.on) {
    pg.tween(6.5, () => {   // glitter drifting down over the whole sky
      for (let k = 0; k < 2; k++) {
        const p = skyPoint(pg, -0.5 + Math.random(), 0.32 + Math.random() * 0.14);
        pg.fx.emit(p, { x: (Math.random() - 0.5) * 0.02, y: -pg.up.y * 0.03, z: -pg.up.z * 0.03 }, Math.random() < 0.6 ? '#ffe9a0' : '#ffffff', 0.016 + Math.random() * 0.012, 2.4, 0.99, -0.03, 1);
      }
    });
  }
  ids.forEach((id, i) => pg.later(500 + i * 220, () => pg.burst(id, 20, 1.2, ['#fff2a8', '#ffffff', fireworkColor(id)])));
  pg.later(CALM.on ? 4800 : 5200, () => {
    pg.firework(skyPoint(pg, 0, 0.3), '#ffd84a', '#fff6c8', 'willow', new THREE.Vector3(0, -0.12, 0.01), () => {
      pg.ono('ドドーン！', skyPoint(pg, 0, 0.4), '#ffd84a');
      pg.sfx('finale');
      ids.forEach((id, i) => pg.later(i * 120, () => { pg.hop(id, 0.07); pg.burst(id, 16, 1.3, ['#fff2a8', '#ffffff', '#ffc2e2']); }));
    });
  });
}

const DONE_TOAST = {
  choose: 'せいかい！', pop: 'ぜんぶ つかまえたね！', fall: 'ぜんぶ キャッチしたね！', grow: 'おおきく なったね！', rub: 'ぴかぴかに なったね！',
  carry: 'ぜんぶ はこんだね！', copy: 'よく おぼえたね！', pairs: 'ぜんぶ そろったね！', trace: 'できあがり！',
};
export function goalDone(pg, g) {
  if (pg.gs.done) return;
  pg.gs.done = true;
  pg.complete();
  // "if" / "need" in done: when it does not hold, "else" is the ending instead (スタンプの数・かぞえた数 … で変わる)
  let d = g.done || {};
  if ((d.if || d.need) && !holds(d)) d = d.else || {};
  pg.later(400, () => {
    pg.sfx(d.sound || 'fanfare');
    if (d.toast !== '') pg.toast(d.toast || (g.type === 'choose' && !g.answer ? 'これに きめた！' : DONE_TOAST[g.type]) || 'できたね！ すごい！', 3000);
    if (d.get) [].concat(d.get).forEach((it, i) => pg.later(1200 + i * 500, () => pg.getItem(it)));   // もちもの
    const cast = castIds().filter((id) => pg.C(id));
    // happy faces: every character that has a <id>@happy picture on this page ("face": "cheer" = another name, false = none)
    const face = d.face === undefined ? 'happy' : d.face;
    if (face) cast.forEach((id) => { const k = `${id}@${face}`; if (pg.tex[k]) { clearTimeout(pg.C(id)._backT); pg.swap(id, k); } }); // (a picture that was going back later stays this face)
    if (d.hop !== false) cast.filter((id) => !(d.move && d.move[id])).forEach((id, i) => pg.later(i * 130, () => pg.hop(id, 0.05)));   // (one with its own "move" does that instead)
    // "move": { "door": "open" } — things that move when the page is cleared
    Object.entries(d.move || {}).forEach(([id, mv], i) => pg.C(id) && moveOf(pg, mv) && pg.later(i * 150, () => moveOf(pg, mv)(pg, id)));
    // "trail": { "points": [[x, y], …] in page pixels (1600 × 1200), "color": "#…" } — a path that lights up
    const tr = Array.isArray(d.trail) ? { points: d.trail } : d.trail;
    const trailPts = tr && Array.isArray(tr.points) && tr.points.length >= 2 ? tr.points.map(([x, y]) => [x / 1600 - 0.5, 0.375 - y / 1600]) : null;
    if (trailPts) pg.later(300, () => pg.trail(trailPts, tr.color || '#ffe08a', 40));
    // "walk": { "cat": [[x, y], …] } — walking somewhere when the page is cleared
    Object.entries(d.walk || {}).forEach(([id, w], i) => canTravel(pg, id) && pg.later(i * 200, () => walk(pg, id, Array.isArray(w) ? w : w.points, { flip: !!w.flip })));
    // "light": ["window", "lamp"] — lights that turn on;  "dark": 0.5 — the page gets darker (0 = bright again)
    [].concat(d.light || []).forEach((id, i) => pg.C(id) && pg.later(300 + i * 250, () => light(pg, id, true)));
    if (typeof d.dark === 'number') darken(pg, d.dark, 2);
    // "mark": "heart" (everyone) or { "cat": "note" } — feeling marks
    // (not for the ones who say a line here: their words say it)
    const says = Array.isArray(d.say) ? d.say : d.say ? [d.say] : [];
    const speakers = new Set(says.map((s) => s && s.who));
    if (d.mark) Object.entries(typeof d.mark === 'string' ? Object.fromEntries(cast.map((id) => [id, d.mark])) : d.mark).filter(([id]) => !speakers.has(id)).forEach(([id, k], i) => pg.later(200 + i * 150, () => pg.mark(id, k)));
    // "keep": false — the ending ends after a while; otherwise a little of it stays until the page changes
    // (the rainbow and the lit path stay, confetti / petals / stars go on, a little: scene.js LASTING)
    const keep = d.keep !== false;
    if (keep) { startLasting(pg, d.effect, trailPts); if (trailPts) pg._lasting.color = tr.color || '#ffe08a'; }
    if (MOODS[d.effect]) MOODS[d.effect](pg, keep);
    else if (d.effect === 'finale') finale(pg);
    else if (d.effect === 'none') { /* nothing more (a page's own move can make the ending) */ }
    else if (d.effect === 'fireworks') {
      for (let k = 0; k < (CALM.on ? 3 : 6); k++) pg.later(200 + k * 320, () => {
        const x = -0.35 + Math.random() * 0.7, p = new THREE.Vector3(x, 0.05, 0.01).add(pg.up.clone().multiplyScalar(0.3 + Math.random() * 0.08));
        const ids = cast.length ? cast : ['_'];
        pg.firework(p, fireworkColor(ids[k % ids.length]), '#ffffff', k % 2 ? 'ring' : 'peony', new THREE.Vector3(x, -0.08, 0.01));
      });
    } else {
      for (let k = 0; k < 5; k++) pg.later(k * 160, () => pg.fx.burst(new THREE.Vector3(-0.36 + k * 0.18, -0.02 + Math.random() * 0.2, 0.04), 16, 1.2));
    }
    says.forEach((s, k) => pg.later(700 + k * 1700, () => pg.C(s.who) && pg.say(s.who, s.text)));
  });
}

// ---------- helpers for the games ----------
// "choose": the question, by a character's speech bubble or at the top of the screen
function ask(pg, g) {
  if (!g.question) return;
  if (g.who && pg.C(g.who)) pg.say(g.who, g.question); else pg.toast(g.question, 2600);
}
// "dressup": the look a piece is wearing now ("" = its own picture)
function lookOf(pg, g, id) { const list = ['', ...(g.looks[id] || [])]; return list[pg.gs.look[id] || 0]; }
function lookMatches(pg, g, id) {
  if (!g.answer || !(id in g.answer)) return true;
  const want = g.answer[id] === 'base' ? '' : g.answer[id];
  return lookOf(pg, g, id) === want;
}
// "rub": a piece goes away when it is rubbed clean (or changes to its "swap" picture)
function rubClear(pg, g, id) {
  pg.gs.cleared[id] = true; pg.removeGauge(`r_${id}`);
  pg.sfx(g.doneSound || 'kirarin'); pg.ono(g.doneWord || 'ぴかぴか！', id, g.color || '#3fa9e0');
  if (g.swap && pg.tex[`${id}@${g.swap}`]) { pg.swap(id, `${id}@${g.swap}`); pg.burst(id, 18, 1.1); }
  else {
    const b = pg.C(id).body; pg.puff(pg.top(id, 0.5), 18, '#ffffff', 0.02, 0.14, 0.03);
    pg.tween(0.5, (t) => b.scale.setScalar(1 - t), () => { pg.hide(id); b.scale.setScalar(1); });
  }
  const n = Object.keys(pg.gs.cleared).length;
  pg.progress(n, g.targets.length); progressed(pg);
  if (n === g.targets.length) pg.later(900, () => goalDone(pg, g));
}
function rubAdd(pg, g, id, amount, hit) {
  if (pg.gs.cleared[id]) return;
  pg.gs.rubbed[id] = Math.min(1, (pg.gs.rubbed[id] || 0) + amount);
  if (!pg.labels.gauges[`r_${id}`]) pg.gauge(`r_${id}`, 'bar', id, g.gauge || 'ぴかぴか', '#3fa9e0', 1.05);
  pg.setGauge(`r_${id}`, pg.gs.rubbed[id]);
  const t = pg.time;
  if (t - (pg.gs.fxT || 0) > 0.12) { pg.gs.fxT = t; pg.puff(hit ? hit.point : pg.top(id, 0.5), CALM.on ? 2 : 4, g.particle || '#e8f8ff', 0.012, 0.08, 0.02); }
  if (t - (pg.gs.sndT || 0) > 0.3) { pg.gs.sndT = t; pg.sfx(g.sound || 'kyu'); }
  if (t - (pg.gs.wordT || 0) > 1.0) { pg.gs.wordT = t; pg.ono(pick(g.word || ['ゴシゴシ', 'キュッキュッ'], nextIdx(pg, 'rub')), hit ? hit.point : id, g.color || '#3fa9e0'); }
  if (pg.gs.rubbed[id] >= 1) rubClear(pg, g, id);
}

// ---------- でてきたら タッチ (pop) and おちてくる (fall) ----------
// how a target comes out, stays, and goes back. Positions are the piece's own (body) offsets: y is "up" on the card.
const POP_STYLE = {
  rise: {
    inT: 0.5,
    come(pg, id, L) {
      const c = pg.C(id), b = c.body, bs = pg.base(c); pg.show(id);
      pg.tween(0.5, (t) => { b.position.y = bs.y + L - (c.h + L) * (1 - easeInOut(t)); });
    },
    stay(pg, id, e, L) { const c = pg.C(id); c.body.position.y = pg.base(c).y + L; },
    go(pg, id) {
      const c = pg.C(id), b = c.body, bs = pg.base(c), y0 = b.position.y;
      pg.tween(0.35, (t) => { b.position.y = y0 - (y0 - bs.y + c.h) * t * t; }, () => { pg.hide(id); b.position.y = bs.y; });
    },
  },
  swim: {
    inT: 0.9,
    come(pg, id, L) {
      const c = pg.C(id), b = c.body, bs = pg.base(c), k = Math.random() < 0.5 ? -1 : 1; c.popDir = k; pg.show(id);
      pg.tween(0.9, (t) => { const e = easeInOut(t); b.position.x = bs.x + k * 0.07 * (1 - e); b.position.y = bs.y + L - (c.h + L) * (1 - e); b.rotation.z = k * 0.25 * (1 - e); });
    },
    stay(pg, id, e, L) { const c = pg.C(id), b = c.body, bs = pg.base(c); b.position.y = bs.y + L + 0.006 * Math.sin(e * 3); b.rotation.z = 0.08 * Math.sin(e * 2.2); },
    go(pg, id) {
      const c = pg.C(id), b = c.body, bs = pg.base(c), k = -(c.popDir || 1), y0 = b.position.y;
      pg.tween(0.7, (t) => { const e = easeInOut(t); b.position.x = bs.x + k * 0.06 * e; b.position.y = y0 - (y0 - bs.y + c.h) * e; b.rotation.z = -k * 0.3 * e; },
        () => { pg.hide(id); b.position.set(bs.x, bs.y, bs.z); b.rotation.z = 0; });
    },
  },
  fly: {
    inT: 1.1,
    come(pg, id, L) {
      const c = pg.C(id), b = c.body, bs = pg.base(c); pg.show(id);
      pg.tween(1.1, (t) => { const e = easeInOut(t); b.position.y = bs.y + L - (c.h * 1.2 + L) * (1 - e); b.position.x = bs.x + 0.02 * Math.sin(Math.PI * 2 * t) * (1 - t); });
      c.glowFlash = pg.time;
    },
    stay(pg, id, e, L) { const c = pg.C(id), b = c.body, bs = pg.base(c); b.position.x = bs.x + 0.018 * Math.sin(e * 1.6); b.position.y = bs.y + L + 0.012 * Math.sin(e * 3.2); },
    go(pg, id) {
      const c = pg.C(id), b = c.body, bs = pg.base(c), x0 = b.position.x, y0 = b.position.y;
      pg.tween(1.0, (t) => { const e = easeInOut(t); b.position.x = x0 + (bs.x - x0) * e; b.position.y = y0 + (bs.y - c.h * 1.2 - y0) * e; },
        () => { pg.hide(id); b.position.set(bs.x, bs.y, bs.z); });
    },
  },
  fall: {
    inT: 0,
    come(pg, id) { const c = pg.C(id), b = c.body, bs = pg.base(c); pg.show(id); b.position.y = bs.y + FALL_H; c.fallT = 0; },
    stay() {},
    go(pg, id) {   // reached the ground: a small bounce, then it fades away
      const c = pg.C(id), b = c.body, bs = pg.base(c);
      pg.tween(0.7, (t) => { b.position.y = bs.y + 0.02 * Math.sin(Math.PI * t); b.scale.setScalar(Math.max(0.001, 1 - easeInOut(t))); }, () => { pg.hide(id); b.position.y = bs.y; b.scale.setScalar(1); });
    },
  },
};
const FALL_H = 0.3;   // how high above their place the falling ones start (page widths)
// how high above its own place a target comes out: over the front pieces it hides behind ("behind"), else "lift"
function liftOf(pg, g, id) {
  const c = pg.C(id);
  if (c.popLift !== undefined) return c.popLift;
  let L = typeof g.lift === 'number' ? g.lift * c.h : (g.style === 'fly' ? 0.02 : 0);
  if (typeof g.lift !== 'number') for (const k of [].concat(g.behind || [])) {
    const f = pg.C(k); if (!f) continue;
    const overlap = Math.min(c.m.x + c.m.w, f.m.x + f.m.w) - Math.max(c.m.x, f.m.x);
    if (overlap > 0 && f.m.y + f.m.h > c.m.y + c.m.h) L = Math.max(L, f.h * 0.85);
  }
  return (c.popLift = L);
}
const popStyle = (g) => POP_STYLE[g.type === 'fall' ? 'fall' : g.style] || POP_STYLE.rise;
const popTimes = (g) => param(g, 'times', 'popTimes');
// a target out now that is close enough to the touch (the tool reaches a little farther than a hand)
const GRACE = 0.5;   // seconds a target that has started to go back can still be caught
const catchable = (pg) => [...Object.keys(pg.gs.up), ...Object.keys(pg.gs.leaving).filter((id) => pg.time - pg.gs.leaving[id] < GRACE)];
function nearTarget(pg, g, hit) {
  if (!hit) return null;
  let best = null, bd = reach(pg);
  for (const id of catchable(pg)) {
    const d = pg.top(id, 0.5).distanceTo(hit.point);
    if (d < bd) { bd = d; best = id; }
  }
  return best;
}
// a place inside the box, not too close to the ones already there (and not in a neat row either)
function boxSlot(pg, box, size) {
  const used = pg.gs.slots, minD = Math.max(size * 1.4, box.w * 0.2);
  let best = null, bestD = -1;
  for (let k = 0; k < 24; k++) {
    const p = new THREE.Vector3((Math.random() - 0.5) * box.w * 0.56, box.h * (0.12 + Math.random() * 0.5), 0);
    const d = used.length ? Math.min(...used.map((q) => Math.hypot(q.x - p.x, q.y - p.y))) : 1;
    if (d >= minD) { best = p; break; }
    if (d > bestD) { bestD = d; best = p; }
  }
  used.push(best);
  return best.clone();
}
// a caught one goes into the "into" piece and stays there (glowing ones keep glowing; the piece lights up a little more)
function intoBox(pg, g, id) {
  const box = pg.C(g.into), c = pg.C(id); if (!box || !c) return;
  const n = pg.gs.inside.length; if (n >= 14) return;
  const mesh = new THREE.Mesh(c.mesh.geometry, cardMaterial(c.mesh.material.map));
  const k = Math.min(0.55, (box.w * 0.32) / c.w); mesh.renderOrder = 2;
  const slot = boxSlot(pg, box, c.w * k);
  slot.z = 0.0012 + n * 0.0001;
  if (box.m.pivot === 'top') slot.y -= box.h;
  const glow = c.m.glow ? new THREE.Mesh(new THREE.PlaneGeometry(c.w * 1.6, c.w * 1.6), new THREE.MeshBasicMaterial({ map: glowTexture(), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending })) : null;
  const from = pg.top(id, 0.5);
  pg.root.add(mesh); pg._extras.push(mesh);
  pg.tween(0.8, (t) => {
    const to = box.body.localToWorld(slot.clone()); pg.root.worldToLocal(to);
    const e = easeInOut(t), p = from.clone().lerp(to, e).add(pg.up.clone().multiplyScalar(0.08 * Math.sin(Math.PI * t)));
    const s = 1 + (k - 1) * e; mesh.scale.set(s, s, 1);
    mesh.position.copy(p); mesh.quaternion.copy(box.body.getWorldQuaternion(new THREE.Quaternion()));
    const pq = pg.root.getWorldQuaternion(new THREE.Quaternion()).invert(); mesh.quaternion.premultiply(pq);
  }, () => {
    pg.root.remove(mesh); mesh.position.copy(slot); mesh.quaternion.identity(); mesh.scale.set(k, k, 1); mesh.userData.caught = true; box.body.add(mesh);
    if (glow) { glow.position.set(slot.x, slot.y + c.h * k * 0.4, slot.z - 0.0004); glow.userData.caught = true; glow.userData.born = pg.time; glow.material.opacity = 0; box.body.add(glow); pg.gs.glows.push(glow); }
    pg.gs.inside.push(mesh); pg.pulse(g.into, 1.06, 0.5); pg.sfx('po');
    if (c.m.glow || g.intoLight) { light(pg, g.into, true); pg.later(600, () => { if (box.lamp) box.lamp.material.opacity = Math.min(1, 0.3 + 0.1 * pg.gs.inside.length); }); }
  });
}
function popGame(type) {
  return {
    texts: (g) => wordsOf(g.word, ['ポン！', 'タッチ！']).map((x) => said(x, g.color || '#e8756a')),
    init(pg, g) {
      pg.gs.up = {}; pg.gs.leaving = {}; pg.gs.caught = 0; pg.gs.nextAt = 0; pg.gs.inside = []; pg.gs.glows = []; pg.gs.slots = [];
      g.targets.forEach((t) => pg.C(t) && pg.hide(t));
      const box = g.into && pg.C(g.into);   // (from the last time: the ones in the box go)
      if (box) box.body.children.filter((o) => o.userData.caught).forEach((o) => box.body.remove(o));
    },
    play(pg, g) { pg.gs.nextAt = pg.time + 0.8 + toolStart(pg, g); },
    open(pg, g) { if (pg.playing && hasTool(g) && !pg.gs.tool) pg.gs.nextAt = Math.max(pg.gs.nextAt, pg.time + toolStart(pg, g)); },
    update(pg, g, dt) {
      for (const g2 of pg.gs.glows) g2.material.opacity = Math.min(1, (pg.time - g2.userData.born) / 0.6) * (0.55 + 0.35 * Math.sin(pg.time * 3 + g2.id));
      if (pg.gs.done || pg.gs.finishing || !pg.playing || !pg.open) return;
      const S = popStyle(g), stay = param(g, 'stay');
      for (const [id, t0] of Object.entries(pg.gs.up)) {
        const e = pg.time - t0;
        if (type === 'fall') {   // falling: "stay" × 2 seconds from the sky to the ground
          const c = pg.C(id), b = c.body, bs = pg.base(c), fallT = stay * 2;
          b.position.y = bs.y + FALL_H * Math.max(0, 1 - e / fallT); b.rotation.z = 0.15 * Math.sin(e * 2.5);
          if (e >= fallT) { delete pg.gs.up[id]; pg.gs.leaving[id] = pg.time; b.rotation.z = 0; S.go(pg, id); pg.sfx('po'); }
          continue;
        }
        if (e > S.inT) S.stay(pg, id, e - S.inT, liftOf(pg, g, id));
        if (e > S.inT + stay) { delete pg.gs.up[id]; pg.gs.leaving[id] = pg.time; S.go(pg, id); }
      }
      if (pg.time < pg.gs.nextAt || Object.keys(pg.gs.up).length >= (g.together || 1)) return;
      const free = g.targets.filter((t) => pg.C(t) && !pg.gs.up[t] && !pg.C(t).body.visible);
      for (const t of free) delete pg.gs.leaving[t];
      if (!free.length) return;
      const id = free[Math.floor(Math.random() * free.length)];
      pg.gs.up[id] = pg.time; S.come(pg, id, type === 'fall' ? 0 : liftOf(pg, g, id)); pg.sfx(g.upSound || (type === 'fall' ? 'sui' : 'pyoko'));
      pg.gs.nextAt = pg.time + S.inT + stay * 0.6 + 0.4;
    },
    tap(pg, g, id, hit) {
      const mine = g.targets.includes(id) || [].concat(g.behind || []).includes(id) || id === 'plate' || id === g.into;
      if (pg.gs.done) return false;
      if (pg.gs.finishing) return g.targets.includes(id);
      const t = g.targets.includes(id) && catchable(pg).includes(id) ? id : nearTarget(pg, g, hit);
      if (!t) { if (mine && hasTool(g)) { toolSwing(pg, g, hit && hit.point); return true; } return g.targets.includes(id); }
      const at = pg.top(t, 0.5);
      delete pg.gs.up[t]; delete pg.gs.leaving[t]; pg.gs.caught++; progressed(pg);
      toolSwing(pg, g, at);
      const r = g.react && g.react[t];
      if (r) react(pg, t, r, null, { free: true }); else pg.sfx(g.sound || 'pon');
      pg.ono(pick(g.word || ['ポン！', 'タッチ！'], nextIdx(pg, 'pop')), pg.top(t, 1.0), g.color || '#e8756a');
      const c = pg.C(t), b = c.body, bs = pg.base(c);
      if (g.into && pg.C(g.into)) {
        pg.burst(t, 10, 0.8, ['#fff2a8', '#ffffff']);
        intoBox(pg, g, t);
        pg.later(120, () => { pg.hide(t); b.position.set(bs.x, bs.y, bs.z); b.rotation.z = 0; b.scale.setScalar(1); });
      } else if (type === 'fall') {
        pg.burst(t, 14, 1.0);
        pg.tween(0.4, (k) => b.scale.setScalar(1 - k), () => { pg.hide(t); b.position.set(bs.x, bs.y, bs.z); b.rotation.z = 0; b.scale.setScalar(1); });
      } else {
        pg.burst(t, 14, 1.0);
        pg.later(250, () => { b.rotation.z = 0; POP_STYLE.rise.go(pg, t); });
      }
      if (g.count) setCount(g.count, pg.gs.caught);
      const times = popTimes(g);
      pg.progress(Math.min(pg.gs.caught, times), times);
      if (pg.gs.caught >= times) {
        pg.gs.finishing = true;
        // everyone comes out to celebrate (not the ones that went into a box)
        pg.later(900, () => { if (!g.into) g.targets.forEach((x, i) => pg.C(x) && pg.later(i * 120, () => (type === 'fall' ? POP_STYLE.rise : popStyle(g)).come(pg, x, type === 'fall' ? 0 : liftOf(pg, g, x)))); goalDone(pg, g); });
      }
      return true;
    },
  };
}

// ---------- さがす: hiding, coming out ----------
const findKey = (it) => it.item || it.spot;
const AREA_MORE = 0.2;
// "main": the others wait (no calls, no hints) until the main one is found
const waitsForMain = (pg, it) => !!(pg.gs.mainId && it.item !== pg.gs.mainId && !pg.gs.found[pg.gs.mainId]);
// does it come out in front (it stands on the ground: 人・ねこ) or peek out where it is (up in a tree, flying, glowing)?
function comeOutMode(pg, it, spotId, feetY) {
  if (it.comeOut === 'front' || it.comeOut === 'here') return it.comeOut;
  const c = pg.C(it.item), s = pg.C(spotId);
  if (!c || !s || c.m.glow || ['fly', 'float'].includes(c.m.idle) || (c.m.pivot && c.m.pivot !== 'bottom')) return 'here';
  if ((s.m.pivot && s.m.pivot !== 'bottom') || s.m.flat || s.pvy < 600) return 'here';   // (a cloud in the sky, a hanging thing)
  return (feetY ?? c.pvy) >= s.pvy - 60 ? 'front' : 'here';
}
// hide at a place: "front" ones stand (hidden) just behind the spot, "here" ones go on the spot (behind it)
function hideAt(pg, it, pl) {
  const s = pg.C(pl.spot), c = pg.C(it.item); if (!s || !c) return;
  const [x, y] = pl.at || [s.pvx, s.pvy];
  if (comeOutMode(pg, it, pl.spot, y) === 'front') pg.placePiece(it.item, null, [x, Math.min(y, s.pvy - 14)]);
  else pg.placePiece(it.item, pl.spot, [x, y], { behind: true });
  pg.hide(it.item);
  const flip = (id) => { const k = pg.C(id); k.flipX = pl.flip ? -1 : 1; k.still.scale.x = k.flipX * Math.abs(k.still.scale.x); };
  flip(it.item);
  // the clue: a little of it shows at the edge of the place ("peek": where its bottom is, page pixels) — it is put
  // behind the place's picture, so only the part out of the picture is seen (やたいの はしから あたまが ちらっと)
  if (it.clue && pg.C(it.clue)) {
    pg.placePiece(it.clue, pl.spot, pl.peek || [x, y], { behind: true }); pg.hide(it.clue); flip(it.clue);
  }
}
// ---------- さがす: hiding in a part of a big piece ----------
// A spot much bigger than the one hiding there is cut into parts: 3 × 3 when it is 2 times as big or more, 2 × 2
// when 1.4 times or more (the smaller of the width and the height ratios; "split": 1 / 4 / 9 to choose). It hides in
// one part — not the middle one nor the bottom middle one (nothing to peek out of there), another one each time —
// with a little of it (PEEK of its size) showing past the edge of the spot there: over the top in the top row, at
// the side in the others. Touching that part (or the bit that shows) finds it; the hint shines there.
const PEEK = 0.18;
function splitOf(pg, it, spotId) {
  if (it.split !== undefined) return [4, 9].includes(it.split) ? it.split : 1;
  const s = pg.C(spotId), c = pg.C(it.item); if (!s || !c) return 1;
  const [x0, y0, x1, y1] = pg.seenBox(s), [a0, b0, a1, b1] = pg.seenBox(c);
  const r = Math.min((x1 - x0) / Math.max(1, a1 - a0), (y1 - y0) / Math.max(1, b1 - b0));
  return r >= 2 ? 9 : r >= 1.4 ? 4 : 1;
}
const median = (a) => { const b = a.filter((v) => v !== null).sort((p, q) => p - q); return b.length ? b[b.length >> 1] : null; };
// where the spot's picture begins, coming from above at x (its top edge) or from the left / right at y (its sides)
function topEdge(pg, id, x0, x1, ya, yb) {
  const col = (x) => { for (let y = ya; y < yb; y += 3) if (pg.solidAt(id, x, y)) return y; return null; };
  const out = []; for (let x = x0; x <= x1; x += Math.max(2, (x1 - x0) / 12)) out.push(col(x));
  return median(out);
}
function sideEdge(pg, id, k, y0, y1, xa, xb) {
  const row = (y) => { if (k < 0) { for (let x = xa; x < xb; x += 3) if (pg.solidAt(id, x, y)) return x; } else { for (let x = xb; x > xa; x -= 3) if (pg.solidAt(id, x, y)) return x; } return null; };
  const out = []; for (let y = y0; y <= y1; y += Math.max(2, (y1 - y0) / 12)) out.push(row(y));
  return median(out);
}
// the parts of the spot it can hide in, and where it stands (behind the spot) so that a little of it shows
function hidingParts(pg, it, spotId, n) {
  const s = pg.C(spotId), c = pg.C(it.item), [sx0, sy0, sx1, sy1] = pg.seenBox(s), [a0, b0, a1, b1] = pg.seenBox(c);
  const X0 = s.m.x + sx0, Y0 = s.m.y + sy0, X1 = s.m.x + sx1, Y1 = s.m.y + sy1, k = n === 9 ? 3 : 2;
  const cw = (X1 - X0) / k, ch = (Y1 - Y0) / k, W = a1 - a0, H = b1 - b0, foot = s.pvy;
  const front = inFront(pg, spotId, it.item), out = [];
  for (let r = 0; r < k; r++) for (let q = 0; q < k; q++) {
    if (k === 3 && q === 1 && r >= 1) continue;   // the middle and the bottom middle
    const area = [X0 + q * cw, Y0 + r * ch, X0 + (q + 1) * cw, Y0 + (r + 1) * ch];
    let fx, fy, dx = 0, dy = 0;   // where its feet are, and which way is deeper behind the spot
    if (r === 0) {   // over the top
      const cx = Math.max(X0 + W / 2, Math.min(X1 - W / 2, (area[0] + area[2]) / 2));
      const edge = topEdge(pg, spotId, cx - W / 4, cx + W / 4, Y0, Y1) ?? Y0;
      fx = cx + (c.m.w / 2 - (a0 + a1) / 2); fy = edge - PEEK * H + c.m.h - b0; dy = H * 0.04;
    } else {   // at the side: the left column out to the left, the right one out to the right
      const side = q === 0 ? -1 : 1;
      const cy = r === k - 1 ? foot - H / 2 : (area[1] + area[3]) / 2;
      const edge = sideEdge(pg, spotId, side, cy - H / 4, cy + H / 4, X0, X1) ?? (side < 0 ? X0 : X1);
      fx = side < 0 ? edge - PEEK * W - a0 + c.m.w / 2 : edge + PEEK * W + c.m.w / 2 - a1;
      fy = Math.min(foot - 4, cy + c.m.h - (b0 + b1) / 2); dx = -side * W * 0.04;
    }
    // the picture of the spot is not the same everywhere (roofs, a round tree): move it until about a sixth shows
    let share = shownShare(pg, it.item, fx, fy, spotId, front);
    for (let t = 0; t < 14 && share > 0.24; t++) { fx += dx; fy = Math.min(foot - 4, fy + dy); share = shownShare(pg, it.item, fx, fy, spotId, front); }
    for (let t = 0; t < 14 && share < 0.07; t++) { fx -= dx; fy -= dy; share = shownShare(pg, it.item, fx, fy, spotId, front); }
    if (share < 0.04 || share > 0.3) continue;   // it can not peek out a little here
    // where the spot is drawn in this part (a tree is not square): the middle of that shines for the hint
    let n = 0, sx = 0, sy = 0;
    for (let j = 0; j < 8; j++) for (let i = 0; i < 8; i++) {
      const x = area[0] + (area[2] - area[0]) * (i + 0.5) / 8, y = area[1] + (area[3] - area[1]) * (j + 0.5) / 8;
      if (pg.solidAt(spotId, x, y) && !hides(pg, front, x, y)) { n++; sx += x; sy += y; }
    }
    if (n < 10) continue;   // hardly any of the spot to touch here
    out.push({ spot: spotId, area, at: [fx, fy], part: { r, q, k }, peeks: true, center: [sx / n, sy / n], peekAt: peekOf(pg, it.item, fx, fy, spotId, front).at });
  }
  return out;
}
// the pieces in front of the spot, which hide what is behind: the ones on it (a pinwheel on the stall) where they are
// drawn, and the ones standing before it — standing up nearer, they hide more of it, up to about as far again
// as they stand before it (page pixels)
function inFront(pg, spotId, itemId) {
  const s = pg.C(spotId), y = (o) => (o.m.parent && pg.C(o.m.parent) ? pg.C(o.m.parent).pvy : o.pvy);
  return Object.values(pg.cards).filter((o) => o.id !== spotId && o.id !== itemId && o.body.visible && !o.flat && !o.m.flat
    && (o.m.parent === spotId ? !o.m.behind : y(o) > s.pvy + 2))
    .map((o) => ({ id: o.id, up: o.m.parent === spotId ? 0 : (y(o) - s.pvy) * 0.8, box: [o.m.x, o.m.y, o.m.x + o.m.w, o.m.y + o.m.h] }));
}
const hides = (pg, front, x, y) => front.some((f) => (f.up ? x > f.box[0] && x < f.box[2] && y > f.box[1] - f.up && y < f.box[3] : pg.solidAt(f.id, x, y)));
// how much of the hiding one shows (not behind the spot, nor behind a piece in front) with its feet at (fx, fy),
// and where the bit that shows is (its middle, page px)
function peekOf(pg, itemId, fx, fy, spotId, front) {
  const c = pg.C(itemId), a = pg.alpha[c.mesh.userData.tex]; if (!a) return { share: 0, at: null };
  const x0 = fx - c.m.w / 2, y0 = fy - c.m.h;
  let on = 0, seen = 0, sx = 0, sy = 0;
  for (let j = 0; j < 16; j++) for (let i = 0; i < 16; i++) {
    const u = (i + 0.5) / 16, v = (j + 0.5) / 16;
    if (a.data[Math.floor(v * a.h) * a.w + Math.floor(u * a.w)] <= 60) continue;
    on++;
    const px = x0 + u * c.m.w, py = y0 + v * c.m.h;
    if (!pg.solidAt(spotId, px, py) && !hides(pg, front, px, py)) { seen++; sx += px; sy += py; }
  }
  return { share: on ? seen / on : 0, at: seen ? [sx / seen, sy / seen] : null };
}
const shownShare = (pg, itemId, fx, fy, spotId, front) => peekOf(pg, itemId, fx, fy, spotId, front).share;
const overlap = (a, b) => {
  const w = Math.min(a[2], b[2]) - Math.max(a[0], b[0]), h = Math.min(a[3], b[3]) - Math.max(a[1], b[1]);
  return w > 0 && h > 0 ? (w * h) / Math.min((a[2] - a[0]) * (a[3] - a[1]), (b[2] - b[0]) * (b[3] - b[1])) : 0;
};
// how it comes out of a part: people and big ones walk out and stand in front ("front"); small ones in the top row
// stand on the spot there (a cat on the roof, a bird on the tree: "here"), and in the other parts walk out in
// front; things that are not characters (a glove), and ones that fly, glow or are up in the sky, come out on top
const isCharacter = (pg, id) => { const c = pg.C(id); return !!c && (isCast(id) || !!c.m.faces || c.m.tex.some((t) => /@(blink|talk)$/.test(t))); };
function partOut(pg, it, spotId, part) {
  if (it.comeOut === 'front' || it.comeOut === 'here') return it.comeOut;
  const c = pg.C(it.item), s = pg.C(spotId);
  if (comeOutMode(pg, it, spotId, s.pvy) === 'here' || !isCharacter(pg, it.item)) return 'here';
  if (pg.seenSize(c).h >= pg.seenSize(s).h * 0.45) return 'front';
  return part.r === 0 ? 'here' : 'front';
}
// hide in a part: behind the spot, peeking out a little (it shows when the game begins)
function hideInPart(pg, it, pl) {
  const c = pg.C(it.item);
  pg.placePiece(it.item, pl.spot, pl.at, { behind: true });
  pg.hide(it.item);
  c.stillNow = true; c.still.position.set(0, 0, 0);   // a firefly does not fly about while it hides
  pg.reach(it.item, NEAR);   // touching just beside the bit that shows finds it too
}
// ---------- さがす: where it stands when found ----------
// Found, it comes out to a place where at least SEEN of it can be seen (not behind the spot, nor behind what stands
// in front) and where it is not over another character (nor over one that is still peeking out). Looked for from the
// place it would go to first, a little farther each time; the places are tried nearest first.
const SEEN = 0.7, NEAR = 40;
// its picture's box (page px) with its feet at (fx, fy)
function boxAt(pg, c, fx, fy) {
  const [a0, b0, a1, b1] = pg.seenBox(c), x0 = fx - c.m.w / 2, y0 = c.m.pivot === 'top' ? fy : fy - c.m.h;
  return [x0 + a0, y0 + b0, x0 + a1, y0 + b1];
}
// what it must keep clear of: the characters there and the ones found before (where they are going, for ones found
// a moment ago), and the bits that show of the ones still hiding. Not a big one behind everything (the moon with
// a face, more than 4 times as big): in front of that is all right
function keepClear(pg, g, itemId) {
  const out = [], stand = pg.gs.stand || {}, me = boxAt(pg, pg.C(itemId), 0, 0), big = 4 * (me[2] - me[0]) * (me[3] - me[1]);
  for (const o of Object.values(pg.cards)) {
    if (o.id === itemId) continue;
    const pl = pg.gs.place && pg.gs.place[o.id];
    if (pl && pl.peeks && !pg.gs.found[o.id]) { if (pl.peekAt && o.body.visible) out.push([pl.peekAt[0] - 24, pl.peekAt[1] - 24, pl.peekAt[0] + 24, pl.peekAt[1] + 24]); continue; }
    const b = stand[o.id] || (o.body.visible && isCharacter(pg, o.id) ? boxAt(pg, o, o.pvx, o.pvy) : null);
    if (b && (stand[o.id] || (b[2] - b[0]) * (b[3] - b[1]) <= big)) out.push(b);
  }
  return out;
}
const clash = (box, others) => others.some((o) => overlap(box, o) > 0.12);
// what stands in front of a piece standing on the ground at fy (and hides it where they are drawn, and a little
// above that: the nearer, the more), not counting `skip`
function frontOfGround(pg, fy, skip) {
  const y = (o) => (o.m.parent && pg.C(o.m.parent) ? pg.C(o.m.parent).pvy : o.pvy);
  return Object.values(pg.cards).filter((o) => !skip.includes(o.id) && !skip.includes(o.m.parent) && o.body.visible && !o.flat && !o.m.flat
    && !(o.m.parent && o.m.behind) && y(o) > fy + 2).map((o) => ({ id: o.id, up: (y(o) - fy) * 0.8 }));
}
const coveredAt = (pg, cov, x, y) => cov.some((f) => pg.solidAt(f.id, x, y) || (f.up > 0 && (pg.solidAt(f.id, x, y + f.up / 2) || pg.solidAt(f.id, x, y + f.up))));
// how much of it is seen with its feet at (fx, fy): standing on the ground ("cov": frontOfGround), or on the spot
// behind its picture (spotId, and "cov": what is in front of the spot)
function seenShare(pg, c, fx, fy, cov, spotId) {
  const a = pg.alpha[c.mesh.userData.tex]; if (!a) return 1;
  const x0 = fx - c.m.w / 2, y0 = c.m.pivot === 'top' ? fy : fy - c.m.h;
  let on = 0, seen = 0;
  for (let j = 0; j < 12; j++) for (let i = 0; i < 12; i++) {
    const u = (i + 0.5) / 12, v = (j + 0.5) / 12;
    if (a.data[Math.floor(v * a.h) * a.w + Math.floor(u * a.w)] <= 60) continue;
    on++;
    const px = x0 + u * c.m.w, py = y0 + v * c.m.h;
    if (!(spotId && pg.solidAt(spotId, px, py)) && !(spotId ? hides(pg, cov, px, py) : coveredAt(pg, cov, px, py))) seen++;
  }
  return on ? seen / on : 1;
}
// the best of the places (nearest first): seen enough and clear of the others; else seen enough; else the one seen
// most. How much is seen is worked out only for the places tried ("see"), so it is quick
function bestPlace(cands, others) {
  cands.sort((p, q) => p.cost - q.cost);
  const seen = (p) => (p.seen === undefined ? (p.seen = p.see()) : p.seen);
  return cands.find((p) => !clash(p.box, others) && seen(p) >= SEEN)
    || cands.find((p) => seen(p) >= SEEN) || cands.reduce((m, p) => (!m || seen(p) > seen(m) ? p : m), null);
}
const pageX = (pg, c, cx) => { const [a0, , a1] = pg.seenBox(c); return cx - ((a0 + a1) / 2 - c.m.w / 2); };   // its feet x for its picture's middle at cx
const inPage = (pg, c, fx, fy) => { const b = boxAt(pg, c, fx, fy); return b[0] >= 8 && b[2] <= 1592 && b[1] >= 8; };
// on the spot's top edge (a cat on the roof): along the top, from where it is
function topPlace(pg, g, it, spotId) {
  const c = pg.C(it.item), s = pg.C(spotId), [a0, b0, a1, b1] = pg.seenBox(c), W = a1 - a0, H = b1 - b0;
  const [sx0, sy0, sx1, sy1] = pg.seenBox(s), X0 = s.m.x + sx0, X1 = s.m.x + sx1;
  const cov = inFront(pg, spotId, it.item), others = keepClear(pg, g, it.item), cx0 = c.pvx - c.m.w / 2 + (a0 + a1) / 2, cands = [];
  for (let i = 0; i < 9; i++) {
    const cx = cx0 + (i % 2 ? 1 : -1) * Math.ceil(i / 2) * W * 0.45;
    if (cx < X0 + W * 0.3 || cx > X1 - W * 0.3) continue;
    const edge = topEdge(pg, spotId, cx - W / 4, cx + W / 4, s.m.y + sy0, s.m.y + sy1) ?? (s.m.y + sy0);
    const fx = pageX(pg, c, cx), fy = edge + H * 0.08 + (c.m.h - b1);
    if (!inPage(pg, c, fx, fy)) continue;
    cands.push({ fx, fy, cost: Math.abs(cx - cx0), see: () => seenShare(pg, c, fx, fy, cov, spotId), box: boxAt(pg, c, fx, fy) });
  }
  return bestPlace(cands, others);
}
// on the ground a little in front of the spot: beside it (the nearer side first), in front of it, a little nearer
function groundPlace(pg, g, it, spotId) {
  const c = pg.C(it.item), s = pg.C(spotId), [a0, , a1] = pg.seenBox(c), W = a1 - a0;
  const [sx0, , sx1] = pg.seenBox(s), X0 = s.m.x + sx0, X1 = s.m.x + sx1, others = keepClear(pg, g, it.item);
  const cx0 = c.pvx - c.m.w / 2 + (a0 + a1) / 2, k = cx0 - X0 < X1 - cx0 ? -1 : 1;
  const y0 = Math.min(940, s.pvy + 34), cands = [], covs = {};
  for (const side of [k, -k]) {
    const edge = side < 0 ? X0 : X1;
    for (let i = -3; i < 5; i++) {   // i < 0: in front of the spot itself
      const cx = edge + side * (i >= 0 ? W * 0.15 + i * W * 0.6 : -W * 0.45 + (i + 1) * W * 0.6);
      for (let j = 0; j < 4; j++) {
        const fy = Math.min(940, y0 + j * 36), fx = pageX(pg, c, cx);
        if (!inPage(pg, c, fx, fy) || (j && fy === y0)) continue;
        const cov = () => covs[fy] || (covs[fy] = frontOfGround(pg, fy, [it.item, spotId]));
        const def = edge + side * W * 0.15;
        cands.push({ fx, fy, cost: Math.abs(cx - def) + (fy - y0) * 2 + (side !== k ? 80 : 0), see: () => seenShare(pg, c, fx, fy, cov()), box: boxAt(pg, c, fx, fy) });
      }
    }
  }
  return bestPlace(cands, others);
}

// a piece on another one (behind it) goes onto the page itself, just where it is seen now: up off the ground
// by as much as it stood up on the other one (page units). It is not seen to move
function liftOff(pg, c) {
  const p = pg.C(c.m.parent); if (!p) return 0;
  pg.root.updateMatrixWorld(true);
  const P = pg.root.worldToLocal(c.pivot.getWorldPosition(new THREE.Vector3()));
  const sn = Math.sin(p.theta), cs = Math.cos(p.theta), z0 = 0.0015 + c.order * 0.0005;
  const h = sn > 0.2 ? Math.max(0, (P.z - z0) / sn) : 0, y = P.y - h * cs;
  pg.placePiece(c.id, null, [(P.x + 0.5) * 1600, (0.375 - y) * 1600]);
  c.pivot.position.set(P.x, y, z0);
  return h;
}
// flying ones fly again little by little (not all at once from where they hid)
function wakeUp(c) { c.stillNow = false; c.idleK = 0; }

// found, it stays on the spot it hid on: it climbs (up onto the top edge there, or out at the side) to its place
function slideTo(pg, it, to) {
  const c = pg.C(it.item), from = [c.pvx, c.pvy], p0 = c.pivot.position.clone();
  pg.show(it.item);
  pg.tween(0.9, (t) => {
    const k = easeInOut(t);
    c.pivot.position.x = p0.x + (to.fx - from[0]) * S_PX * k;
    c.pivot.position.y = p0.y + (from[1] - to.fy) * S_PX * k;
  }, () => { c.pvx = to.fx; c.pvy = to.fy; pg.hop(it.item, 0.03); pg.burst(it.item, 20, 1.2); });
}
const S_PX = 1 / 1600;

// found: it comes out — on the spot's top ("here") or onto the ground in front of it ("front")
function comeOut(pg, g, it, spotId) {
  const c = pg.C(it.item), s = pg.C(spotId), pl = pg.gs.place[findKey(it)];
  wakeUp(c);
  pg.gs.stand = pg.gs.stand || {};
  const mode = pl && pl.part && s ? partOut(pg, it, spotId, pl.part) : !s ? 'here' : comeOutMode(pg, it, spotId, c.pvy);
  if (mode === 'here' && pl && pl.part) {   // up onto the top edge there (also from a part at the side); if it can not be seen enough there: popUp
    const to = topPlace(pg, g, it, spotId);
    if (to && to.seen >= SEEN) { pg.gs.stand[it.item] = to.box; return slideTo(pg, it, to); }
  }
  if (mode === 'here' || !s) return popUp(pg, g, it, spotId);
  const to = groundPlace(pg, g, it, spotId);
  if (!to) return popUp(pg, g, it, spotId);
  pg.gs.stand[it.item] = to.box;
  const h = c.m.parent ? liftOff(pg, c) : 0;
  walkOut(pg, it, c, s, to, h);
}
// it comes out where it hid, from behind the spot (a rabbit behind a cloud, an owl in the tree, a firefly in the
// bush): straight up until SEEN of it shows over the spot; only when there is no room up there (the top of the
// page) a little to the side. One that was not seen comes up from behind; one that was peeking out climbs up behind
// the spot. When the spot moves out of the way ("spotMove": the cloud slides away), it comes up just where it is
function popUp(pg, g, it, spotId) {
  const c = pg.C(it.item), s = pg.C(spotId), [a0, b0, a1, b1] = pg.seenBox(c), W = a1 - a0, H = b1 - b0;
  pg.gs.stand = pg.gs.stand || {};
  if (it.spotMove || !s) {
    pg.gs.stand[it.item] = boxAt(pg, c, c.pvx, c.pvy);
    pg.rise(it.item, -c.h, 1.1); pg.later(550, () => pg.burst(it.item, 20, 1.2));
    return;
  }
  if (!c.m.parent && !c.body.visible) pg.placePiece(it.item, spotId, [c.pvx, c.pvy], { behind: true });   // on the spot, behind its picture: up is up
  const on = c.m.parent && pg.C(c.m.parent) ? c.m.parent : null, peeking = c.body.visible, cands = [];
  const cov = on ? inFront(pg, on, it.item) : null, others = keepClear(pg, g, it.item);
  for (let i = 0; i < 11; i++) for (let j = 0; j < 16; j++) {
    const fx = c.pvx + (i % 2 ? 1 : -1) * Math.ceil(i / 2) * W * 0.4, fy = c.pvy - j * H * 0.1;
    if (!inPage(pg, c, fx, fy)) continue;
    const see = () => (on ? seenShare(pg, c, fx, fy, cov, on) : seenShare(pg, c, fx, fy, frontOfGround(pg, fy, [it.item])));
    cands.push({ fx, fy, cost: Math.abs(fx - c.pvx) * 4 + (c.pvy - fy), see, box: boxAt(pg, c, fx, fy) });   // up first, the side only after
  }
  const to = bestPlace(cands, others) || { fx: c.pvx, fy: c.pvy, box: boxAt(pg, c, c.pvx, c.pvy) };
  pg.gs.stand[it.item] = to.box;
  if (peeking && on) return slideTo(pg, it, to);
  if (to.fx !== c.pvx || to.fy !== c.pvy) pg.placePiece(it.item, on, [to.fx, to.fy], { behind: !!(on && c.m.behind) });
  pg.rise(it.item, -c.h, 1.1); pg.later(550, () => pg.burst(it.item, 20, 1.2));
}
// out from behind the spot: along behind it to its side (still up where it hid), down onto the ground, then
// a little forward to its place
function walkOut(pg, it, c, s, to, h0 = 0) {
  const [a0, , a1] = pg.seenBox(c), W = a1 - a0, [sx0, , sx1] = pg.seenBox(s), X0 = s.m.x + sx0, X1 = s.m.x + sx1;
  const x0 = c.pvx, y0 = c.pvy, cx = (X0 + X1) / 2;
  const k = to.fx < X0 ? -1 : to.fx > X1 ? 1 : (x0 < cx ? -1 : 1);
  const xs = Math.max(W / 2 + 10, Math.min(1590 - W / 2, k < 0 ? X0 - W / 2 - 8 : X1 + W / 2 + 8));
  const v = (x, y, h) => new THREE.Vector3(x / 1600 - 0.5, 0.375 - y / 1600, h);   // (z: how high up, page units)
  const pts = [v(x0, y0, h0), v(xs, y0, h0), v(xs, y0, 0), v(xs, to.fy, 0), v(to.fx, to.fy, 0)];
  pts[0].x = c.pivot.position.x; pts[0].y = pts[1].y = pts[2].y = c.pivot.position.y;
  const seg = pts.slice(1).map((p, i) => p.distanceTo(pts[i])), total = seg.reduce((a, b) => a + b, 0) || 1e-6;
  const b = c.body, bs = pg.base(c), dur = Math.min(1.35, 0.8 + total * 2), z = c.pivot.position.z;
  pg.show(it.item);
  pg.tween(dur, (t) => {
    let d = easeInOut(t) * total, i = 0;
    while (i < seg.length - 1 && d > seg[i]) { d -= seg[i]; i++; }
    const u = seg[i] ? Math.min(1, d / seg[i]) : 1, p = pts[i].clone().lerp(pts[i + 1], u);
    c.pivot.position.set(p.x, p.y, z);
    const jump = i === 1 && h0 > 0.01 ? Math.sin(Math.PI * u) * 0.02 : 0;   // down with a little jump
    b.position.y = bs.y + p.z + jump + (p.z > 0.001 ? 0 : Math.abs(Math.sin(t * Math.PI * 4)) * 0.014);   // とことこ
  }, () => {
    b.position.y = bs.y; c.pvx = to.fx; c.pvy = to.fy;
    c.pivot.position.set(pts[4].x, pts[4].y, z);
    if (c.shadow) c.shadow.position.set(c.pivot.position.x, c.pivot.position.y, 0.0008);
    pg.hop(it.item, 0.04); pg.burst(it.item, 18, 1.1);
  });
}
// not found for a while: it calls out from where it hides (the hint, or the spot), and the spot shakes a little
function callOut(pg, it) {
  const pl = pg.gs.place[findKey(it)], spot = pl ? pl.spot : it.spot;
  const from = it.clue && pg.C(it.clue) && pg.C(it.clue).body.visible ? it.clue : pl && pl.peeks ? it.item : spot;
  const call = it.call || {};
  if (call.say) pg.say(from, call.say, `call_${findKey(it)}`, call.who || it.item || spot);
  if (call.sound) pg.sfx(call.sound);
  pg.later(300, () => { pg.wobble(spot, 0.03, 0.7); if (it.clue && pg.C(it.clue) && pg.C(it.clue).body.visible) pg.hop(it.clue, 0.03); });
}

// ---------- えらぶ（クイズ）: one question, or "questions" one after another ----------
export const said = (text, color) => ({ kind: 'o', text, color });
export const told = (text, who) => ({ kind: 'b', text, who });
export const wordsOf = (w, kit) => [].concat(w || kit).filter((x) => typeof x === 'string');
const quizOf = (g) => (g.questions && g.questions.length ? g.questions.map((q) => ({ ...g, ...q, questions: undefined })) : [g]);
const answersOf = (q) => (q.answer === undefined || q.answer === null || q.answer === '' ? null : [].concat(q.answer));
const quizTotal = (g) => quizOf(g).reduce((n, q) => n + (answersOf(q) ? answersOf(q).length : 1), 0);

// ---------- the games ----------
// each: init(pg, g), tap(pg, g, id, hit) → true when the game used the touch, and optionally
// update(pg, g, dt), play(pg, g) (story time is over), grab / rub (finger moving over a piece),
// texts(g): the words and lines the game itself can show, with their colours (drawn before they are needed:
// presets.js pageTexts)
export const GOALS = {
  // さがす: "items": [{ "spot": the piece to touch, "item": the hidden piece that comes out, … }] — all found → cleared
  //   "area": [x1, y1, x2, y2] — only this part of the spot finds it (page pixels: 屋台の のれん・台の下 …)
  //   "places": [{ "spot", "area", "at": [x, y], "peek": [x, y], "flip": true }] — it hides at one of these places,
  //       another one each time the page is played ("at": where its feet are while it hides, behind the spot)
  //   "clue": a small hidden picture (ちらっと 見える 手がかり) shown at the place's "peek" — touching it finds it too
  //   "call": { "say": "いちろう〜", "after": 10 } — not found for a while (or after 3 misses): it calls out, its place shakes
  //   "comeOut": "front" — comes out from behind the spot and stands on the ground a little in front of it (人・ねこ);
  //              "here" — comes up from behind the spot where it is, over its top (とりが 木の 上に・うさぎが 雲の 上に;
  //              one peeking out at the side climbs up behind the spot). Not written: "front" when it stands on the ground
  //              (its feet about where the spot stands), "here" when it is up in the spot, flies or glows
  //   goal "main": the one the page is about (まいごの おかあさん): the hints and the calls are for it until it is
  //       found; found, a word says others are hiding too ("toast" of its item, or the kit's). Lines that change
  //       when it is found: "if": { "found": "<its id>" } (presets.js). No "main": all of them are the same
  //   goal "misses": [{ "spot", "area", "react" }] — something else is there (ヨーヨーが ぽよーん …);
  //   goal "miss": what a spot with nothing there does (default: it shakes, "いないみたい")
  // A touch finds it on its place, a little around the place too (AREA_MORE of its size), and on the bit of it that
  // shows or just beside it (NEAR px)
  find: {
    texts: (g) => [said(g.missWord || 'いないみたい', '#7a5aa0'), ...(g.items || []).flatMap((it) => [
      ...(it.word !== false ? [said(it.word || 'みつけた！', it.color || '#e8b21f')] : []),
      ...(it.call && typeof it.call.say === 'string' ? [told(it.call.say, it.call.who || it.item || it.spot)] : []),
      ...wordsOf(it.say).map((x) => told(x, it.who || it.item || it.spot))])],
    // would a touch on piece `id` (where: hit.at) find one that still hides?
    finds(pg, g, id, hit) {
      const at = hit && hit.at;
      const inArea = (a) => {
        if (!a || !at) return true;
        const mx = Math.max(24, (a[2] - a[0]) * AREA_MORE), my = Math.max(24, (a[3] - a[1]) * AREA_MORE);
        return at[0] >= a[0] - mx && at[0] <= a[2] + mx && at[1] >= a[1] - my && at[1] <= a[3] + my;
      };
      const on = (spot) => id === spot || (pg.C(id) && pg.C(id).m.parent === spot && !pg.C(id).m.behind);
      return g.items.some((x) => {
        const k = findKey(x); if (pg.gs.found[k]) return false;
        if (x.clue && id === x.clue) return true;
        const pl = pg.gs.place[k];
        if (pl && pl.peeks && id === x.item) return true;
        return pl ? (pl.part ? on(pl.spot) : id === pl.spot) && inArea(pl.area) : id === x.spot && inArea(x.area);
      });
    },
    init(pg, g) {
      pg.gs.found = {}; pg.gs.place = {}; pg.gs.callAt = {}; pg.gs.misses = 0; pg.gs.stand = {};
      pg.gs.mainId = g.main && g.items.some((it) => it.item === g.main) ? g.main : null;
      const cache = pg._hiding || (pg._hiding = {});   // where it can hide in a big spot does not change: worked out once
      for (const it of g.items) {
        if (it.item && pg.C(it.item)) pg.hide(it.item);
        if (it.clue && pg.C(it.clue)) pg.hide(it.clue);
        if (!it.item || !pg.C(it.item)) continue;
        const places = it.places && it.places.length ? it.places : it.spot ? [{ spot: it.spot, area: it.area }] : [];
        const pl = places[Math.floor(Math.random() * places.length)];
        if (!pl) continue;
        const n = pl.at || pl.peek || pl.area ? 1 : splitOf(pg, it, pl.spot);
        if (n > 1) {   // a part of a big spot, not one another item hides in
          const key = `${it.item}|${pl.spot}|${n}`;
          const all = cache[key] || (cache[key] = hidingParts(pg, it, pl.spot, n));
          const taken = Object.values(pg.gs.place).filter((p) => p.spot === pl.spot && p.part).map((p) => p.area);
          const parts = all.filter((p) => !taken.some((a) => overlap(a, p.area) > 0.3));
          const part = parts[Math.floor(Math.random() * parts.length)];
          if (part) { pg.gs.place[findKey(it)] = part; hideInPart(pg, it, part); continue; }
        }
        if (it.places && it.places.length) { pg.gs.place[findKey(it)] = pl; hideAt(pg, it, pl); }
      }
    },
    play(pg, g) {
      for (const it of g.items) {
        const k = findKey(it);
        if (it.clue && pg.C(it.clue) && !pg.gs.found[k]) { pg.show(it.clue); pg.gs.clueT = pg.time + 2; }
        const pl = pg.gs.place[k];
        if (pl && pl.peeks && !pg.gs.found[k]) { pg.show(it.item); pg.gs.clueT = pg.time + 2; }
        if (it.call && !waitsForMain(pg, it)) pg.gs.callAt[k] = pg.time + (it.call.after ?? 10);
      }
    },
    update(pg, g) {
      if (pg.gs.done || !pg.playing || !pg.open) return;
      for (const it of g.items) {
        const k = findKey(it);
        if (pg.gs.found[k]) continue;
        // the clue picture moves a little now and then, so it can be noticed
        if (it.clue && pg.C(it.clue) && pg.C(it.clue).body.visible && pg.time > (pg.gs.clueT || 0)) { pg.gs.clueT = pg.time + 3.5 + Math.random() * 2; pg.wobble(it.clue, 0.06, 0.6); }
        const pl = pg.gs.place[k];
        if (pl && pl.peeks && pg.C(it.item).body.visible && pg.time > (pg.gs.clueT || 0)) { pg.gs.clueT = pg.time + 3.5 + Math.random() * 2; pg.wobble(it.item, 0.06, 0.6); }
        if (it.call && pg.gs.callAt[k] !== undefined && (pg.time > pg.gs.callAt[k] || pg.gs.misses >= 3)) {
          pg.gs.misses = 0; pg.gs.callAt[k] = pg.time + (it.call.every ?? it.call.after ?? 10);
          callOut(pg, it);
        }
      }
    },
    tap(pg, g, id, hit) {
      // a found one standing in front of a place where another one still hides: the touch goes through to that place
      const foundOne = (x) => g.items.some((it) => it.item === x && pg.gs.found[findKey(it)]);
      if (hit && hit.behind && foundOne(id)) {
        const h = hit.behind.find((b) => !foundOne(b.id) && GOALS.find.finds(pg, g, b.id, b));
        if (h) { id = h.id; hit = h; }
      }
      const at = hit && hit.at;
      const inArea = (a, more = 0) => {
        if (!a || !at) return true;
        const mx = Math.max(more ? 24 : 0, (a[2] - a[0]) * more), my = Math.max(more ? 24 : 0, (a[3] - a[1]) * more);
        return at[0] >= a[0] - mx && at[0] <= a[2] + mx && at[1] >= a[1] - my && at[1] <= a[3] + my;
      };
      const on = (spot) => id === spot || (pg.C(id) && pg.C(id).m.parent === spot && !pg.C(id).m.behind);   // (a pinwheel on the stall)
      const finds = (x, more) => {
        const k = findKey(x); if (pg.gs.found[k]) return false;
        if (x.clue && id === x.clue) return true;
        const pl = pg.gs.place[k];
        if (pl && pl.peeks && id === x.item) return true;   // the bit of it that shows (or just beside it)
        return pl ? (pl.part ? on(pl.spot) : id === pl.spot) && inArea(pl.area, more) : id === x.spot && inArea(x.area, more);
      };
      const it = g.items.find((x) => finds(x, 0)) || g.items.find((x) => finds(x, AREA_MORE));
      if (!it) {
        if (pg.gs.done) return false;
        if (g.items.some((x) => (x.item === id && pg.gs.found[findKey(x)]) || x.clue === id)) return false;   // a found one: its own touch reaction
        const ms = (g.misses || []).find((m) => m.spot === id && inArea(m.area));
        if (ms) { progressed(pg); if (react(pg, id, ms.react || {}, hit, { free: true }) !== false) pg.gs.misses++; return true; }
        // a place to look, with nothing (left) there
        const looking = g.items.some((x) => !pg.gs.found[findKey(x)] && (x.spot === id || (x.places || []).some((p) => p.spot === id)));
        if (!looking) return false;
        progressed(pg);
        if (g.miss) { if (react(pg, id, g.miss, hit, { free: true }) !== false) pg.gs.misses++; }
        else { pg.gs.misses++; pg.wobble(id, 0.035, 0.6); pg.sfx('po'); pg.ono(g.missWord || 'いないみたい', hit && hit.point ? hit.point.clone().add(pg.up.clone().multiplyScalar(0.02)) : id, '#7a5aa0'); }
        return true;
      }
      const key = findKey(it), pl = pg.gs.place[key], spot = pl ? pl.spot : it.spot;
      pg.gs.found[key] = true; progressed(pg); pg.gs.misses = 0;
      pg.gs.foundIds = { ...(pg.gs.foundIds || {}), [it.item || it.spot]: true };   // for "if": { "found": … }
      if (it.clue && pg.C(it.clue)) { pg.burst(it.clue, 10, 0.7); pg.hide(it.clue); }
      if (it.spotMove && moveOf(pg, it.spotMove)) moveOf(pg, it.spotMove)(pg, spot);
      else pg.wobble(spot, 0.06, 0.9);
      if (it.item && pg.C(it.item)) pg.later(250, () => { comeOut(pg, g, it, spot); pg.sfx(it.sound || 'pon'); });
      if (it.swap) pg.spin(spot, 'y', 1, 1.2, () => pg.swap(spot, altKey(pg, spot, it.swap)));
      pg.sfx('kirarin');
      if (it.word !== false) pg.ono(it.word || 'みつけた！', pg.top(spot, 1.1), it.color || '#e8b21f');
      const sayer = it.who || it.item || spot;
      const by = it.who && pg.C(it.who) ? it.who : (it.item || spot);   // the bubble comes from the one who speaks
      if (it.say) pg.later(it.item ? 1300 : 800, () => pg.say(by, it.say, by, sayer));
      if (it.get) pg.later(1400, () => pg.getItem(it.get));   // もちもの
      if (it.react) react(pg, spot, it.react, null, { free: true }); // anything else (an effect, a mark, a light …)
      const n = Object.keys(pg.gs.found).length;
      pg.progress(n, g.items.length);
      if (g.count) setCount(g.count, n);
      pg.later(400, () => pg.sfx('found'));
      if (it.item && it.item === pg.gs.mainId && n < g.items.length) {   // the main one: now the others call, and a word says so
        for (const x of g.items) if (x.call && !pg.gs.found[findKey(x)]) pg.gs.callAt[findKey(x)] = pg.time + (x.call.after ?? 10);
        pg.later(2600, () => pg.toast(it.toast || 'みつけた！ ほかにも だれか かくれているみたい', 2800));
      }
      if (n === g.items.length) pg.later(it.item ? 2200 : 1500, () => goalDone(pg, g));
      return true;
    },
  },
  gather: {
    texts: (g) => [said(g.undoWord || 'あれれ？', '#7a5aa0')],
    init(pg) { pg.gs.ready = {}; },
    update(pg, g) {
      if (pg.gs.done || pg.gs.finishing) return;
      const W = windowOf(g, g.targets.length);
      for (const [id, t] of Object.entries(pg.gs.ready)) {
        const frac = 1 - (pg.time - t) / W;
        if (frac > 0) { pg.setGauge(`g_${id}`, frac, frac < 0.3); continue; }
        delete pg.gs.ready[id]; pg.removeGauge(`g_${id}`);
        const r = g.react && g.react[id];
        if (r && r.swap) pg.swap(id, pg.C(id).m.tex[0]);
        pg.sfx('undo');
        const u = g.undo && g.undo[id];
        if (u) react(pg, id, noSwap(u), null, { free: true, auto: true });
        else pg.ono(g.undoWord || 'あれれ？', id, '#7a5aa0');
        pg.progress(Object.keys(pg.gs.ready).length, g.targets.length);
        if (!pg.gs.told) { pg.gs.told = true; pg.toast(`じかんぎれ！ ${W}びょうの うちに ぜんぶ タッチしてね`, 3200); }
      }
    },
    tap(pg, g, id) {
      if (!g.targets.includes(id) || pg.gs.done || pg.gs.finishing) return false;
      const fresh = !pg.gs.ready[id];
      pg.gs.ready[id] = pg.time;
      if (fresh) {
        progressed(pg);
        pg.gauge(`g_${id}`, 'ring', id, g.readyWord || 'OK', '#5fc46a');
        const r = g.react && g.react[id];
        if (r && r.swap) pg.swap(id, altKey(pg, id, r.swap));
        if (r) react(pg, id, noSwap(r), null, { free: true });
        else { pg.hop(id, 0.05); if (isCast(id)) pg.sfx('meow', id); else pg.sfx('pon'); }
      } else {
        const a = g.again && g.again[id];
        if (a) { react(pg, id, noSwap(a), null, { free: true }); if (!a.sound) pg.sfx('ready'); }
        else { pg.wobble(id, 0.04, 0.6); pg.sfx('ready'); }
      }
      pg.setGauge(`g_${id}`, 1);
      const n = Object.keys(pg.gs.ready).length;
      pg.progress(n, g.targets.length);
      if (n === g.targets.length) {
        pg.gs.finishing = true;
        pg.later(600, () => { g.targets.forEach((t) => pg.removeGauge(`g_${t}`)); goalDone(pg, g); });
      }
      return true;
    },
  },
  // なんども タッチ: "target" again and again until the power bar is full.
  //   "team": ["ma", "hi", …] — みんなで: everyone in the team must be touched first (each keeps going for a while,
  //   like gather: 4 of them have the age's "seconds", more of them more: windowOf); only then does the target move.
  //   Touching the target keeps the team going.
  //   per team member: "react" (first touch), "again", "undo" (got tired), "win" (when the target moves)
  mash: {
    texts: (g) => [said('ふぅ…', '#7a5aa0'), said(g.stuckWord || 'びくとも しない', '#7a5aa0'), ...wordsOf(g.word, ['グッ', 'グイッ']).map((x) => said(x, g.color || '#e8756a'))],
    init(pg) { pg.gs.power = 0; pg.gs.ready = {}; },
    update(pg, g, dt) {
      if (pg.gs.done || pg.gs.moving) return;
      if (g.team) {
        const W = windowOf(g, (g.team || []).length);
        for (const [id, t] of Object.entries(pg.gs.ready)) {
          const frac = 1 - (pg.time - t) / W;
          if (frac > 0) { pg.setGauge(`m_${id}`, frac, frac < 0.3); continue; }
          // got tired: this one stops, and the power is lost
          delete pg.gs.ready[id]; pg.removeGauge(`m_${id}`);
          const r = g.react && g.react[id];
          if (r && r.swap) pg.swap(id, pg.C(id).m.tex[0]);
          pg.sfx('undo');
          const u = g.undo && g.undo[id];
          if (u) react(pg, id, noSwap(u), null, { free: true, auto: true }); else pg.ono('ふぅ…', id, '#7a5aa0');
          if (pg.labels.gauges.mash) { pg.gs.power = 0; pg.removeGauge('mash'); }
          pg.progress(Object.keys(pg.gs.ready).length, g.team.length);
          if (!pg.gs.toldTired) { pg.gs.toldTired = true; pg.toast('つかれちゃった！ もういちど みんなを タッチ', 3000); }
        }
      }
      if (!pg.gs.power) return;
      if (pg.time - (pg.gs.lastTap || 0) < 0.8) return; // only drains when you stop tapping
      pg.gs.power = Math.max(0, pg.gs.power - (g.decay ?? 0.04) * dt);
      pg.setGauge('mash', pg.gs.power);
    },
    tap(pg, g, id) {
      if (pg.gs.done || pg.gs.moving) return g.team && g.team.includes(id) && !pg.gs.done ? true : (id === g.target && !pg.gs.done);
      // みんなで: a team member joins in
      if (g.team && g.team.includes(id)) {
        const fresh = !pg.gs.ready[id];
        pg.gs.ready[id] = pg.time; progressed(pg);
        if (fresh) {
          pg.gauge(`m_${id}`, 'ring', id, g.readyWord || 'OK', '#ff8fb1');
          const r = g.react && g.react[id];
          if (r && r.swap) pg.swap(id, altKey(pg, id, r.swap));
          if (r) react(pg, id, noSwap(r), null, { free: true }); else { pg.hop(id, 0.04); pg.sfx(isCast(id) ? 'meow' : 'pon', id); }
        } else {
          const a = g.again && g.again[id];
          if (a) react(pg, id, noSwap(a), null, { free: true }); else { pg.wobble(id, 0.03, 0.6); pg.sfx('ready'); }
        }
        pg.setGauge(`m_${id}`, 1);
        const n = Object.keys(pg.gs.ready).length;
        pg.progress(n, g.team.length);
        if (n === g.team.length && !pg.labels.gauges.mash) {
          pg.gauge('mash', 'bar', g.target, g.gauge || 'ちから', '#ff5a4a', 1.08); pg.setGauge('mash', pg.gs.power);
          pg.toast('いまだ！ なんども タッチ！', 2600); pg.sfx('ready');
        }
        return true;
      }
      if (id !== g.target) return false;
      // みんなで: not everyone is pushing yet → it does not move
      if (g.team && Object.keys(pg.gs.ready).length < g.team.length) {
        pg.shake(g.target, 0.006, 0.7); pg.sfx('gugu'); pg.onoAround(g.stuckWord || 'びくとも しない', g.target, '#7a5aa0');
        if (!pg.gs.toldTeam) { pg.gs.toldTeam = true; pg.toast('まずは みんなを タッチ！', 2600); }
        return true;
      }
      if (g.team) for (const t of g.team) { pg.gs.ready[t] = pg.time; pg.wobble(t, 0.025, 0.3); } // cheering keeps everyone going
      if (!pg.labels.gauges.mash) pg.gauge('mash', 'bar', g.target, g.gauge || 'ちから', '#ff5a4a', 1.08);
      pg.gs.lastTap = pg.time; progressed(pg);
      pg.gs.power = Math.min(1, pg.gs.power + 1 / param(g, 'times') + 1e-6);
      pg.setGauge('mash', pg.gs.power);
      // each touch: the target shakes, or does "tapMove" (a kit move or this page's own move)
      if (g.tapMove && moveOf(pg, g.tapMove)) moveOf(pg, g.tapMove)(pg, g.target, null, g); else pg.shake(g.target, 0.006, 0.3);
      pg.sfx(g.sound || 'gu');
      pg.onoAround(pick(g.word || ['グッ', 'グイッ'], nextIdx(pg, 'mash')), g.target, g.color || '#e8756a');
      if (pg.gs.power >= 1) {
        pg.gs.moving = true;
        pg.removeGauge('mash');
        (g.team || []).forEach((t, i) => {
          pg.removeGauge(`m_${t}`);
          const w = g.win && g.win[t];
          if (w) pg.later(250 + i * 90, () => react(pg, t, w, null, { free: true, auto: true }));
        });
        const away = g.doneMove || 'rollAway';
        const c = pg.C(g.target), b = c.body, hh = c.h / 2;
        if (away === 'rollAway') { pg.sfx('gorogoro'); pg.tween(1.4, (t) => { const k = 1 - Math.pow(1 - t, 2), a = -Math.PI * 2 * k; b.rotation.z = a; b.position.x = 0.2 * k + hh * Math.sin(a); b.position.y = hh * (1 - Math.cos(a)); }); }
        else if (away === 'flyAway') { pg.sfx('boing'); pg.tween(1.2, (t) => { b.position.y = t * t * 0.5; b.rotation.z = t * 2; }, () => pg.hide(g.target)); }
        else if (away === 'pop') { pg.sfx('pon'); pg.burst(g.target, 30, 1.4); pg.hide(g.target); }
        else if (away !== 'none' && moveOf(pg, away)) moveOf(pg, away)(pg, g.target, null, g);   // a move of the kit or of this page
        pg.later(g.team && g.win ? 2400 : 1200, () => goalDone(pg, g));   // (a team falls over and gets up first)
      }
      return true;
    },
  },
  // じゅんばんに タッチ: "targets" in order; a wrong one wobbles (with "strict", it starts again)
  order: {
    texts: (g) => [said(g.wrongWord || 'ちがうよ', '#7a5aa0'), ...(g.targets || []).map((t, i) => said(pick(g.words || [String(i + 1)], i), g.color || '#e8b21f'))],
    init(pg) { pg.gs.next = 0; },
    tap(pg, g, id) {
      const i = g.targets.indexOf(id);
      if (i < 0 || pg.gs.done) return false;
      if (i < pg.gs.next) return false; // already done → its normal touch reaction
      if (i === pg.gs.next) {
        pg.gs.next++; progressed(pg);
        const r = g.react && g.react[id];
        if (r) react(pg, id, r, null, { free: true }); else { pg.hop(id, 0.05); pg.sfx('pon'); }
        pg.ono(pick(g.words || [String(i + 1)], i), pg.top(id, 1.05), g.color || '#e8b21f');
        pg.gauge(`o_${id}`, 'ring', id, String(i + 1), '#5fc46a'); pg.setGauge(`o_${id}`, 1);
        pg.progress(pg.gs.next, g.targets.length);
        if (pg.gs.next === g.targets.length) pg.later(900, () => { g.targets.forEach((t) => pg.removeGauge(`o_${t}`)); goalDone(pg, g); });
      } else {
        pg.wobble(id, 0.06, 0.8); pg.sfx('undo'); pg.ono(g.wrongWord || 'ちがうよ', id, '#7a5aa0');
        if (param(g, 'strict') && pg.gs.next > 0) {
          g.targets.forEach((t) => pg.removeGauge(`o_${t}`));
          pg.gs.next = 0; pg.progress(0, g.targets.length);
          pg.toast(g.again || 'さいしょから もういちど', 2200);
        }
      }
      return true;
    },
  },
  // えらぶ（クイズ）: "question", "options" (pieces), "answer"
  //   no "answer": any one is right (えらぶだけ). "remember": "gift" keeps what was chosen for later pages ("{gift}" in texts)
  // えらぶ（クイズ）: "question", "options", "answer" — or "answer": [ … ] (several are right: find them all),
  //   or "questions": [{ "question", "answer", "options", "right", "wrong" }, …] asked one after another (all right → cleared).
  //   No "answer": whatever is chosen is the choice ("remember": what was chosen, for other pages)
  choose: {
    texts: (g) => [said('もう みつけたよ', '#7a5aa0'), ...quizOf(g).flatMap((q) => [
      said(q.rightWord || (answersOf(q) ? 'せいかい！' : 'これに きめた！'), '#e8b21f'), said(q.wrongWord || 'ちがうみたい', '#7a5aa0'),
      ...(q.who && typeof q.question === 'string' ? [told(q.question, q.who)] : [])])],
    init(pg) { pg.gs.q = 0; pg.gs.got = {}; pg.gs.right = 0; },
    play(pg, g) { pg.later(500, () => ask(pg, quizOf(g)[pg.gs.q] || g)); },
    tap(pg, g, id) {
      const Q = quizOf(g), q = Q[pg.gs.q];
      if (!q || pg.gs.done || !(q.options || []).includes(id)) return false;
      if (pg.gs.next) return true;   // (the next question is coming)
      const ans = answersOf(q);
      if (!ans || ans.includes(id)) {
        if (ans && pg.gs.got[id]) { pg.hop(id, 0.04, 0.6); pg.ono('もう みつけたよ', id, '#7a5aa0'); return true; }
        pg.gs.got[id] = true; pg.gs.right++; pg.gs.chosen = id; progressed(pg);
        if (!ans && q.remember) remember(q.remember, id, (q.names && q.names[id]) || itemOf(id).name);
        const r = (q.react && q.react[id]) || q.right;   // "react": { "<option>": { … } } for each one, or "right" for any
        if (r) react(pg, id, r, null, { free: true }); else { pg.hop(id, 0.08, 0.75); pg.sfx('kirarin'); }
        if (!(r && r.word)) pg.ono(q.rightWord || (ans ? 'せいかい！' : 'これに きめた！'), pg.top(id, 1.1), '#e8b21f'); pg.burst(id, 20, 1.2);
        pg.progress(pg.gs.right, quizTotal(g));
        const left = ans ? ans.filter((a) => !pg.gs.got[a]).length : 0;
        if (left > 0) { pg.later(700, () => pg.toast(`あと ${left}つ！`, 1800)); return true; }
        if (pg.gs.q + 1 < Q.length) {   // the next question
          pg.gs.next = true;
          pg.later(1900, () => { pg.gs.q++; pg.gs.got = {}; pg.gs.next = false; pg.toast(`${pg.gs.q + 1}もんめ`, 1400); pg.later(300, () => ask(pg, Q[pg.gs.q])); });
        } else pg.later(900, () => goalDone(pg, g));
      } else {
        const w = q.wrong && q.wrong[id];
        if (w) react(pg, id, w, null, { free: true });
        else { pg.wobble(id, 0.06, 0.8); pg.sfx('undo'); pg.ono(q.wrongWord || 'ちがうみたい', id, '#7a5aa0'); }
      }
      return true;
    },
  },
  // でてきたら タッチ: "targets" (hidden pieces) come out one by one and go back; touch them while they are out.
  //   "style": "rise" (下から ぴょこっ: もぐら) / "swim" (よこから 泳いで来て もぐる: 金魚) / "fly" (ふわっと 飛んで来て 光る: ほたる)
  //   "behind": the front pieces they hide behind (穴・水そうの ふち・草) — touching those also catches one nearby
  //   "into": a piece the caught ones go into and stay (金魚ばち・かご・びん)
  //   "tool": 道具と手 (tool.js);  "count": "fish" — the number caught, for other pages ({fish}, "if": { "fish": 3 })
  pop: popGame('pop'),
  // おちてくる ものを キャッチ: "targets" fall from the sky; touch them before they reach the ground (same options as pop)
  fall: popGame('fall'),
  // そだてる: tap "target" "times" times for each of the "stages" (pictures <target>@<stage>)
  grow: {
    texts: (g) => wordsOf(g.words).map((x) => said(x, g.color || '#5fc46a')),
    init(pg) { pg.gs.stage = 0; pg.gs.n = 0; },
    tap(pg, g, id) {
      if (id !== g.target || pg.gs.done) return false;
      const times = param(g, 'times', 'growTimes'), stages = g.stages || [];
      if (pg.gs.stage >= stages.length) return true;   // grown up: the clear comes in a moment
      if (!pg.labels.gauges.grow) pg.gauge('grow', 'bar', g.target, g.gauge || 'そだつ', '#5fc46a', 1.08);
      pg.gs.n++; progressed(pg);
      pg.pulse(id, 1.08, 0.6); pg.sfx(g.sound || 'pon');
      pg.setGauge('grow', pg.gs.n / times);
      if (pg.gs.n < times) return true;
      pg.gs.n = 0; const s = stages[pg.gs.stage++];
      pg.spin(id, 'y', 1, 1.0, () => pg.swap(id, altKey(pg, id, s)));
      pg.sfx('kirarin'); pg.later(350, () => pg.burst(id, 18, 1.1));
      if (g.words) pg.onoAround(pick(g.words, pg.gs.stage - 1), id, g.color || '#5fc46a');
      pg.progress(pg.gs.stage, stages.length); pg.setGauge('grow', 0);
      if (pg.gs.stage >= stages.length) { pg.removeGauge('grow'); pg.later(1000, () => goalDone(pg, g)); }
      return true;
    },
  },
  // きせかえ: each tap shows the next look ("looks": { id: [alt, alt] }); match "answer" to clear
  dressup: {
    init(pg) { pg.gs.look = {}; pg.gs.seen = {}; },
    tap(pg, g, id) {
      const looks = g.looks[id];
      if (!looks || pg.gs.done) return false;
      const list = ['', ...looks], i = ((pg.gs.look[id] || 0) + 1) % list.length;
      pg.gs.look[id] = i;
      if (g.keep) keepLook(id, list[i]);   // the same look on the other pages
      (pg.gs.seen[id] = pg.gs.seen[id] || new Set()).add(i);
      pg.spin(id, 'y', 1, 0.8, () => pg.swap(id, i === 0 ? pg.C(id).m.tex[0] : altKey(pg, id, list[i])));
      pg.sfx(g.sound || 'pon');
      const ids = Object.keys(g.answer || g.looks);
      const ok = g.answer ? ids.filter((t) => lookMatches(pg, g, t)).length : ids.filter((t) => (pg.gs.seen[t] || new Set()).size >= g.looks[t].length).length;
      pg.progress(ok, ids.length);
      if (ok === ids.length) { progressed(pg); pg.later(800, () => goalDone(pg, g)); }
      return true;
    },
  },
  // こする・はらう: rub "targets" with a finger (taps help a little too) until they are clean
  rub: {
    texts: (g) => [said(g.doneWord || 'ぴかぴか！', g.color || '#3fa9e0'), ...wordsOf(g.word, ['ゴシゴシ', 'キュッキュッ']).map((x) => said(x, g.color || '#3fa9e0'))],
    init(pg) { pg.gs.rubbed = {}; pg.gs.cleared = {}; },
    grab(pg, g, id) { return g.targets.includes(id) && !pg.gs.done && !pg.gs.cleared[id]; },
    rub(pg, g, id, hit, px) { if (g.targets.includes(id) && !pg.gs.done) { progressed(pg); rubAdd(pg, g, id, px / param(g, 'amount', 'rub'), hit); } },
    tap(pg, g, id, hit) {
      if (!g.targets.includes(id) || pg.gs.done) return false;
      if (pg.gs.cleared[id]) return false;
      progressed(pg); rubAdd(pg, g, id, 0.15, hit);
      return true;
    },
  },
};

Object.assign(GOALS, MORE_GAMES);

// ---------- each frame: the game, then the hint ----------
export function goalUpdate(pg, g, dt) {
  const G = GOALS[g.type];
  if (G.update) G.update(pg, g, dt);
  const wait = param(g, 'hintAfter');
  if (!wait || pg.gs.done || !pg.playing || !pg.open) return;
  if (pg.gs.lastMove === undefined) pg.gs.lastMove = pg.time;
  const since = Math.max(pg.gs.lastMove, pg.gs.lastHint ?? -Infinity);
  if (pg.time - since > wait) { pg.gs.lastHint = pg.time; showHint(pg, g); }
}
