// npm run excel                  → out/<book>_表.xlsx : the book's settings as a table with drop-down lists
//                                  (book.json, every page.json and read.json — open it in Excel, LibreOffice or Google スプレッドシート)
// npm run excel -- --new         → make it again (the table you were writing in is overwritten)
// npm run excel -- --book <id>   another book
// After writing in it: npm run excel-in  (lib/table.mjs)
import fs from 'node:fs';
import path from 'node:path';
import { ROOT, rel, args, config, loadBook, mkdirp, exists } from './lib/common.mjs';
import { writeXlsx } from './lib/xlsx.mjs';
import { bookToSheets } from './lib/table.mjs';

const A = args();
const B = loadBook(A.book || config().book);
mkdirp(rel('out'));
const file = rel('out', `${B.id}_表.xlsx`);
if (exists(file) && !A.new) {
  console.error(`\n  ${path.relative(ROOT, file)} はもうあります（書きかけの表を 消さないように、作りませんでした）。
  ・表を直したら → npm run excel-in
  ・json を 直接 書きかえたので 表を 作りなおす → npm run excel -- --new\n`);
  process.exit(1);
}
const sheets = bookToSheets(B);
try { fs.writeFileSync(file, writeXlsx(sheets)); }
catch (e) { console.error(`\n  ${path.relative(ROOT, file)} に 書けません。Excel などで 開いていたら 閉じてから、もう一度 してください。\n`); process.exit(1); }
console.log(`
  ✅ ${path.relative(ROOT, file)} を作りました（「${B.book.title}」${B.pages.length}ページ）
     Excel・LibreOffice・Google スプレッドシートで 開いて、書きかえます（▼ で えらべる列があります）
     「はじめに」の シートに 書きかたが あります

  書いたら：保存して → npm run excel-in → npm run check → npm run build
`);
