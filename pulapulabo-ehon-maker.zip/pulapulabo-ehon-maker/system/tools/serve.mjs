// npm run serve                    → shows publish/<book>/ at http://localhost:8080
// npm run serve -- --book <id>     → another book;  --dir <folder> → any folder;  --port <n>
// (a PC webcam works here, because localhost counts as secure)
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { ROOT, args, config, publishDir } from './lib/common.mjs';

const A = args();
const dir = A.dir ? path.resolve(ROOT, A.dir) : publishDir(A.book || config().book);
if (!fs.existsSync(path.join(dir, 'index.html'))) {
  console.error(`\n  ${path.relative(ROOT, dir)}/ に index.html がありません。先に npm run build をしてください。\n`);
  process.exit(1);
}
const port = Number(A.port || 8080);
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.mind': 'application/octet-stream', '.png': 'image/png', '.jpg': 'image/jpeg', '.pdf': 'application/pdf', '.txt': 'text/plain; charset=utf-8', '.json': 'application/json' };
http.createServer((req, res) => {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname);   // (?v=… is ignored)
  if (p.endsWith('/')) p += 'index.html';
  const f = path.join(dir, p);
  if (!f.startsWith(dir) || !fs.existsSync(f)) { res.writeHead(404); res.end('not found'); return; }
  res.writeHead(200, { 'Content-Type': types[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
  fs.createReadStream(f).pipe(res);
}).listen(port, () => {
  console.log(`\n  ${path.relative(ROOT, dir)}/ を表示しています`);
  console.log(`  AR本体:       http://localhost:${port}/`);
  console.log(`  カメラなし:    http://localhost:${port}/preview.html`);
  console.log('  （止めるときは Ctrl + C）\n  ※ スマホのカメラで試すには https が必要です → guide/06_公開と印刷.md\n');
});
