// AR の文章: the story box at the bottom of the page, drawn again in the app (in the language being used),
// laid over the printed one. The printed paper stays Japanese.
// Same place and look as the printed box (system/tools/lib/svg.mjs): x 40–1560, y 944–1170, the page title band above it.
import * as THREE from 'three';
import { LANG, tr, plain } from './lang.js';
import { fill } from './story.js';

const X0 = 30, Y0 = 866, X1 = 1570, Y1 = 1180, K = 1.25;   // canvas area (page px) and its resolution
const RUBY = /\{([^{}|]+)\|([^{}]+)\}/g;

function rrect(g, x, y, w, h, r) {
  g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
}
// a story line as pieces: { t: text, r: reading or null }
function pieces(raw) {
  const s = fill(tr(raw));
  if (LANG.now !== 'ja') return [{ t: plain(s), r: null }];
  const out = []; let pos = 0;
  for (const m of s.matchAll(RUBY)) { if (m.index > pos) out.push({ t: s.slice(pos, m.index), r: null }); out.push({ t: m[1], r: m[2] }); pos = m.index + m[0].length; }
  if (pos < s.length) out.push({ t: s.slice(pos), r: null });
  return out;
}
// break one line into rows that fit maxW (at spaces; a very long word is broken anywhere)
function rows(g, parts, maxW) {
  const words = [];
  for (const p of parts) {
    if (p.r) { words.push({ ...p, sp: false }); continue; }
    p.t.split(/(\s+)/).forEach((w) => { if (w) words.push({ t: w, r: null, sp: /^\s+$/.test(w) }); });
  }
  const out = []; let cur = [], w = 0;
  const push = () => { while (cur.length && cur[cur.length - 1].sp) cur.pop(); if (cur.length) out.push(cur); cur = []; w = 0; };
  for (const wd of words) {
    const ww = g.measureText(wd.t).width;
    if (wd.sp && !cur.length) continue;
    if (w + ww > maxW && cur.length && !wd.sp) push();
    if (ww > maxW && !wd.r) {   // a word longer than the row: letter by letter
      for (const ch of wd.t) { const cw = g.measureText(ch).width; if (w + cw > maxW && cur.length) push(); cur.push({ t: ch, r: null, sp: false }); w += cw; }
      continue;
    }
    cur.push(wd); w += ww;
  }
  push();
  return out;
}

// draws the box; returns { canvas, boxes: [{ x, y, w, h }] for each story line (page px) }
export function drawTextBox(manifest, font) {
  const P = manifest.panel; if (!P) return null;
  const fillC = P.fill || '#fff8e8', border = P.border || '#e9c47a', ink = P.ink || '#3b2e5a', accent = P.accent || '#e8756a';
  const c = document.createElement('canvas'); c.width = Math.round((X1 - X0) * K); c.height = Math.round((Y1 - Y0) * K);
  const g = c.getContext('2d'); g.scale(K, K); g.translate(-X0, -Y0);
  g.lineJoin = 'round';
  rrect(g, 40, 944, 1520, 226, 30); g.fillStyle = fillC; g.fill(); g.lineWidth = 6; g.strokeStyle = border; g.stroke();
  g.save(); g.setLineDash([12, 10]); g.globalAlpha = 0.6; rrect(g, 56, 960, 1488, 194, 22); g.lineWidth = 3; g.stroke(); g.restore();
  const mark = P.mark || 'number';
  if (mark !== 'none') {
    g.beginPath(); g.arc(1452, 1030, 40, 0, Math.PI * 2); g.fillStyle = '#ffe9a8'; g.fill(); g.lineWidth = 5; g.strokeStyle = border; g.stroke();
    g.fillStyle = '#8a5a2a'; g.textAlign = 'center';
    if (mark === 'paw') {
      g.fillStyle = '#d9894a';
      const paw = (x, y, rx, ry) => { g.beginPath(); g.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2); g.fill(); };
      paw(1452, 1036, 13.6, 11.2); [[-13.6, -10], [-4.8, -18], [4.8, -18], [13.6, -10]].forEach(([dx, dy]) => paw(1452 + dx, 1028 + dy, 5.6, 5.6));
      g.fillStyle = '#8a5a2a';
    } else { g.font = `900 36px ${font}`; g.fillText(String(P.n), 1452, 1043); }
    g.font = `900 28px ${font}`; g.fillText(`${P.n} / ${P.count}`, 1452, 1108);
  }
  // the page title band above the box
  if (P.title) {
    const t = plain(fill(tr(P.title)));
    g.font = `900 40px ${font}`;
    const w = g.measureText(t).width + 64;
    rrect(g, 60, 878, w, 64, 32); g.fillStyle = accent; g.fill(); g.lineWidth = 6; g.strokeStyle = '#fff3d9'; g.stroke();
    g.fillStyle = '#fff8e8'; g.textAlign = 'left'; g.fillText(t, 92, 923);
  }
  // the story: the biggest letters that let every line fit (rows wrap)
  const story = manifest.story || [];
  const maxW = (mark === 'none' ? 1460 : 1310), maxFs = P.size === 'large' ? 50 : 40;
  const ruby = LANG.now === 'ja' && story.some((s) => /\{[^{}|]+\|[^{}]+\}/.test(s));
  let fs = maxFs, laid;
  for (; fs >= 16; fs -= 1) {
    g.font = `700 ${fs}px ${font}`;
    laid = story.map((s) => rows(g, pieces(s), maxW));
    const n = laid.reduce((a, r) => a + r.length, 0);
    if (n * fs * (ruby ? 1.62 : 1.25) <= 200) break;
  }
  const lh = Math.round(fs * (ruby ? 1.62 : 1.25));
  const total = laid.reduce((a, r) => a + r.length, 0);
  let y = 1060 - lh * (total - 1) / 2 + fs * (ruby ? 0.55 : 0.35);
  g.textAlign = 'left'; g.fillStyle = ink;
  const boxes = [];
  for (const rs of laid) {
    const top = y;
    let wmax = 0;
    for (const row of rs) {
      let x = 92;
      for (const wd of row) {
        g.font = `700 ${fs}px ${font}`; g.fillStyle = ink;
        const ww = g.measureText(wd.t).width;
        g.fillText(wd.t, x, y);
        if (wd.r) { g.font = `700 ${Math.round(fs * 0.46)}px ${font}`; g.textAlign = 'center'; g.fillText(wd.r, x + ww / 2, y - fs * 0.98); g.textAlign = 'left'; }
        x += ww;
      }
      wmax = Math.max(wmax, x - 92);
      y += lh;
    }
    const up = ruby ? fs * 1.5 : fs * 1.02;
    boxes.push({ x: 78, y: Math.round(top - up), w: Math.round(wmax + 28), h: Math.round((y - lh) - top + up + fs * 0.32) });
  }
  return { canvas: c, boxes };
}

// the plane that carries the drawing, placed over the printed box
export function textBoxMesh() {
  const S = 1 / 1600, PH = 0.75;
  const m = new THREE.Mesh(new THREE.PlaneGeometry((X1 - X0) * S, (Y1 - Y0) * S), new THREE.MeshBasicMaterial({ transparent: true, depthWrite: false }));
  m.position.set(((X0 + X1) / 2) * S - 0.5, PH / 2 - ((Y0 + Y1) / 2) * S, 0.00074);
  m.renderOrder = 1; m.visible = false;
  return m;
}
