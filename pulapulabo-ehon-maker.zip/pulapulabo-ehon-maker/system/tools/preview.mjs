// npm run preview                 → out/<book>_preview.html : the camera-less preview as ONE file (no ehon folder needed)
//                                   (made from publish/<book>/ — run npm run build first; npm run pack makes it too)
// npm run preview -- --book <id>
import fs from 'node:fs';
import path from 'node:path';
import { ROOT, rel, args, config, publishDir, mkdirp, exists } from './lib/common.mjs';
import { oneFilePreview } from './lib/onefile.mjs';

const A = args();
const id = A.book || config().book;
const pub = publishDir(id);
if (!exists(path.join(pub, 'preview.html'))) { console.error(`\n  publish/${id}/preview.html がありません。先に npm run build をしてください。\n`); process.exit(1); }
mkdirp(rel('out'));
const out = rel('out', `${id}_preview.html`);
fs.writeFileSync(out, oneFilePreview(pub));
console.log(`\n  ✅ ${path.relative(ROOT, out)}（${(fs.statSync(out).size / 1024 / 1024).toFixed(1)} MB）  ← カメラなしの プレビューを 1つの ファイルに しました。開くだけで 動きが 見られます\n`);
