// DOM overlay: page chip, progress, bottom buttons (read / narration / effects / reset / paper), page arrows, panels,
// もちもの (the bag), subtitles for other languages, the reward stamp.
import { tr, LANG, LANGS } from './lang.js';
import { shown } from './story.js';

const I = {
  book: '<svg viewBox="0 0 24 24" width="24" height="24"><path d="M3 5.5C5.5 4 8.5 4 12 6c3.5-2 6.5-2 9-.5V19c-2.5-1.3-5.5-1.3-9 .7-3.5-2-6.5-2-9-.7Z" fill="#fff4d6" stroke="#4a3360" stroke-width="1.8" stroke-linejoin="round"/><path d="M12 6v13.7" stroke="#4a3360" stroke-width="1.8"/></svg>',
  stop: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="6" y="6" width="12" height="12" rx="2.5" fill="#4a3360"/></svg>',
  voice: '<svg viewBox="0 0 24 24" width="24" height="24"><circle cx="9" cy="9" r="4" fill="#ffd96b" stroke="#4a3360" stroke-width="1.8"/><path d="M2.5 20c.6-4 3.3-6 6.5-6s5.9 2 6.5 6" fill="#ffd96b" stroke="#4a3360" stroke-width="1.8"/><path d="M17 7.5a4 4 0 0 1 0 5M19.5 5a7.5 7.5 0 0 1 0 10" fill="none" stroke="#4a3360" stroke-width="1.8" stroke-linecap="round"/></svg>',
  sfx: '<svg viewBox="0 0 24 24" width="24" height="24"><path d="M9 17V5l11-2v12" fill="none" stroke="#4a3360" stroke-width="1.8" stroke-linejoin="round"/><circle cx="6.5" cy="17" r="3" fill="#ff8fb1" stroke="#4a3360" stroke-width="1.8"/><circle cx="17.5" cy="15" r="3" fill="#7cc6f0" stroke="#4a3360" stroke-width="1.8"/></svg>',
  slash: '<path d="M3 3l18 18" stroke="#c4504f" stroke-width="2.6" stroke-linecap="round"/>',
  reset: '<svg viewBox="0 0 24 24" width="22" height="22"><path d="M5 12a7 7 0 1 0 2.2-5.1" fill="none" stroke="#4a3360" stroke-width="2.2" stroke-linecap="round"/><path d="M6.5 3.5v4h4" fill="none" stroke="#4a3360" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  text: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="3" y="4.5" width="18" height="15" rx="3" fill="#fff4d6" stroke="#4a3360" stroke-width="1.8"/><path d="M7 9.5h10M7 13h10M7 16.5h6" stroke="#4a3360" stroke-width="1.8" stroke-linecap="round"/></svg>',
  layers: '<svg viewBox="0 0 24 24" width="22" height="22"><path d="M12 4 3 8.5l9 4.5 9-4.5Z" fill="#ffd96b" stroke="#4a3360" stroke-width="1.8" stroke-linejoin="round"/><path d="m3 12.5 9 4.5 9-4.5M3 16.5l9 4.5 9-4.5" fill="none" stroke="#4a3360" stroke-width="1.8" stroke-linejoin="round" stroke-dasharray="2.5 2"/></svg>',
  left: '<svg viewBox="0 0 24 24" width="26" height="26"><path d="M15 5l-7 7 7 7" fill="none" stroke="#4a3360" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  restart: '<svg viewBox="0 0 24 24" width="18" height="18"><rect x="4" y="5" width="3" height="14" rx="1" fill="#4a3360"/><path d="M19 5v14L8.5 12Z" fill="#4a3360" stroke="#4a3360" stroke-width="1.5" stroke-linejoin="round"/></svg>',
  home: '<svg viewBox="0 0 24 24" width="18" height="18"><path d="M3.5 11.5 12 4l8.5 7.5" fill="none" stroke="#4a3360" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 10.5V20h12v-9.5" fill="#ffd96b" stroke="#4a3360" stroke-width="2" stroke-linejoin="round"/><rect x="10" y="14" width="4" height="6" fill="#4a3360"/></svg>',
  crayon: '<svg viewBox="0 0 24 24" width="18" height="18"><path d="M4 20l2.2-6.6L16.6 3a2 2 0 0 1 2.8 0l1.6 1.6a2 2 0 0 1 0 2.8L10.6 17.8Z" fill="#ff8fb1" stroke="#4a3360" stroke-width="1.8" stroke-linejoin="round"/><path d="M6.2 13.4l4.4 4.4M4 20l2-.6" stroke="#4a3360" stroke-width="1.8" stroke-linecap="round"/></svg>',
  globe: '<svg viewBox="0 0 24 24" width="18" height="18"><circle cx="12" cy="12" r="8.5" fill="#bfe6ff" stroke="#4a3360" stroke-width="1.8"/><path d="M3.5 12h17M12 3.5c-2.6 2.4-3.8 5.2-3.8 8.5s1.2 6.1 3.8 8.5M12 3.5c2.6 2.4 3.8 5.2 3.8 8.5s-1.2 6.1-3.8 8.5" fill="none" stroke="#4a3360" stroke-width="1.6"/></svg>',
  right: '<svg viewBox="0 0 24 24" width="26" height="26"><path d="M9 5l7 7-7 7" fill="none" stroke="#4a3360" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>',
};
const withSlash = (svg, off) => (off ? svg.replace('</svg>', `${I.slash}</svg>`) : svg);

// an icon of the screen buttons in another colour (for the coloured buttons of the panels)
export const icon = (name, color = '#ffffff') => (I[name] || '').split('#4a3360').join(color);

export class UI {
  constructor(h) {
    this.h = h;
    this.hud = document.getElementById('hud');
    this.hud.innerHTML = `
      <div class="top">
        <div class="tl">
          <div class="chip page"><b class="pn">1/4</b><span class="pname"></span></div>
          <button class="mini restart" type="button" aria-label="さいしょから よむ">${I.restart}<span>さいしょ</span></button>
          <button class="mini home" type="button" aria-label="はじめに もどる">${I.home}<span>はじめ</span></button>
          <button class="mini langbtn" type="button" aria-label="ことば" aria-expanded="false" hidden>${I.globe}<span>ことば</span></button>
        </div>
        <div class="langpop" hidden></div>
        <div class="tr">
          <div class="chip prog"><span class="lbl"></span><span class="slots"></span></div>
          <div class="bag" aria-label="もちもの"></div>
        </div>
      </div>
      <div class="hint" role="status"><span class="ht"></span><b class="done">できた！</b></div>
      <div class="coverhelp"><span>♪ キラリンが きこえないときは</span><button type="button" class="reload">よみこみなおす</button></div>
      <div class="toast" role="status"></div>
      <div class="caption" aria-live="polite"></div>
      <div class="stamppop" aria-hidden="true"></div>
      <button class="playbtn" type="button">▶ あそぶ</button>
      <button class="endbtn" type="button">📖 おしまい</button>
      <button class="nav prev" type="button" aria-label="まえの ページ">${I.left}</button>
      <button class="nav next" type="button" aria-label="つぎの ページ">${I.right}</button>
      <div class="bottom">
        <button class="tb read" type="button"><i>${I.book}</i><span>よむ</span></button>
        <button class="tb narr" type="button" aria-pressed="true"><i>${I.voice}</i><span>セリフ</span></button>
        <button class="tb sfx" type="button" aria-pressed="true"><i>${I.sfx}</i><span>こうかおん</span></button>
        <button class="tb reset" type="button"><i>${I.reset}</i><span>もどす</span></button>
        <button class="tb text" type="button" aria-pressed="false"><i>${I.text}</i><span>もじ</span></button>
        <button class="tb paper" type="button" aria-pressed="false"><i>${I.layers}</i><span>ARだけ</span></button>
      </div>`;
    const q = (s) => this.hud.querySelector(s);
    this.el = { read: q('.read'), narr: q('.narr'), sfx: q('.sfx'), reset: q('.reset'), paper: q('.paper'), prev: q('.prev'), next: q('.next'), toast: q('.toast'), pn: q('.pn'), pname: q('.pname'), lbl: q('.prog .lbl'), slots: q('.prog .slots') };
    this.el.read.addEventListener('click', () => h.onRead());
    this.el.narr.addEventListener('click', () => h.onNarration());
    this.el.sfx.addEventListener('click', () => h.onSfx());
    this.el.reset.addEventListener('click', () => h.onReset());
    this.el.text = q('.tb.text'); this.el.text.addEventListener('click', () => h.onText());
    this.el.paper.addEventListener('click', () => h.onPaper());
    this.el.prev.addEventListener('click', () => h.onPage(-1));
    this.el.next.addEventListener('click', () => h.onPage(1));
    this.el.hint = q('.hint'); this.el.ht = q('.hint .ht'); this.el.play = q('.playbtn');
    q('.mini.restart').addEventListener('click', () => h.onRestart());
    q('.mini.home').addEventListener('click', () => h.onHome());
    // ことば: the words on the screen (もじ) and the voice (こえ), each on its own, from any page
    this.el.langbtn = q('.mini.langbtn'); this.el.langpop = q('.langpop');
    this.el.langbtn.addEventListener('click', (e) => { e.stopPropagation(); this.openLangs(this.el.langpop.hidden); });
    this.el.langpop.addEventListener('click', (e) => {
      e.stopPropagation();
      const b = e.target.closest('button'); if (!b) return;
      try { if (b.dataset.lang) h.onWords(b.dataset.lang); else if (b.dataset.voice) h.onVoice(b.dataset.voice); } finally { this.drawLangs(); }
    });
    document.addEventListener('pointerdown', (e) => { if (!this.el.langpop.hidden && !e.target.closest('.langpop, .mini.langbtn')) this.openLangs(false); });
    this.el.play.addEventListener('click', () => h.onPlay());
    // on the printed cover (camera), with こうかおん on: a reader who does not hear the キラリン can load the page again
    q('.coverhelp .reload').addEventListener('click', () => location.reload());
    this.el.end = q('.endbtn'); this.el.end.addEventListener('click', () => h.onEnding());
    this.el.bag = q('.bag'); this.el.caption = q('.caption'); this.el.stamp = q('.stamppop');
    this.done = {};
    this.prog = {};
    this.relabel();
  }
  // ことば: the button is there when the book has two languages or more
  setLangs(list) { this._langs = (list || []).filter((l) => LANGS[l]); this.el.langbtn.hidden = this._langs.length < 2; if (this._langs.length < 2) this.openLangs(false); }
  openLangs(on) { this.el.langpop.hidden = !on; this.el.langbtn.setAttribute('aria-expanded', String(on)); this.el.langbtn.classList.toggle('active', on); if (on) this.drawLangs(); }
  drawLangs() {
    const row = (label, key, now) => `<div class="lrow"><small>${tr(label)}</small>${this._langs.map((l) => `<button type="button" data-${key}="${l}" class="${l === now ? 'on' : ''}" lang="${l}" aria-pressed="${l === now}">${LANGS[l].name}</button>`).join('')}</div>`;
    this.el.langpop.innerHTML = row('もじ', 'lang', LANG.now) + row('こえ', 'voice', LANG.voice);
  }
  // the buttons' words in the language being used
  relabel() {
    const q = (s) => this.hud.querySelector(s);
    const set = (sel, ja, attr) => { const el = q(sel); if (!el) return; if (attr) el.setAttribute(attr, tr(ja)); else el.textContent = tr(ja); };
    set('.mini.restart span', 'さいしょ'); set('.mini.restart', 'さいしょから よむ', 'aria-label');
    set('.mini.home span', 'はじめ'); set('.mini.home', 'はじめに もどる', 'aria-label');
    set('.mini.langbtn span', 'ことば'); set('.mini.langbtn', 'ことば', 'aria-label');
    if (this.el.langpop && !this.el.langpop.hidden) this.drawLangs();
    set('.nav.prev', 'まえの ページ', 'aria-label'); set('.nav.next', 'つぎの ページ', 'aria-label');
    set('.hint .done', 'できた！'); set('.playbtn', '▶ あそぶ'); this.el.end.textContent = `📖 ${tr('おしまい')}`;
    set('.coverhelp span', '♪ キラリンが きこえないときは'); set('.coverhelp .reload', 'よみこみなおす');
    set('.tb.narr span', 'セリフ'); set('.tb.sfx span', 'こうかおん'); set('.tb.reset span', 'もどす'); set('.tb.text span', 'もじ');
    set('.bag', 'もちもの', 'aria-label');
    if (this._paperJa) this.setPaperLabel(this._paperJa);
    this.setReading(!!this._reading);
    if (this.page) { this.setPage(this.page, this._pname, this.progDef); this.setHint(this._hintJa, this._story); }
    if (this._cover) this.el.pname.textContent = tr('ひょうし');
  }
  show(on = true) { this.hud.classList.toggle('on', on); }
  setNav(on) { this.hud.classList.toggle('withnav', on); }
  setPaperLabel(t) { this._paperJa = t; this.el.paper.querySelector('span').textContent = tr(t); }
  setPaperMode(on) { this.el.paper.classList.toggle('active', on); this.el.paper.setAttribute('aria-pressed', String(on)); }
  setNarration(on) { this.el.narr.classList.toggle('off', !on); this.el.narr.setAttribute('aria-pressed', String(on)); this.el.narr.querySelector('i').innerHTML = withSlash(I.voice, !on); }
  // the おしまい button: after the last page is cleared, it opens the book's ending
  setEnd(on) { this.el.end.classList.toggle('on', on); }
  setText(on) { this.el.text.classList.toggle('active', on); this.el.text.setAttribute('aria-pressed', String(on)); }
  setSfx(on) { this.hud.classList.toggle('nosfx', !on); this.el.sfx.classList.toggle('off', !on); this.el.sfx.setAttribute('aria-pressed', String(on)); this.el.sfx.querySelector('i').innerHTML = withSlash(I.sfx, !on); }
  setReading(on) { this._reading = on; this.el.read.classList.toggle('active', on); this.el.read.querySelector('i').innerHTML = on ? I.stop : I.book; this.el.read.querySelector('span').textContent = tr(on ? 'とめる' : 'よむ'); if (!on) this.caption(''); }
  // the printed cover is shown (camera): the chip says so; the page's hint, progress and buttons wait
  setCover(on) {
    if (on === !!this._cover) return;
    this._cover = on; this.hud.classList.toggle('oncover', on);
    if (on) { this._chip = [this.el.pn.textContent, this.el.pname.textContent]; this.el.pname.textContent = tr('ひょうし'); }
    else if (this.page) this.setPage(this.page, this._pname, this.progDef);
    else [this.el.pn.textContent, this.el.pname.textContent] = this._chip;
  }
  setPage(n, name, progressDef) {
    this.page = n; this._pname = name;
    this.el.pn.textContent = `${n}/${this.count || n}`; this.el.pname.textContent = shown(name);
    this.el.prev.disabled = n <= 1; this.el.next.disabled = n >= (this.count || n);
    this._renderDone && this._renderDone();
    this.progDef = progressDef;
    this._renderProg();
  }
  setProgress(n, done, total) { this.prog[n] = { done, total }; if (n === this.page) this._renderProg(); }
  _renderProg() {
    const d = this.progDef;
    this.el.slots.parentElement.style.display = d ? '' : 'none';
    if (!d) return;
    const p = this.prog[this.page] || { done: 0, total: d.total || (d.colors ? d.colors.length : 3) };
    this.el.lbl.textContent = shown(d.label);
    let s = '';
    for (let i = 0; i < p.total; i++) {
      const got = i < p.done;
      if (!d.colors) s += `<i class="dot plain${got ? ' got' : ''}"></i>`;
      else s += `<i class="dot${got ? ' got' : ''}" style="--c:${d.colors[i % d.colors.length]}"></i>`;
    }
    const was = this.el.slots.querySelectorAll('.got').length;
    this.el.slots.innerHTML = s;
    if (p.done > was && p.done > 0) { const el = this.el.slots.children[p.done - 1]; el && el.classList.add('pop'); }
    this.el.slots.parentElement.classList.toggle('complete', p.done >= p.total);
  }
  // persistent hint for the page (story phase: what to do first; play phase: the page's goal)
  setHint(text, story = false) {
    this._hintJa = text;
    this.el.ht.textContent = text ? shown(text) : '';
    this.el.hint.classList.toggle('on', !!text);
    this.el.hint.classList.toggle('story', story);
    this._story = story;
    this._renderDone();
  }
  setStory(on) { this.el.play.classList.toggle('on', on); this.hud.classList.toggle('storymode', on); }
  setDone(n, done) { this.done[n] = done; this._renderDone(); }
  _renderDone() { this.el.hint.classList.toggle('isdone', !this._story && !!this.done[this.page]); }
  toast(text, ms = 3000) {
    this.el.toast.textContent = shown(text); this.el.toast.classList.add('on');
    clearTimeout(this._tt); this._tt = setTimeout(() => this.el.toast.classList.remove('on'), ms);
  }

  // subtitles while reading in another language ('' hides them)
  caption(text) { this.el.caption.textContent = text || ''; this.el.caption.classList.toggle('on', !!text); }
  // もちもの: the things in the bag (icons: { id: picture }), the newest one pops
  setBag(items, icons, names, fresh) {
    this.el.bag.innerHTML = items.map((id) => `<i class="item${id === fresh ? ' pop' : ''}" title="${esc(names(id))}">${icons[id] ? `<img src="${icons[id]}" alt="${esc(names(id))}">` : `<b>${esc(names(id).slice(0, 2))}</b>`}</i>`).join('');
    this.el.bag.classList.toggle('on', items.length > 0);
  }
  // ごほうびスタンプ: a stamp pops in the middle of the screen, then fades
  stampPop(html) {
    const el = this.el.stamp;
    el.innerHTML = `${html}<b>${esc(tr('スタンプ ゲット！'))}</b>`;
    el.classList.remove('on'); void el.offsetWidth; el.classList.add('on');
    clearTimeout(this._st); this._st = setTimeout(() => el.classList.remove('on'), 2600);
  }
}
export const esc = (t) => String(t ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

export function panel(id, html) {
  let el = document.getElementById(id);
  if (!el) { el = document.createElement('div'); el.id = id; el.className = 'panel'; document.body.appendChild(el); }
  el.innerHTML = `<div class="card">${html}</div>`;
  el.classList.add('on');
  return el;
}
export function hidePanel(id) { const el = document.getElementById(id); if (el) el.classList.remove('on'); }
export function showLicenses() {
  const text = window.EHON_LICENSES || '';   // ehon/licenses.js
  const el = panel('licenses', `<h2>${tr('ライセンス表示')}</h2><p class="lic">${tr('この ページに ふくまれる ソフトウェアと フォントの ライセンスです。')}</p><pre></pre><button class="big close" type="button">${tr('とじる')}</button>`);
  el.querySelector('pre').textContent = text;
  el.querySelector('.close').addEventListener('click', () => hidePanel('licenses'));
}
