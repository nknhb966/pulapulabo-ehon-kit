// ぬりえ（タブレットで いろを ぬる）
//   The pictures (SVG, from ehon/nurie.js) are shown as line drawings; a tap on a part fills it with the chosen colour
//   (it never goes over the lines). The colours are kept on this device (localStorage), page by page, and the
//   preview / AR pages use them: the pictures, their other looks (まばたき・しゃべる・ばんざい …) and, when chosen,
//   the background. 「みほんの いろ」 goes back to the book's own colours; 「はじめから」 clears the colouring.
//   A part that is not coloured yet is white, like a colouring book. Pictures drawn as PNG stay as they are.
import { tr } from './lang.js';
import { esc } from './ui.js';

const T = (ja) => esc(tr(ja));
const WHITE = '#ffffff';
const HELP = '#c9c0d3';          // a light line around a part that has no line of its own (so it can be seen while white)
const THIN = '#d9d2e0';          // a thin coloured line (しま・ひげ) before it is coloured
const PALETTE = [
  ['#e8452c', 'あか'], ['#ff8fb1', 'ピンク'], ['#f39a2b', 'だいだい'], ['#ffd93b', 'きいろ'], ['#a6d84a', 'きみどり'],
  ['#3fa34d', 'みどり'], ['#6fc8f0', 'みずいろ'], ['#2f6fd6', 'あお'], ['#8b5cc7', 'むらさき'], ['#9a6236', 'ちゃいろ'],
  ['#ffd7b0', 'はだいろ'], ['#a7a7a7', 'はいいろ'], ['#3a3340', 'くろ'], ['#ffffff', 'しろ'],
];
const SHAPES = new Set(['path', 'rect', 'circle', 'ellipse', 'polygon', 'polyline']);
const SKIP = new Set(['defs', 'clipPath', 'mask', 'pattern', 'marker', 'symbol', 'linearGradient', 'radialGradient', 'filter', 'style', 'title', 'desc', 'metadata']);
const GEO = ['d', 'points', 'x', 'y', 'width', 'height', 'cx', 'cy', 'r', 'rx', 'ry', 'transform'];
const NAMED = { white: '#ffffff', black: '#000000', red: '#ff0000', none: 'none', transparent: 'none' };

// ---------- colours ----------
function norm(c) {
  if (c == null) return null;
  c = String(c).trim().toLowerCase();
  if (NAMED[c]) return NAMED[c];
  if (/^#[0-9a-f]{3}$/.test(c)) return `#${c[1]}${c[1]}${c[2]}${c[2]}${c[3]}${c[3]}`;
  if (/^#[0-9a-f]{6}/.test(c)) return c.slice(0, 7);
  if (c.startsWith('url')) return 'url';
  return c;
}
function luma(hex) {
  if (!/^#[0-9a-f]{6}$/.test(hex)) return 1;
  const v = [1, 3, 5].map((k) => parseInt(hex.slice(k, k + 2), 16) / 255);
  return 0.299 * v[0] + 0.587 * v[1] + 0.114 * v[2];
}
// a style="…" declaration or the attribute itself
function own(el, name) {
  const st = el.getAttribute('style');
  if (st) { const m = new RegExp(`(?:^|;)\\s*${name}\\s*:\\s*([^;]+)`).exec(st); if (m) return m[1].trim(); }
  const a = el.getAttribute(name);
  return a == null ? null : a;
}
function inherit(el, name) {
  for (let e = el; e && e.nodeType === 1; e = e.parentNode) { const v = own(e, name); if (v != null && v !== 'inherit') return v; }
  return null;
}
function opacity(el) {
  let o = 1;
  for (let e = el; e && e.nodeType === 1; e = e.parentNode) { const v = own(e, 'opacity'); if (v != null) o *= parseFloat(v) || 0; }
  const fo = inherit(el, 'fill-opacity');
  return o * (fo == null ? 1 : parseFloat(fo));
}
function setOwn(el, name, value) {
  const st = el.getAttribute('style');
  if (st) el.setAttribute('style', st.replace(new RegExp(`(?:^|;)\\s*${name}\\s*:[^;]*`, 'g'), ''));
  if (value == null) el.removeAttribute(name); else el.setAttribute(name, value);
}
// a short name for a part: its shape and where it is (the same part in the other looks gets the same name)
function hash(s) {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return (h >>> 0).toString(36);
}
function sigOf(el) {
  let s = el.nodeName;
  for (const a of GEO) { const v = el.getAttribute(a); if (v != null) s += `|${a}=${v}`; }
  for (let e = el.parentNode; e && e.nodeType === 1; e = e.parentNode) { const t = e.getAttribute('transform'); if (t) s += `<${t}`; }
  return hash(s);
}
function* shapes(node) {
  for (const el of node.children || []) {
    if (SKIP.has(el.nodeName)) continue;
    if (SHAPES.has(el.nodeName)) yield el;
    yield* shapes(el);
  }
}

// ---------- one picture as a ぬりえ ----------
//   parts: the parts that can be coloured { el, key, orig, lined }; the shading (half see-through) is put away
function prepare(text, prefix = '') {
  if (prefix) {
    text = text.replace(/\bid="([^"]+)"/g, `id="${prefix}$1"`).replace(/url\(#([^)]+)\)/g, `url(#${prefix}$1)`)
      .replace(/(xlink:)?href="#([^"]+)"/g, (m, x, id) => `${x || ''}href="#${prefix}${id}"`);
  }
  const doc = new DOMParser().parseFromString(text, 'image/svg+xml');
  const svg = doc.documentElement;
  if (!svg || svg.nodeName !== 'svg' || doc.getElementsByTagName('parsererror').length) return null;
  // the line colour: the colour most used for lines
  const count = {};
  for (const el of shapes(svg)) { const s = norm(inherit(el, 'stroke')); if (s && s !== 'none') count[s] = (count[s] || 0) + 1; }
  const ink = Object.entries(count).sort((a, b) => b[1] - a[1])[0];
  const inkColor = ink ? ink[0] : '#000000';
  const parts = [], seen = {};
  for (const el of shapes(svg)) {
    const given = inherit(el, 'fill'), stroke = norm(inherit(el, 'stroke'));
    // (no fill written but a line: a line — しま・ひげ are drawn so; the default black fill shows nothing there)
    const fill = given == null && stroke && stroke !== 'none' ? 'none' : norm(given ?? '#000000');
    if (fill === 'none') {
      // a part drawn as a coloured line (しっぽ・しま・ひも): its line is coloured
      const st = norm(inherit(el, 'stroke'));
      if (!st || st === 'none' || st === 'url' || st === inkColor || luma(st) < 0.12) continue;
      if (opacity(el) < 0.95) { el.setAttribute('display', 'none'); continue; }
      const sig = sigOf(el), n = (seen[sig] = (seen[sig] ?? -1) + 1);
      parts.push({ el, key: n ? `${sig}.${n}` : sig, orig: `line:${st}`, line: parseFloat(inherit(el, 'stroke-width') ?? '1') >= 8 ? 'thick' : 'thin' });
      continue;
    }
    if (opacity(el) < 0.95) { el.setAttribute('display', 'none'); continue; }   // shading and light
    if (/\b(eye|mouth|shine|ink|line)\b/.test(el.getAttribute('class') || '')) continue;   // eyes, mouth: as drawn
    if (fill !== 'url' && (fill === inkColor || luma(fill) < 0.12)) continue;            // the lines' colour
    const sig = sigOf(el), n = (seen[sig] = (seen[sig] ?? -1) + 1);
    const st = norm(inherit(el, 'stroke')), sw = parseFloat(inherit(el, 'stroke-width') ?? '1');
    parts.push({ el, key: n ? `${sig}.${n}` : sig, orig: fill, lined: !!st && st !== 'none' && sw > 0 });
  }
  return { doc, svg, parts };
}
function paint(el, color, lined, line) {
  if (line) { setOwn(el, 'stroke', color || (line === 'thick' ? WHITE : THIN)); setOwn(el, 'stroke-opacity', null); return; }
  setOwn(el, 'fill', color || WHITE);
  setOwn(el, 'fill-opacity', null);
  if (!lined) {
    if (color) { setOwn(el, 'stroke', null); setOwn(el, 'stroke-width', null); }
    else { setOwn(el, 'stroke', HELP); setOwn(el, 'stroke-width', '2'); }
  }
}
// the colours of a picture's other look: the same part → the same colour; a part drawn differently → the colour
// given to the most parts that had its colour
function fallbackOf(prep, colors) {
  const by = {};
  for (const p of prep.parts) { const c = colors[p.key]; if (!c) continue; (by[p.orig] ||= {})[c] = ((by[p.orig] || {})[c] || 0) + 1; }
  const out = {};
  for (const [o, cs] of Object.entries(by)) out[o] = Object.entries(cs).sort((a, b) => b[1] - a[1])[0][0];
  return out;
}
function colorAll(prep, colors, fallback) {
  for (const p of prep.parts) paint(p.el, colors[p.key] || (fallback && fallback[p.orig]) || null, p.lined, p.line);
}

// ---------- pictures for the AR / preview page ----------
const canvas = (w, h) => { const c = document.createElement('canvas'); c.width = Math.max(1, w); c.height = Math.max(1, h); return c; };
async function svgImage(prep) {
  const text = new XMLSerializer().serializeToString(prep.svg);
  const url = URL.createObjectURL(new Blob([text], { type: 'image/svg+xml' }));
  try { const im = new Image(); im.src = url; await im.decode(); return im; } finally { setTimeout(() => URL.revokeObjectURL(url), 1000); }
}
const pngImage = async (src) => { const im = new Image(); im.src = src; await im.decode(); return im; };
// the paper edge around a picture (like the printed pieces): the picture drawn around itself, in the edge colour
function paper(c, o) {
  if (!o) return c;
  const out = canvas(c.width, c.height), g = out.getContext('2d');
  for (const r of [o.width, o.width * 0.5]) for (let i = 0; i < 16; i++) { const a = (i / 16) * Math.PI * 2; g.drawImage(c, Math.cos(a) * r, Math.sin(a) * r); }
  g.globalCompositeOperation = 'source-in'; g.fillStyle = o.color; g.fillRect(0, 0, out.width, out.height);
  g.globalCompositeOperation = 'source-over'; g.drawImage(c, 0, 0);
  return out;
}

const KEY = (id) => `ehon-nurie:${id}`;
const tick = () => new Promise((r) => setTimeout(r, 0));
// as on the paper: a piece standing behind the one it is on (戸口の むこうの 外の けしき) comes under it
const underFirst = (list) => { const out = []; for (const m of list) { const k = m.behind && m.parent ? out.findIndex((x) => x.id === m.parent) : -1; if (k >= 0) out.splice(k, 0, m); else out.push(m); } return out; };

export class Nurie {
  constructor(ctx, data, assets) {
    this.ctx = ctx; this.data = data; this.A = assets;
    this.preps = {}; this.runs = {};
    this.state = { bg: data.background === true, use: true, pages: {} };   // 「はいけいも ぬる」は さいしょ オフ（book.json の "nurie": { "background": true } で オン）
    try {
      const s = JSON.parse(localStorage.getItem(KEY(data.id)) || 'null');
      if (s && s.pages) { if (!s.bgSet) delete s.bg; Object.assign(this.state, s); }   // 「はいけいも ぬる」は じぶんで きりかえた ときだけ おぼえる
    } catch (e) { /* no storage */ }
    this.color = PALETTE[0][0]; this.undo = []; this.dirty = new Set();
  }
  get available() { return this.data.pages.some((p) => p.bg || Object.keys(p.tex || {}).length); }
  save() { try { localStorage.setItem(KEY(this.data.id), JSON.stringify(this.state)); } catch (e) { /* storage blocked: kept until the page closes */ } }
  pageId(i) { return this.A.pages[i].id; }
  colored(i) {
    const st = this.state.pages[this.pageId(i)]; if (!st) return false;
    return Object.entries(st).some(([np, cs]) => (np !== '_bg' || this.state.bg) && Object.keys(cs).length);
  }
  prep(i, key, text) { const k = `${i}/${key}`; if (!this.preps[k]) this.preps[k] = prepare(text); return this.preps[k]; }

  // the AR / preview pictures of page i: the colours, or the book's own (みほんの いろ / nothing coloured on the page)
  async apply(i) {
    const pg = this.ctx.pages[this.A.pages[i].n]; if (!pg) return;
    const run = (this.runs[i] = (this.runs[i] || 0) + 1);
    const N = this.data.pages[i], man = this.A.pages[i].manifest, st = this.state.pages[this.pageId(i)] || {};
    const on = this.state.use && this.colored(i);
    const ol = this.data.outline;
    for (const m of Object.values(man.pieces)) {
      for (const key of m.tex) {
        const t = pg.tex[key]; if (!t) continue;
        if (!t.userData.orig) t.userData.orig = t.image;
        if (!on || !N.tex[key]) { if (t.image !== t.userData.orig) { t.image = t.userData.orig; t.needsUpdate = true; } continue; }
        const prep = this.prep(i, key, N.tex[key]); if (!prep) continue;
        const colors = st[m.id] || {};
        let fb = null;
        if (key !== m.id && N.tex[m.id]) { const base = this.prep(i, m.id, N.tex[m.id]); if (base) fb = fallbackOf(base, colors); }
        colorAll(prep, colors, fb);
        let c;
        try {
          const im = await svgImage(prep);
          c = canvas(m.w, m.h); c.getContext('2d').drawImage(im, -m.x, -m.y, 1600, 1200);
          c = paper(c, ol);
        } catch (e) { continue; }
        if (run !== this.runs[i]) return;          // coloured again meanwhile: that run finishes the job
        t.image = c; t.needsUpdate = true;
        await tick();
      }
    }
    // the paper (background + the story box)
    if (on && this.state.bg && N.bg) {
      const prep = this.prep(i, '_bg', N.bg);
      if (prep) {
        colorAll(prep, st._bg || {}, null);
        try {
          const c = canvas(1600, 1200), g = c.getContext('2d');
          g.fillStyle = '#ffffff'; g.fillRect(0, 0, 1600, 1200);
          g.drawImage(await svgImage(prep), 0, 0, 1600, 1200);
          if (N.over) g.drawImage(await pngImage(N.over.src), N.over.x, N.over.y, N.over.w, N.over.h);
          if (run === this.runs[i]) pg.setPlate(c);
        } catch (e) { /* keep the paper */ }
      }
    } else pg.setPlate(null);
  }
  async applyAll(list) {
    for (const i of list || this.A.pages.map((p, k) => k)) await this.apply(i);
  }

  // ---------- the ぬりえ screen ----------
  open(i = 0, onClose = null) {
    this.i = Math.max(0, Math.min(this.A.pages.length - 1, i)); this.focus = null; this.onClose = onClose;
    this.useBefore = this.state.use; this.bgBefore = this.state.bg;
    let el = document.getElementById('nurie');
    if (!el) { el = document.createElement('div'); el.id = 'nurie'; document.body.appendChild(el); }
    el.innerHTML = `
      <div class="nu-top">
        <button class="nu-btn nu-close" type="button">✓ ${T('おわる')}</button>
        <div class="nu-pages"><button class="nu-btn nu-prev" type="button" aria-label="${T('まえの ページ')}">◀</button><b class="nu-pn"></b><button class="nu-btn nu-next" type="button" aria-label="${T('つぎの ページ')}">▶</button></div>
        <button class="nu-btn nu-undo" type="button">↶ ${T('ひとつ もどす')}</button>
        <button class="nu-btn nu-clear" type="button">${T('はじめから')}</button>
      </div>
      <div class="nu-opts">
        <button class="nu-tog nu-bg" type="button"></button>
        <button class="nu-tog nu-use" type="button"></button>
      </div>
      <div class="nu-stage"><div class="nu-zoom"></div><div class="nu-fit"><button class="nu-btn nu-zin" type="button" aria-label="${T('おおきく')}">＋</button><button class="nu-btn nu-zout" type="button" aria-label="${T('ちいさく')}">－</button></div></div>
      <div class="nu-tray"></div>
      <div class="nu-palette">${PALETTE.map(([c, n]) => `<button class="nu-sw" type="button" data-c="${c}" style="--c:${c}" aria-label="${T(n)}"></button>`).join('')}<button class="nu-sw nu-erase" type="button" data-c="" aria-label="${T('けしゴム')}">${T('けす')}</button></div>
      <div class="nu-ask" hidden></div>`;
    el.hidden = false; this.el = el;
    document.body.classList.add('nurie-open');
    const q = (s) => el.querySelector(s);
    q('.nu-close').addEventListener('click', () => this.close());
    q('.nu-prev').addEventListener('click', () => this.go(this.i - 1));
    q('.nu-next').addEventListener('click', () => this.go(this.i + 1));
    q('.nu-undo').addEventListener('click', () => this.back());
    q('.nu-clear').addEventListener('click', () => this.askClear());
    q('.nu-bg').addEventListener('click', () => { this.state.bg = !this.state.bg; this.state.bgSet = true; this.save(); this.dirty.add(this.i); this.draw(); });
    q('.nu-use').addEventListener('click', () => { this.state.use = !this.state.use; this.save(); this.opts(); });
    q('.nu-zin').addEventListener('click', () => this.zoomBy(1.4));
    q('.nu-zout').addEventListener('click', () => this.zoomBy(1 / 1.4));
    el.querySelectorAll('.nu-sw').forEach((b) => b.addEventListener('click', () => { this.color = b.dataset.c; this.swatches(); }));
    this.input(q('.nu-stage'));
    this.swatches(); this.draw();
  }
  swatches() { this.el.querySelectorAll('.nu-sw').forEach((b) => b.classList.toggle('on', b.dataset.c === this.color)); }
  opts() {
    const has = !!this.data.pages[this.i].bg, b = this.el.querySelector('.nu-bg');
    b.hidden = !has;
    b.innerHTML = `${T('はいけいも ぬる')}：<b>${T(this.state.bg ? 'オン' : 'オフ')}</b>`; b.classList.toggle('on', this.state.bg);
    const u = this.el.querySelector('.nu-use');
    u.innerHTML = `${T('えほんの いろ')}：<b>${T(this.state.use ? 'じぶんの いろ' : 'みほんの いろ')}</b>`; u.classList.toggle('on', this.state.use);
  }
  go(i) {
    if (i < 0 || i >= this.A.pages.length) return;
    this.i = i; this.focus = null; this.draw();
  }
  // the page (or one picture that comes out later), as a line drawing with the colours so far
  draw() {
    const i = this.i, P = this.A.pages[i], N = this.data.pages[i], man = P.manifest;
    const st = (this.state.pages[P.id] ||= {});
    this.el.querySelector('.nu-pn').textContent = `${i + 1}/${this.A.pages.length}`;
    this.opts();
    const parts = [];
    const add = (np, text, attrs = '') => {
      const prep = prepare(text, `n${i}_${np}_`); if (!prep) return false;
      for (const p of prep.parts) { p.el.setAttribute('data-nk', p.key); p.el.setAttribute('data-np', np); if (p.line) p.el.setAttribute('data-nline', p.line); else if (!p.lined) p.el.setAttribute('data-nl', '0'); }
      colorAll(prep, st[np] || {}, null);
      const svg = prep.svg; svg.setAttribute('x', '0'); svg.setAttribute('y', '0'); svg.setAttribute('width', '1600'); svg.setAttribute('height', '1200'); svg.setAttribute('overflow', 'visible');
      parts.push(`<g data-np="${esc(np)}" ${attrs}>${new XMLSerializer().serializeToString(svg)}</g>`);
      return true;
    };
    const img = (href, x, y, w, h) => parts.push(`<image href="${href}" x="${x}" y="${y}" width="${w}" height="${h}" preserveAspectRatio="none"/>`);
    let vb = '0 0 1600 1200';
    if (this.focus) {
      const m = man.pieces[this.focus];
      add(m.id, N.tex[m.id]);
      const pad = 30; vb = `${m.x - pad} ${m.y - pad} ${m.w + pad * 2} ${m.h + pad * 2}`;
    } else {
      const bgOn = this.state.bg && N.bg;
      if (!bgOn || !add('_bg', N.bg)) img(P.plate, 0, 0, 1600, 1200);
      for (const m of underFirst(Object.values(man.pieces))) {
        if (m.hidden) continue;
        if (!(N.tex[m.id] && add(m.id, N.tex[m.id]))) img(P.tex[m.id], m.x, m.y, m.w, m.h);
      }
      if (bgOn && N.over) img(N.over.src, N.over.x, N.over.y, N.over.w, N.over.h);
    }
    const z = this.el.querySelector('.nu-zoom');
    z.innerHTML = `<svg class="nu-svg" xmlns="http://www.w3.org/2000/svg" viewBox="${vb}" preserveAspectRatio="xMidYMid meet">${parts.join('')}</svg>`;
    this.zoom = { s: 1, x: 0, y: 0 }; this.place();
    this.tray();
  }
  // the pictures that come out later (hidden on the paper): colour them too, one at a time
  tray() {
    const i = this.i, P = this.A.pages[i], N = this.data.pages[i], man = P.manifest;
    // pictures that come out later, and the ones behind others (戸口の むこうの 外の けしき: under the door on the page)
    const hidden = Object.values(man.pieces).filter((m) => (m.hidden || m.depth) && N.tex[m.id]);
    const t = this.el.querySelector('.nu-tray');
    if (!hidden.length) { t.hidden = true; t.innerHTML = ''; return; }
    t.hidden = false;
    t.innerHTML = `<small>${T(hidden.some((m) => m.depth) ? 'かくれている え' : 'あとで でてくる え')}</small>
      <button class="nu-card ${this.focus ? '' : 'on'}" type="button" data-f=""><img src="${this.A.thumbs[i]}" alt=""><span>${T('ページ')}</span></button>
      ${hidden.map((m) => `<button class="nu-card ${this.focus === m.id ? 'on' : ''}" type="button" data-f="${esc(m.id)}"><img src="${P.tex[m.id]}" alt=""></button>`).join('')}`;
    t.querySelectorAll('.nu-card').forEach((b) => b.addEventListener('click', () => { this.focus = b.dataset.f || null; this.draw(); }));
  }
  fill(x, y) {
    const hit = document.elementFromPoint(x, y);
    const el = hit && hit.closest && hit.closest('[data-nk]');
    if (!el || !this.el.contains(el)) return;
    const np = el.getAttribute('data-np'), nk = el.getAttribute('data-nk');
    const pid = this.pageId(this.i), st = (this.state.pages[pid] ||= {}), cs = (st[np] ||= {});
    const prev = cs[nk] || null, color = this.color || null;
    if (prev === color) return;
    this.undo.push({ i: this.i, np, nk, prev });
    if (this.undo.length > 200) this.undo.shift();
    this.set(np, nk, color);
    this.splash(x, y, color || WHITE);
    try { this.ctx.sound.sfx('po'); } catch (e) { /* no sound */ }
  }
  set(np, nk, color) {
    const pid = this.pageId(this.i), cs = ((this.state.pages[pid] ||= {})[np] ||= {});
    if (color) cs[nk] = color; else delete cs[nk];
    this.el.querySelectorAll(`[data-np="${CSS.escape(np)}"][data-nk="${CSS.escape(nk)}"]`).forEach((e) => paint(e, color, e.getAttribute('data-nl') !== '0', e.getAttribute('data-nline')));
    this.dirty.add(this.i); this.save();
  }
  back() {
    const u = this.undo.pop(); if (!u) return;
    if (u.i !== this.i) { this.i = u.i; this.focus = null; this.draw(); }
    this.set(u.np, u.nk, u.prev);
  }
  splash(x, y, c) {
    const d = document.createElement('div'); d.className = 'nu-splash'; d.style.cssText = `left:${x}px;top:${y}px;--c:${c}`;
    document.body.appendChild(d); setTimeout(() => d.remove(), 600);
  }
  askClear() {
    const a = this.el.querySelector('.nu-ask');
    a.hidden = false;
    a.innerHTML = `<div class="nu-card2"><p>${T('いろを けして、はじめから ぬる？')}</p>
      <button class="nu-btn page" type="button">${T('この ページを けす')}</button>
      <button class="nu-btn all" type="button">${T('ぜんぶの ページを けす')}</button>
      <button class="nu-btn no" type="button">${T('やめる')}</button></div>`;
    a.querySelector('.page').addEventListener('click', () => { delete this.state.pages[this.pageId(this.i)]; this.undo = []; this.dirty.add(this.i); this.save(); a.hidden = true; this.draw(); });
    a.querySelector('.all').addEventListener('click', () => { this.A.pages.forEach((p, k) => { if (this.state.pages[p.id]) this.dirty.add(k); }); this.state.pages = {}; this.undo = []; this.save(); a.hidden = true; this.draw(); });
    a.querySelector('.no').addEventListener('click', () => { a.hidden = true; });
  }
  // zoom (＋ − and two fingers) and moving around (one finger, when zoomed); a short tap colours
  place() {
    const z = this.zoom, s = this.el.querySelector('.nu-svg'); if (!s) return;
    s.style.transform = `translate(${z.x}px, ${z.y}px) scale(${z.s})`;
  }
  zoomBy(k) {
    const z = this.zoom; z.s = Math.max(1, Math.min(5, z.s * k));
    if (z.s === 1) { z.x = 0; z.y = 0; }
    this.place();
  }
  input(stage) {
    const pts = new Map(); let moved = false, pinch = 0;
    stage.addEventListener('pointerdown', (e) => {
      if (e.target.closest('.nu-fit')) return;
      stage.setPointerCapture && stage.setPointerCapture(e.pointerId);
      pts.set(e.pointerId, { x: e.clientX, y: e.clientY, sx: e.clientX, sy: e.clientY });
      if (pts.size === 1) moved = false;
      if (pts.size === 2) { const [a, b] = [...pts.values()]; pinch = Math.hypot(a.x - b.x, a.y - b.y); moved = true; }
    });
    stage.addEventListener('pointermove', (e) => {
      const p = pts.get(e.pointerId); if (!p) return;
      const dx = e.clientX - p.x, dy = e.clientY - p.y; p.x = e.clientX; p.y = e.clientY;
      if (pts.size === 2) { const [a, b] = [...pts.values()]; const d = Math.hypot(a.x - b.x, a.y - b.y); if (pinch > 0) this.zoomBy(d / pinch); pinch = d; return; }
      if (Math.hypot(p.x - p.sx, p.y - p.sy) > 8) moved = true;
      if (moved && this.zoom.s > 1) { this.zoom.x += dx; this.zoom.y += dy; this.place(); }
    });
    const end = (e) => {
      if (!pts.has(e.pointerId)) return;
      const single = pts.size === 1; pts.delete(e.pointerId);
      if (single && !moved && e.type === 'pointerup') this.fill(e.clientX, e.clientY);
    };
    stage.addEventListener('pointerup', end); stage.addEventListener('pointercancel', end);
  }
  close() {
    if (!this.el) return;
    this.el.hidden = true; this.el.innerHTML = ''; document.body.classList.remove('nurie-open');
    if (this.state.use !== this.useBefore || this.state.bg !== this.bgBefore) this.A.pages.forEach((p, k) => this.dirty.add(k));
    const list = [...this.dirty]; this.dirty.clear();
    const done = this.onClose; this.onClose = null;
    if (done) done(list.length > 0);
    if (list.length) this.applyAll(list);
  }
}

export function makeNurie(ctx, assets) {
  if (!assets.nurie || !assets.nurie.pages) return null;
  const n = new Nurie(ctx, assets.nurie, assets);
  return n.available ? n : null;
}
