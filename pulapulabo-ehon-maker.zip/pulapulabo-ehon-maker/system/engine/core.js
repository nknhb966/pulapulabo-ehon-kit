import * as THREE from 'three';
import { PageView } from './page.js';
import { CoverPrompt } from './coverprompt.js';
import { Sound } from './sound.js';
import { UI, panel, hidePanel, showLicenses, esc, icon } from './ui.js';
import { BOOK, setBook, CALM, castColor, isCast, voice } from './book.js';
import { setReadMap, spoken } from './read.js';
import { makeLogic } from './presets.js';
import { LANG, LANGS, ADULTS, tr, trx, setLang, setBookLangs, startLang, saveLang } from './lang.js';
import { MEM, ICONS, forget, onMemory, stamp, itemOf, has, shown, markSeen, markCleared } from './story.js';
import { makeNurie } from './nurie.js';

const FONT = 'ZenMaru, "Hiragino Maru Gothic ProN", "Hiragino Sans", "Noto Sans JP", sans-serif';
let ASSETS = null;
const T = (ja) => esc(tr(ja));          // a kit text, translated, ready for HTML
const S = (t) => esc(shown(t));         // a book text, translated, ready for HTML
const castHTML = () => {
  const cast = (BOOK.cast || []).filter((c) => c.intro !== false);
  if (!cast.length) return '';
  return `<div class="cast">${cast.map((c) => `
  <div class="who" style="border-color:${esc(c.frame || c.mark || c.color || '#f1d79f')}">${ASSETS.cast[c.id] ? `<img src="${ASSETS.cast[c.id]}" alt="">` : ''}<div><b>${S(c.name)}</b><small>${S(c.look || '')}</small><span>${S(c.about || '')}</span></div></div>`).join('')}</div>`;
};
// ことば: buttons for the languages the book has (book.json "languages")
const langsHTML = () => {
  const L = (BOOK.languages || []).filter((l) => LANGS[l]);
  if (L.length < 2) return '';
  return `<div class="langs"><small>${T('ことば')}</small>${L.map((l) => `<button type="button" data-lang="${l}" class="${l === LANG.now ? 'on' : ''}" lang="${l}">${LANGS[l].name}</button>`).join('')}</div>`;
};

const img = async (url) => { const i = new Image(); i.src = url; await i.decode(); return i; };

async function loadFont() {
  try { const ff = new FontFace('ZenMaru', `url(${ASSETS.font})`, { weight: '700' }); await ff.load(); document.fonts.add(ff); } catch (e) { /* system font */ }
}
async function loadPage(P, sound, ui) {
  const tex = {}, alpha = {};
  await Promise.all(Object.entries(P.tex).map(async ([k, url]) => {
    const im = await img(url);
    const t = new THREE.Texture(im); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; t.needsUpdate = true; tex[k] = t;
    const sc = Math.min(1, 192 / Math.max(im.width, im.height));
    const w = Math.max(1, Math.round(im.width * sc)), h = Math.max(1, Math.round(im.height * sc));
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    const g = c.getContext('2d', { willReadFrequently: true }); g.drawImage(im, 0, 0, w, h);
    const d = g.getImageData(0, 0, w, h).data, a = new Uint8Array(w * h);
    for (let i = 0; i < a.length; i++) a[i] = d[i * 4 + 3];
    alpha[k] = { w, h, data: a };
  }));
  const [plateImg, maskImg] = await Promise.all([img(P.plate), img(P.mask)]);
  return new PageView({ n: P.n, manifest: P.manifest, tex, alpha, plateImg, maskImg, font: FONT, sound, ui, logic: makeLogic(P.def, P.script) });
}

// onGrab(x, y) → true: the page wants this finger's movement (onRub) instead of turning the view, and its lifting (onRelease)
function attachInput(el, { onTap, onDrag, onPinch, onGrab, onRub, onRelease }) {
  const pts = new Map(); let moved = false, pinchD = 0, multi = false, grabbed = false;
  el.addEventListener('pointerdown', (e) => {
    el.setPointerCapture && el.setPointerCapture(e.pointerId);
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY, sx: e.clientX, sy: e.clientY });
    if (pts.size === 1) { moved = false; multi = false; grabbed = !!(onGrab && onGrab(e.clientX, e.clientY)); }
    if (pts.size === 2) { multi = true; grabbed = false; const [a, b] = [...pts.values()]; pinchD = Math.hypot(a.x - b.x, a.y - b.y); }
  });
  el.addEventListener('pointermove', (e) => {
    const p = pts.get(e.pointerId); if (!p) return;
    const dx = e.clientX - p.x, dy = e.clientY - p.y; p.x = e.clientX; p.y = e.clientY;
    if (grabbed && !multi) { if (Math.hypot(p.x - p.sx, p.y - p.sy) > 10) moved = true; onRub(p.x, p.y, Math.hypot(dx, dy)); return; }
    if (pts.size === 2 && onPinch) { const [a, b] = [...pts.values()]; const d = Math.hypot(a.x - b.x, a.y - b.y); if (pinchD > 0) onPinch(d / pinchD); pinchD = d; return; }
    if (Math.hypot(p.x - p.sx, p.y - p.sy) > 10) moved = true;
    if (moved && onDrag && !multi) onDrag(dx, dy);
  });
  const end = (e) => {
    if (!pts.has(e.pointerId)) return;
    pts.delete(e.pointerId);
    if (grabbed && !multi && onRelease) onRelease(e.clientX, e.clientY);
    if (!moved && !multi && e.type === 'pointerup') onTap(e.clientX, e.clientY);
    if (!pts.size) grabbed = false;
  };
  el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
}

export async function init({ ar = false, startAR = null, assets, scripts = {} } = {}) {
  ASSETS = assets;
  Object.assign(ICONS, assets.items || {});
  setBook(assets.book);
  setReadMap(assets.read);
  setBookLangs(assets.lang);
  setLang(startLang(BOOK.languages));
  document.title = assets.book.title + (assets.book.subtitle ? ` — ${assets.book.subtitle}` : '');
  const container = document.getElementById('stage');
  const sound = new Sound();
  sound.narrationOn = !!BOOK.settings.voiceOn;
  ['touchend', 'click', 'pointerup', 'keydown'].forEach((ev) => document.addEventListener(ev, () => sound.unlock(), { passive: true }));

  CALM.on = loadCalm();
  const ctx = { container, sound, pages: {}, cur: 0, reading: false, readToken: 0, mode: 'cover', ar, played: {}, phase: {}, running: false };
  const ui = new UI({
    onRead: () => { sound.unlock(); if (ctx.reading) { stopReading(ctx); return; } if (ctx.onCover) ctx.readCover(); else readPage(ctx, ctx.cur); },
    onNarration: () => {
      sound.unlock(); sound.narrationOn = !sound.narrationOn; ui.setNarration(sound.narrationOn);
      if (!sound.narrationOn) stopReading(ctx);
      ui.toast(sound.narrationOn ? 'セリフ オン' : 'セリフ オフ', 1500);
      if (ctx.onCover) { if (sound.narrationOn && !ctx.reading) ctx.readCover(); }
      else if (ctx.phase[ctx.cur] === 'story') {
        ui.setHint(storyHint(ctx), true);
        if (sound.narrationOn && !ctx.reading) readPage(ctx, ctx.cur);
      }
    },
    onSfx: () => { sound.unlock(); sound.sfxOn = !sound.sfxOn; sound.syncAmbience(); ui.setSfx(sound.sfxOn); ui.toast(sound.sfxOn ? 'こうかおん オン' : 'こうかおん オフ', 1500); },
    onText: () => { sound.unlock(); setText(ctx, !ctx.textOn); ui.toast(ctx.textOn ? 'もじを ひょうじ' : 'もじを かくす', 1500); },
    onReset: () => {
      sound.unlock(); if (ctx.onCover) return;
      const pg = ctx.pages[ctx.cur];
      if (pg) {
        pg.reset();
        // in play time the game starts again at once (things come out again, the hint clock starts)
        if (ctx.phase[ctx.cur] === 'play') { pg.setPlaying(true); ui.setHint(pg.logic.hint, false); }
        ui.toast('もういちど あそぼう！', 1800);
      }
      endButton(ctx);
    },
    onEnding: () => { sound.unlock(); stopReading(ctx); showEnding(ctx); },
    onPaper: () => { sound.unlock(); ctx.togglePaper && ctx.togglePaper(); },
    onPage: (d) => { sound.unlock(); ctx.goto && ctx.goto(Math.min(ctx.count, Math.max(1, ctx.cur + d))); },
    onPlay: () => { sound.unlock(); if (ctx.phase[ctx.cur] === 'story') { stopReading(ctx); enterPlay(ctx, ctx.cur); } },
    onRestart: () => { sound.unlock(); restart(ctx); restartToast(ctx); },
    onHome: () => { sound.unlock(); restart(ctx, true); showStart(ctx); },
    // ぬりえ: colour the page being read (the book waits behind)
  });
  ctx.ui = ui;
  ui.setNarration(sound.narrationOn); ui.setSfx(sound.sfxOn);

  panel('loading', `<div class="spinner"></div><p>${T('じゅんびちゅう…')}</p>`);
  await loadFont();
  for (const P of ASSETS.pages) ctx.pages[P.n] = await loadPage({ ...P, script: scripts[P.id] }, sound, ui);
  for (const pg of Object.values(ctx.pages)) pg.onComplete = (n) => pageCleared(ctx, n);
  // ぬりえ: the colours kept on this device are put on the pictures (a little at a time, after the start)
  ctx.nurie = makeNurie(ctx, ASSETS);
  // ぬりえ: only from the start screen (no button on the pages)
  if (ctx.nurie) setTimeout(() => ctx.nurie.applyAll(), 300);
  setText(ctx, LANG.now !== 'ja');
  // もちもの: show the bag; a new thing comes with a sound and a word
  onMemory((what, id) => {
    ui.setBag(MEM.items, ASSETS.items || {}, (x) => shown(itemOf(x).name), what === 'item' && has(id) ? id : null);
    if (what === 'item' && has(id)) { sound.sfx('kirarin'); ui.toast(trx('{x}を てに いれた！', { x: shown(itemOf(id).name) }), 2200); }
    if (what === 'join') { sound.sfx('kirarin'); ui.toast(trx('{x}が いっしょに いくよ！', { x: shown(itemOf(id).name) }), 2400); }
  });
  ctx.count = ASSETS.pages.length; BOOK.pageCount = ctx.count; ui.count = ctx.count; ui.el.pn.textContent = `1/${ctx.count}`;
  hidePanel('loading');
  window.__pages = ctx.pages; window.__ctx = ctx; // for automatic checks in a browser (tests); readers never use these

  ctx.startPreview = () => { hidePanel('start'); hidePanel('error'); sound.unlock(); ctx.running = true; runPreview(ctx); };
  ctx.startAR = startAR;
  // preview.html#yomi (or index.html#yomi): the reading check for the people who make the book
  if (location.hash === '#yomi') showYomi(ctx); else showStart(ctx);
  // after switching between the camera and no camera (the page was reloaded): start the chosen way
  let then = null; try { then = sessionStorage.getItem('ehon-start'); sessionStorage.removeItem('ehon-start'); } catch (e) { /* no storage */ }
  if (then === 'preview') ctx.startPreview();
  else if (then === 'camera' && ar) { const go = document.querySelector('#start .go'); if (go) go.click(); }
}

// ひかえめモード (fewer flashes, gentler moves): remembered on this phone
function loadCalm() {
  try { const v = localStorage.getItem('ehon-calm'); if (v === '1' || v === '0') return v === '1'; } catch (e) { /* storage blocked */ }
  return BOOK.calm === true || !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
}
const calmLabel = () => `${tr('ひかえめモード（ひかりと うごきを ひかえめに）')}：${tr(CALM.on ? 'オン' : 'オフ')}`;
function wireCalm() {
  const b = document.querySelector('#start .calm'); if (!b) return;
  b.textContent = calmLabel();
  b.addEventListener('click', () => {
    CALM.on = !CALM.on; b.textContent = calmLabel();
    try { localStorage.setItem('ehon-calm', CALM.on ? '1' : '0'); } catch (e) { /* storage blocked */ }
  });
}

// the links at the bottom of every start panel: ひかえめモード, ことば, おとなの かたへ, ライセンス表示
function wireStart(ctx) {
  wireCalm();
  document.querySelector('#start .lic').addEventListener('click', showLicenses);
  const ad = document.querySelector('#start .adults'); if (ad) ad.addEventListener('click', showAdults);
  document.querySelectorAll('#start .langs button').forEach((b) => b.addEventListener('click', () => {
    setLang(b.dataset.lang); saveLang(LANG.now); ctx.ui.relabel(); setText(ctx, LANG.now !== 'ja'); showStart(ctx);
  }));
}
// ぬりえ on the start screen: colour the pictures first (the start screen is there again after)
const nurieHTML = (ctx) => (ctx.nurie ? `<button class="big nuriego" type="button">${icon('crayon', '#ffffff')} ${T('ぬりえ（いろを ぬる）')}</button>` : '');
function wireNurie(ctx) {
  const b = document.querySelector('#start .nuriego'); if (!b) return;
  b.addEventListener('click', () => { ctx.sound.unlock(); ctx.nurie.open(0); });
}
const startTail = () => `<button class="link calm" type="button"></button>${BOOK.settings.forAdults ? `<button class="link adults" type="button">${T('おとなの かたへ')}</button>` : ''}
      <button class="link lic" type="button">${T('ライセンス表示')}</button>`;

// はじめる画面: always the same items, also when coming back to it with the "はじめ" button while the book is open.
// Then "はじめる" / "カメラで はじめる" reads again from page 1 (the camera keeps running);
// switching between the camera and no camera reloads the page and starts the other way (the camera is never left half on).
function showStart(ctx) {
  const { sound, container } = ctx;
  const startPreview = ctx.startPreview, startAR = ctx.startAR;
  const how = BOOK.settings.readFirst ? `<p class="howto">${T('① まず おはなしを よむ（きく）')}<br>${T('② 「あそぶ」を おすと、えに さわって あそべるよ')}</p>` : '';
  const sub = BOOK.subtitle ? S(BOOK.subtitle) : T('AR えほん');
  const again = () => { sound.unlock(); hidePanel('start'); restart(ctx); if (ctx.camera) ctx.ui.toast('1ページを うつしてね', 2600); };
  const switchTo = (how2) => { try { sessionStorage.setItem('ehon-start', how2); } catch (e) { /* no storage: just reload */ } location.reload(); };
  if (!ctx.ar) {
    panel('start', `
      <h1>${S(BOOK.title)}</h1>
      <p class="sub">${sub} ・ ${T('カメラなしプレビュー')}</p>
      ${langsHTML()}${castHTML()}${how}
      <p>${T('ゆびで ドラッグすると みる むきが かわるよ。')}</p>
      <button class="big go" type="button">${T('はじめる')}</button>
      ${nurieHTML(ctx)}
      <p class="note">${T('おとが でます。iPhone は マナーモードを オフにしてね。')}</p>
      ${startTail()}`);
    wireStart(ctx); wireNurie(ctx);
    document.querySelector('#start .go').addEventListener('click', ctx.running ? again : startPreview);
    return;
  }
  panel('start', `
    <h1>${S(BOOK.title)}</h1>
    <p class="sub">${sub}</p>
    ${langsHTML()}${castHTML()}${how}
    <p>${T('スマホの カメラを つかいます。')}<br>${T('えほんの ページ（いんさつした かみ、または パソコンの がめん）を よういしてね。')}</p>
    <button class="big go" type="button">${T('カメラで はじめる')}</button>
    <button class="link nocam" type="button">${T('カメラなしで みる')}</button>
    ${nurieHTML(ctx)}
    <p class="note">${T('おとが でます。iPhone は マナーモードを オフにしてね。')}</p>
    ${startTail()}`);
  wireStart(ctx); wireNurie(ctx);
  // カメラなしで みる: the first time, or again while it is open without the camera; with the camera on, switch over
  document.querySelector('#start .nocam').addEventListener('click', !ctx.running ? startPreview : ctx.camera ? () => switchTo('preview') : again);
  // カメラで はじめる: the first time; again while the camera is on; from the no-camera view, switch over
  document.querySelector('#start .go').addEventListener('click', ctx.running && ctx.camera ? again : ctx.running ? () => switchTo('camera') : async () => {
    sound.unlock(); hidePanel('start');
    panel('loading', `<div class="spinner"></div><p>${T('カメラを じゅんびちゅう…')}</p>`);
    try { await startAR(ctx); ctx.running = true; ctx.camera = true; hidePanel('loading'); }
    catch (err) {
      hidePanel('loading'); container.innerHTML = '';
      const insecure = !window.isSecureContext;
      panel('error', `<h2>${T('カメラが つかえませんでした')}</h2>
        <p>${insecure ? T('この ページは https の URL で ひらく ひつようが あります。') : `${T('カメラの きょかを オンにして、もういちど ためしてね。')}<br>${T('（ブラウザの せってい → カメラ → きょか）')}`}</p>
        <button class="big retry" type="button">${T('もういちど')}</button>
        <button class="link nocam" type="button">${T('カメラなしで みる')}</button>`);
      document.querySelector('#error .retry').addEventListener('click', () => location.reload());
      document.querySelector('#error .nocam').addEventListener('click', startPreview);
    }
  });
}

// ---------- よみあげ チェック (#yomi) ----------
// every line the voice reads — the story and the characters' lines — with ▶ to hear it in this phone's voice
function linesOf(def) {
  const out = [], seen = new Set();
  const add = (text, who) => { if (typeof text === 'string' && text.trim() && !seen.has(text)) { seen.add(text); out.push({ text, who: who || 'n' }); } };
  (def.story || []).forEach((s) => add(typeof s === 'string' ? s : s && s.text, 'n'));
  const walk = (v, who) => {
    if (!v || typeof v !== 'object') return;
    if (Array.isArray(v)) { v.forEach((x) => walk(x, who)); return; }
    const w = v.who || v.on || who;
    if (v.say !== undefined) [].concat(v.say).forEach((x) => (typeof x === 'string' ? add(x, w) : walk(x, w)));
    if (typeof v.text === 'string' && v.who) add(v.text, v.who);
    if (typeof v.question === 'string') add(v.question, w);
    for (const [k, x] of Object.entries(v)) {
      if (['story', 'say', 'pieces'].includes(k) || !x || typeof x !== 'object') continue;
      if (['touch', 'react', 'again', 'undo', 'wrong'].includes(k) && !Array.isArray(x)) Object.entries(x).forEach(([id, spec]) => walk(spec, id));
      else if (k === 'items' && Array.isArray(x)) x.forEach((it) => walk(it, it && (it.who || it.item || it.spot)));
      else walk(x, w);
    }
  };
  walk(def, 'n');
  return out;
}
function showYomi(ctx) {
  const all = [];
  const who = (id) => (id === 'n' ? tr('おはなし') : shown((BOOK.byId[id] && BOOK.byId[id].name) || id));
  const pagesHTML = ASSETS.pages.map((P) => {
    const rows = linesOf(P.def).map((L) => {
      const i = all.push(L) - 1;
      return `<div class="row"><button class="play" type="button" data-i="${i}" aria-label="▶">▶</button><div><span class="t">${S(L.text)}</span>
        <small>${esc(who(L.who))}${LANG.now === 'ja' ? `　よみ：${esc(spoken(L.text))}` : ''}</small></div></div>`;
    }).join('');
    return `<h3><span>${P.n}. ${S(P.def.name || '')}</span><button class="all" type="button" data-p="${P.n}">${T('この ページを ぜんぶ よむ')}</button></h3>${rows}`;
  }).join('');
  // lines written only in read.json (those of page scripts, script.js)
  const norm = (t) => String(t).replace(/[\s\u3000]+/g, '');
  const known = new Set(all.map((L) => norm(L.text)));
  const extra = Object.keys(ASSETS.read || {}).filter((t) => !known.has(norm(t))).map((t) => {
    const i = all.push({ text: t, who: 'n' }) - 1;
    return `<div class="row"><button class="play" type="button" data-i="${i}" aria-label="▶">▶</button><div><span class="t">${S(t)}</span>${LANG.now === 'ja' ? `<small>よみ：${esc(spoken(t))}</small>` : ''}</div></div>`;
  }).join('');
  const el = panel('yomi', `<h2>${T('よみあげ チェック')}</h2>
    <p class="note">${T('▶ を おすと、この スマホの こえで よみます。よみかたが ちがう ことばは、読み上げ原稿（read）を なおします。')}</p>
    ${langsHTML()}${pagesHTML}${extra ? `<h3><span>${T('そのほかの セリフ')}</span></h3>${extra}` : ''}
    <button class="big close" type="button">${T('はじめる がめんへ')}</button>`);
  const say = (list) => { ctx.sound.unlock(); ctx.sound.narrate(list.map((L) => ({ text: L.text, voice: voice(L.who) }))); };
  el.querySelectorAll('.play').forEach((b) => b.addEventListener('click', () => say([all[+b.dataset.i]])));
  el.querySelectorAll('.all').forEach((b) => b.addEventListener('click', () => say(linesOf(ASSETS.pages[+b.dataset.p - 1].def))));
  el.querySelectorAll('.langs button').forEach((b) => b.addEventListener('click', () => { setLang(b.dataset.lang); saveLang(LANG.now); ctx.ui.relabel(); setText(ctx, LANG.now !== 'ja'); showYomi(ctx); }));
  el.querySelector('.close').addEventListener('click', () => {
    ctx.sound.stopSpeech(); hidePanel('yomi');
    try { history.replaceState(null, '', location.pathname + location.search); } catch (e) { /* file:// */ }
    showStart(ctx);
  });
}

// ---------- おとなの かたへ ----------
function showAdults() {
  const A = ADULTS[LANG.now] || ADULTS.ja, li = (t) => `<li>${esc(t)}</li>`;
  const url = BOOK.url ? `<li>${esc(A.url)}：<a href="${esc(BOOK.url)}" target="_blank" rel="noopener">${esc(BOOK.url)}</a></li>` : '';
  const el = panel('adults', `<h2>${T('おとなの かたへ')}</h2>
    <h3>${esc(A.titles.how)}</h3><ol>${A.how.map(li).join('')}</ol>
    <h3>${esc(A.titles.safe)}</h3><ul>${A.safe.map(li).join('')}</ul>
    ${BOOK.adultNote ? `<p>${S(BOOK.adultNote)}</p>` : ''}
    <h3>${esc(A.titles.about)}</h3>
    <ul><li>${S(BOOK.title)}${BOOK.subtitle ? ` — ${S(BOOK.subtitle)}` : ''}</li>${BOOK.author ? `<li>${esc(A.by)}：${S(BOOK.author)}</li>` : ''}${url}<li>${esc(A.kit)}</li></ul>
    <button class="big close" type="button">${T('とじる')}</button>`);
  el.querySelector('.close').addEventListener('click', () => hidePanel('adults'));
}

// ---------- ごほうびスタンプ・おしまい ----------
// a page's stamp: one of the characters on that page who has a picture (cast/<id>) — a different one on each page
// when there are several — in their colour
function stampHTML(ctx, n, got = true) {
  if (!got) return `<div class="stamp empty"><span class="no">${n}</span></div>`;
  const pg = ctx.pages[n];
  const present = (BOOK.cast || []).map((c) => c.id).filter((id) => pg.cards[id] && ASSETS.cast[id]);
  const who = present.length ? present[(n - 1) % present.length] : Object.keys(pg.cards).find((id) => isCast(id));
  const col = who ? castColor(who) : '#e8756a';
  return `<div class="stamp" style="--c:${esc(col)}">${who && ASSETS.cast[who] ? `<img src="${ASSETS.cast[who]}" alt="">` : '<span class="star">★</span>'}<span class="no">${n}</span></div>`;
}
function pageCleared(ctx, n) {
  markCleared(n);
  if (!BOOK.settings.ending) return;
  if (stamp(n)) setTimeout(() => ctx.ui.stampPop(stampHTML(ctx, n)), 2300);
  // the last page: the おしまい button comes after the page's own celebration; the ending opens when it is pressed
  if (n === ctx.count) { clearTimeout(ctx.endT); ctx.endT = setTimeout(() => endButton(ctx), 3200); }
}
// the おしまい button: on the last page, once it is cleared
function endButton(ctx) {
  const pg = ctx.pages[ctx.count];
  ctx.ui.setEnd(!!(BOOK.settings.ending && ctx.cur === ctx.count && pg && pg.done && ctx.phase[ctx.count] === 'play'));
}
// おしまい: the book's last page — thanks, who made it, the stamps, and two ways on (back to the cover / read again from page 1)
function showEnding(ctx) {
  const got = Object.keys(MEM.stamps).length;
  const stamps = Array.from({ length: ctx.count }, (_, i) => stampHTML(ctx, i + 1, !!MEM.stamps[i + 1])).join('');
  const el = panel('ending', `<h1>${T('おしまい')}</h1>
    <p>${T('よんでくれて ありがとう！')}</p>
    <h2>${T('ごほうびスタンプ')}</h2>
    <div class="stamps">${stamps}</div>
    <p class="note">${T(got >= ctx.count ? 'ぜんぶの ページで スタンプを もらったよ！' : 'スタンプの ない ページも あそんでみてね')}</p>
    <button class="big restart" type="button">${icon('restart')}<span>${T('さいしょから よむ')}</span></button>
    <button class="big second home" type="button">${icon('home')}<span>${T('はじめに もどる')}</span></button>
    ${BOOK.author ? `<p class="by">${T('さく')}${LANG.now === 'ja' ? '：' : ': '}${S(BOOK.author)}</p>` : ''}`);
  el.querySelector('.home').addEventListener('click', () => { ctx.sound.unlock(); restart(ctx, true); showStart(ctx); });
  el.querySelector('.restart').addEventListener('click', () => { ctx.sound.unlock(); restart(ctx); restartToast(ctx); });
}
const restartToast = (ctx) => ctx.ui.toast(ctx.ar ? '1ページから よもう！ 1ページを うつしてね' : 'さいしょから よもう！', 2600);

// AR の文章 (the もじ button): the story box in the language being used, over the printed one.
// It starts shown in other languages (the paper is in Japanese) and hidden in Japanese.
function setText(ctx, on) {
  ctx.textOn = on; ctx.ui.setText(on);
  Object.values(ctx.pages).forEach((p) => p.setText(on));
}

// ---------- narration ----------
function stopReading(ctx) {
  ctx.readToken++; ctx.sound.stopSpeech(); ctx.reading = false; ctx.ui.setReading(false);
  if (BOOK.settings.highlight) Object.values(ctx.pages).forEach((p) => p.highlight(-1));
}
function readPage(ctx, n) {
  const pg = ctx.pages[n]; if (!pg) return;
  if (!ctx.sound.canSpeak) { ctx.ui.toast('この たんまつでは よみあげが つかえません'); return; }
  const token = ++ctx.readToken;
  ctx.reading = true; ctx.ui.setReading(true);
  // each printed line: highlighted on the page while it is read, and shown as a subtitle in another language
  const segs = pg.narration().map((sg) => (sg.line === undefined ? sg : { ...sg, onstart: () => {
    if (sg.onstart) sg.onstart();
    if (BOOK.settings.highlight) pg.highlight(sg.line);
    if (LANG.now !== 'ja' && !ctx.textOn) ctx.ui.caption(shown(sg.text));   // (the AR text box shows it already)
  } }));
  ctx.sound.narrate(segs, () => {
    if (token !== ctx.readToken) return; // stopped or replaced: not a real ending
    ctx.reading = false; ctx.ui.setReading(false);
    if (BOOK.settings.highlight) pg.highlight(-1);
    // story time ends when the reading finishes
    if (ctx.cur === n && ctx.phase[n] === 'story') enterPlay(ctx, n);
  });
}
// the cover's words (camera): read with the narrator's voice, like a page
function readCover(ctx, prompt) {
  if (!ctx.sound.canSpeak) { ctx.ui.toast('この たんまつでは よみあげが つかえません'); return; }
  const token = ++ctx.readToken;
  ctx.reading = true; ctx.ui.setReading(true);
  ctx.sound.narrate([{ text: prompt.text(), voice: voice('n') }], () => {
    if (token !== ctx.readToken) return;
    ctx.reading = false; ctx.ui.setReading(false);
  });
}
function storyHint(ctx) {
  return ctx.sound.narrationOn ? 'おはなしを きいてね' : 'おはなしを よんだら「あそぶ」を おしてね';
}
// story phase: the page pops up and is read; touching only leaves paw prints
function enterStory(ctx, n) {
  ctx.phase[n] = 'story'; ctx.pages[n].setPlaying(false);
  ctx.ui.setHint(storyHint(ctx), true); ctx.ui.setStory(true);
  if (ctx.sound.narrationOn) ctx.narrT = setTimeout(() => { if (ctx.cur === n && ctx.phase[n] === 'story' && !ctx.reading) readPage(ctx, n); }, 1600);
}
// play phase: touching works; the page's goal stays on screen
function enterPlay(ctx, n, quiet = false) {
  ctx.phase[n] = 'play'; ctx.played[n] = true; ctx.pages[n].setPlaying(true);
  const L = ctx.pages[n].logic;
  ctx.ui.setStory(false); ctx.ui.setHint(L.hint, false);
  if (!quiet) ctx.pages[n].playSignal();
}
function activate(ctx, n, force = false) {
  const changed = ctx.cur !== n;
  ctx.cur = n; markSeen(n);
  const L = ctx.pages[n].logic;
  ctx.ui.setPage(n, L.name, L.progress);
  if (!changed && !force) return;
  stopReading(ctx);
  clearTimeout(ctx.narrT);
  if (ctx.played[n] || !BOOK.settings.readFirst) enterPlay(ctx, n, true); else enterStory(ctx, n);
  endButton(ctx);
}
// back to page 1 with every page reset (camera: the reader turns back to page 1)
function restart(ctx, quiet = false) {
  stopReading(ctx); clearTimeout(ctx.narrT); clearTimeout(ctx.endT);
  forget(); hidePanel('ending'); ctx.ui.setEnd(false);
  Object.values(ctx.pages).forEach((p) => p.reset());
  ctx.played = {}; ctx.phase = {};
  if (quiet) return;
  if (ctx.goto) { if (ctx.cur === 1) activate(ctx, 1, true); else ctx.goto(1); }
  else if (ctx.cur) activate(ctx, ctx.cur, true);
}

// ---------- camera AR ----------
export async function runAR(ctx, MindARThree, mindURL) {
  const { container, ui, pages } = ctx;
  const mt = new MindARThree({
    container, imageTargetSrc: mindURL, maxTrack: 1,
    uiLoading: 'no', uiScanning: 'no', uiError: 'no',
    filterMinCF: 0.0001, filterBeta: 0.005, missTolerance: 8, warmupTolerance: 3,
  });
  const { renderer, scene, camera } = mt;
  renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
  const anchors = {};
  let coverA = null;
  const nothingShown = () => !Object.values(anchors).some((x) => x.group.visible) && !(coverA && coverA.group.visible);
  for (let n = 1; n <= ctx.count; n++) {
    const a = mt.addAnchor(n - 1); anchors[n] = a;
    a.group.add(pages[n].root); pages[n].setMode('reveal');
    let lost = null;
    a.onTargetFound = () => {
      clearTimeout(lost); hidePanel('scan');
      if (ctx.onCover) { ctx.onCover = false; ui.setCover(false); stopReading(ctx); }
      pages[n].setOpen(true); activate(ctx, n);
    };
    a.onTargetLost = () => { clearTimeout(lost); lost = setTimeout(() => { pages[n].setOpen(false, true); if (nothingShown()) scan(); }, 1200); };
  }
  // the printed cover (after the pages in targets.mind): a card asks to turn to page 1, with a soft キラン and,
  // with セリフ on, the words read out. Nothing on it can be touched.
  const prompt = ASSETS.coverTarget ? new CoverPrompt({ thumb: ASSETS.thumbs[0], font: FONT }) : null;
  if (prompt) {
    coverA = mt.addAnchor(ctx.count); coverA.group.add(prompt.group);
    ctx.readCover = () => readCover(ctx, prompt);
    let lost = null, shown = false;
    coverA.onTargetFound = () => {
      clearTimeout(lost); hidePanel('scan');
      ctx.onCover = true; ui.setCover(true);
      if (shown) return;   // found again right after a moment lost: the card just stays
      shown = true; prompt.show();
      stopReading(ctx); clearTimeout(ctx.narrT);
      ctx.sound.sfx('kirarin');
      if (ctx.sound.narrationOn) ctx.narrT = setTimeout(() => { if (ctx.onCover && !ctx.reading) ctx.readCover(); }, 700);
    };
    coverA.onTargetLost = () => {
      clearTimeout(lost);
      lost = setTimeout(() => {
        shown = false;
        if (ctx.onCover) { ctx.onCover = false; ui.setCover(false); if (ctx.reading) stopReading(ctx); }
        if (nothingShown()) scan();
      }, 1200);
    };
  }
  ctx.mode = 'reveal';
  ctx.togglePaper = () => {
    ctx.mode = ctx.mode === 'cover' ? 'reveal' : 'cover';
    Object.values(pages).forEach((p) => p.setMode(ctx.mode));
    ui.setPaperMode(ctx.mode === 'cover');
    ui.toast(ctx.mode === 'cover' ? 'ページ ぜんたいを ARで おおいました' : 'かみの えが みえるように しました', 2200);
  };
  const scan = () => panel('scan', `<div class="grid">${ASSETS.thumbs.map((t) => `<img src="${t}" alt="">`).join('')}</div><p>${T('えほんの ページを うつしてね')}</p>`);
  await mt.start();
  ui.setPaperLabel('おおう'); ui.setNav(false); ui.show(true); scan();

  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2(), cam = new THREE.Vector3();
  attachInput(container, {
    onTap: (x, y) => {
      ctx.sound.unlock();
      const a = anchors[ctx.cur]; if (!a || !a.group.visible) return;
      const r = renderer.domElement.getBoundingClientRect();
      ndc.set(((x - r.left) / r.width) * 2 - 1, -((y - r.top) / r.height) * 2 + 1);
      scene.updateMatrixWorld(); ray.setFromCamera(ndc, camera);
      const pg = pages[ctx.cur]; pg.tap(pg.pick(ray), ctx.phase[ctx.cur] === 'play');
    },
    onGrab: (x, y) => { const pg = pages[ctx.cur], a = anchors[ctx.cur]; if (!pg || !a || !a.group.visible) return false; return pg.grab(pickAt(x, y)); },
    onRub: (x, y, d) => { const pg = pages[ctx.cur]; if (pg) pg.rubAt(pickAt(x, y), d); },
    onRelease: (x, y) => { const pg = pages[ctx.cur]; if (pg) pg.release(pickAt(x, y)); },
  });
  function pickAt(x, y) {
    const r = renderer.domElement.getBoundingClientRect();
    ndc.set(((x - r.left) / r.width) * 2 - 1, -((y - r.top) / r.height) * 2 + 1);
    scene.updateMatrixWorld(); ray.setFromCamera(ndc, camera);
    return pages[ctx.cur].touchAt(ray);
  }
  const clock = new THREE.Clock();
  renderer.setAnimationLoop(() => {
    const dt = clock.getDelta();
    scene.updateMatrixWorld();
    camera.getWorldPosition(cam);
    if (coverA && coverA.group.visible) prompt.update(dt);
    for (let n = 1; n <= ctx.count; n++) {
      if (!anchors[n].group.visible) continue;
      const pg = pages[n];
      pg.setViewDir(pg.root.worldToLocal(cam.clone()));
      pg.measure(camera, container.clientWidth, container.clientHeight);
      pg.update(dt);
    }
    renderer.render(scene, camera);
  });
}

// ---------- camera-free preview ----------
function radialTex(inner, outer) {
  const c = document.createElement('canvas'); c.width = c.height = 256;
  const g = c.getContext('2d'); const grd = g.createRadialGradient(128, 128, 10, 128, 128, 128);
  grd.addColorStop(0, inner); grd.addColorStop(1, outer); g.fillStyle = grd; g.fillRect(0, 0, 256, 256);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
function runPreview(ctx) {
  const { container, ui, pages } = ctx;
  container.classList.add('preview');
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
  container.appendChild(renderer.domElement);
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(38, 1, 0.01, 50); camera.up.set(0, 0, 1);
  const shade = new THREE.Mesh(new THREE.PlaneGeometry(1.55, 1.3), new THREE.MeshBasicMaterial({ map: radialTex('rgba(0,0,0,0.55)', 'rgba(0,0,0,0)'), transparent: true, depthWrite: false }));
  shade.position.set(0.02, 0, -0.004); scene.add(shade);

  let az = 0, el = 0.9, zoom = 1, base = 2;
  const resize = () => {
    const w = container.clientWidth, h = container.clientHeight;
    renderer.setSize(w, h); camera.aspect = w / h; camera.updateProjectionMatrix();
    const tv = Math.tan((camera.fov / 2) * Math.PI / 180);
    base = Math.max(0.62 / (tv * camera.aspect), 0.66 / tv);
  };
  const place = () => {
    const d = base * zoom;
    camera.position.set(d * Math.cos(el) * Math.sin(az), -d * Math.cos(el) * Math.cos(az), d * Math.sin(el));
    camera.lookAt(0, 0.03, 0.08);
  };
  window.addEventListener('resize', () => { resize(); place(); }); resize(); place();

  ctx.goto = (n) => {
    if (n === ctx.cur) return;
    const old = pages[ctx.cur];
    if (old) { old.setOpen(false, true); scene.remove(old.root); }
    const pg = pages[n]; scene.add(pg.root); pg.setMode(ctx.mode);
    if (pg.logic.opening) pg.logic.opening(pg);   // what is not there now is never seen, not even lying flat
    setTimeout(() => pg.setOpen(true), 150);
    activate(ctx, n);
  };
  ctx.togglePaper = () => {
    ctx.mode = ctx.mode === 'arOnly' ? 'cover' : 'arOnly';
    Object.values(pages).forEach((p) => p.setMode(ctx.mode));
    shade.visible = ctx.mode !== 'arOnly';
    ui.setPaperMode(ctx.mode === 'arOnly');
    ui.toast(ctx.mode === 'arOnly' ? 'かみを かくして、ARの ぶぶんだけ ひょうじ' : 'かみも ひょうじ', 2200);
  };

  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
  attachInput(renderer.domElement, {
    onTap: (x, y) => {
      ctx.sound.unlock();
      const r = renderer.domElement.getBoundingClientRect();
      ndc.set(((x - r.left) / r.width) * 2 - 1, -((y - r.top) / r.height) * 2 + 1);
      scene.updateMatrixWorld(); ray.setFromCamera(ndc, camera);
      const pg = pages[ctx.cur]; pg.tap(pg.pick(ray), ctx.phase[ctx.cur] === 'play');
    },
    onDrag: (dx, dy) => { az = Math.max(-0.7, Math.min(0.7, az - dx * 0.005)); el = Math.max(0.3, Math.min(1.38, el + dy * 0.005)); place(); },
    onPinch: (k) => { zoom = Math.max(0.55, Math.min(1.4, zoom / k)); place(); },
    onGrab: (x, y) => pages[ctx.cur].grab(pickAt(x, y)),
    onRub: (x, y, d) => pages[ctx.cur].rubAt(pickAt(x, y), d),
    onRelease: (x, y) => pages[ctx.cur].release(pickAt(x, y)),
  });
  function pickAt(x, y) {
    const r = renderer.domElement.getBoundingClientRect();
    ndc.set(((x - r.left) / r.width) * 2 - 1, -((y - r.top) / r.height) * 2 + 1);
    scene.updateMatrixWorld(); ray.setFromCamera(ndc, camera);
    return pages[ctx.cur].touchAt(ray);
  }

  ui.setPaperLabel('ARだけ'); ui.setNav(ctx.count > 1); ui.show(true);
  ctx.goto(1);

  const clock = new THREE.Clock(), cam = new THREE.Vector3();
  renderer.setAnimationLoop(() => {
    const dt = clock.getDelta();
    const pg = pages[ctx.cur];
    camera.getWorldPosition(cam);
    pg.setViewDir(pg.root.worldToLocal(cam.clone()));
    pg.measure(camera, container.clientWidth, container.clientHeight);
    pg.update(dt);
    renderer.render(scene, camera);
  });
}
