// Visual effects: GPU point particles (sparkles, fireworks, steam…), onomatopoeia text, speech bubbles.
import * as THREE from 'three';
import { CALM } from './book.js';

export const easeOutBack = (t) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };
export const easeInOut = (t) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2);

function canvasTex(w, h, draw) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

let SPARK = null;
function sparkTexture() {
  if (SPARK) return SPARK;
  SPARK = canvasTex(64, 64, (g, w, h) => {
    const cx = w / 2, cy = h / 2;
    const grd = g.createRadialGradient(cx, cy, 0, cx, cy, 30);
    grd.addColorStop(0, 'rgba(255,255,255,1)'); grd.addColorStop(0.25, 'rgba(255,255,255,0.55)'); grd.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = grd; g.fillRect(0, 0, w, h);
    g.fillStyle = '#fff'; g.beginPath();
    const s = 30, k = 3.5;
    g.moveTo(cx, cy - s); g.quadraticCurveTo(cx + k, cy - k, cx + s, cy); g.quadraticCurveTo(cx + k, cy + k, cx, cy + s);
    g.quadraticCurveTo(cx - k, cy + k, cx - s, cy); g.quadraticCurveTo(cx - k, cy - k, cx, cy - s); g.fill();
  });
  return SPARK;
}

// ---------- particles: one draw call for everything ----------
export class Particles {
  constructor(max = 1400) {
    this.max = max; this.n = 0;
    const g = new THREE.BufferGeometry();
    this.pos = new Float32Array(max * 3); this.col = new Float32Array(max * 3);
    this.size = new Float32Array(max); this.alpha = new Float32Array(max);
    this.vel = new Float32Array(max * 3); this.life = new Float32Array(max); this.maxLife = new Float32Array(max);
    this.drag = new Float32Array(max); this.grav = new Float32Array(max); this.size0 = new Float32Array(max); this.tw = new Float32Array(max);
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('pcolor', new THREE.BufferAttribute(this.col, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('psize', new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('palpha', new THREE.BufferAttribute(this.alpha, 1).setUsage(THREE.DynamicDrawUsage));
    g.setDrawRange(0, 0);
    this.uniforms = { map: { value: sparkTexture() }, uPx: { value: 400 } };
    const m = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      vertexShader: `attribute vec3 pcolor; attribute float psize; attribute float palpha; uniform float uPx;
        varying vec3 vC; varying float vA;
        void main(){ vec4 mv = modelViewMatrix * vec4(position,1.0);
          float s = length(modelViewMatrix[0].xyz);
          gl_PointSize = clamp(psize * s * uPx * projectionMatrix[1][1] / -mv.z, 0.0, 256.0);
          gl_Position = projectionMatrix * mv; vC = pcolor; vA = palpha; }`,
      fragmentShader: `uniform sampler2D map; varying vec3 vC; varying float vA;
        void main(){ vec4 t = texture2D(map, gl_PointCoord); gl_FragColor = vec4(vC * t.rgb, t.a * vA); }`,
      transparent: true, depthWrite: false, depthTest: false, blending: THREE.AdditiveBlending,
    });
    this.points = new THREE.Points(g, m);
    this.points.frustumCulled = false; this.points.renderOrder = 900;
    this.tmpC = new THREE.Color();
    this.up = new THREE.Vector3(0, 0.5, 0.86);
  }
  setPixelScale(h) { this.uniforms.uPx.value = h / 2; }
  emit(p, v, color, size = 0.02, life = 1, drag = 0.94, grav = -0.25, tw = 1) {
    if (this.n >= this.max) return;
    if (CALM.on && Math.random() < 0.5) return; // ひかえめモード: half the sparkles
    const i = this.n++;
    this.pos.set([p.x, p.y, p.z], i * 3); this.vel.set([v.x, v.y, v.z], i * 3);
    this.tmpC.set(color); this.col.set([this.tmpC.r, this.tmpC.g, this.tmpC.b], i * 3);
    this.size0[i] = size; this.size[i] = 0; this.alpha[i] = 1; this.life[i] = 0; this.maxLife[i] = life;
    this.drag[i] = drag; this.grav[i] = grav; this.tw[i] = tw;
  }
  // radial sparkle burst
  burst(p, n = 12, power = 1, colors = ['#fff2a8', '#ffffff', '#ffc2e2', '#bfe8ff'], size = 0.026) {
    for (let k = 0; k < n; k++) {
      const a = Math.random() * Math.PI * 2, s = (0.08 + Math.random() * 0.22) * power;
      this.emit(p, { x: Math.cos(a) * s, y: Math.sin(a) * s, z: (0.12 + Math.random() * 0.3) * power },
        colors[k % colors.length], size * (0.6 + Math.random() * 0.8), 0.7 + Math.random() * 0.6);
    }
  }
  update(dt) {
    const up = this.up;
    for (let i = 0; i < this.n; i++) {
      this.life[i] += dt;
      const u = this.life[i] / this.maxLife[i];
      if (u >= 1) { this._kill(i); i--; continue; }
      const d = Math.pow(this.drag[i], dt * 60), gr = this.grav[i] * dt;
      const j = i * 3;
      this.vel[j] = this.vel[j] * d + up.x * gr; this.vel[j + 1] = this.vel[j + 1] * d + up.y * gr; this.vel[j + 2] = this.vel[j + 2] * d + up.z * gr;
      this.pos[j] += this.vel[j] * dt; this.pos[j + 1] += this.vel[j + 1] * dt; this.pos[j + 2] += this.vel[j + 2] * dt;
      const tw = this.tw[i] ? 0.75 + 0.25 * Math.sin(this.life[i] * 34 + i) : 1;
      this.size[i] = this.size0[i] * (u < 0.12 ? u / 0.12 : 1) * tw;
      this.alpha[i] = 1 - u * u;
    }
    const g = this.points.geometry;
    g.setDrawRange(0, this.n);
    for (const k of ['position', 'pcolor', 'psize', 'palpha']) g.attributes[k].needsUpdate = true;
  }
  _kill(i) {
    const last = --this.n;
    if (i === last) return;
    const c3 = (arr) => { arr[i * 3] = arr[last * 3]; arr[i * 3 + 1] = arr[last * 3 + 1]; arr[i * 3 + 2] = arr[last * 3 + 2]; };
    c3(this.pos); c3(this.vel); c3(this.col);
    for (const a of [this.size, this.alpha, this.life, this.maxLife, this.drag, this.grav, this.size0, this.tw]) a[i] = a[last];
  }
  clear() { this.n = 0; }
}

// ---------- text sprites (onomatopoeia + bubbles) ----------
function rrect(g, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2);
  g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
}
// the print a touch leaves: the main character's hand (book.json "hand", or what the first character is: ねこ → paw,
// おとこのこ → a hand …). A white edge, then the colour, so it can be seen on any picture.
const PRINT_COLOR = { cat: '#ff8fb1', rabbit: '#ff9fc0', dog: '#c9895a', bear: '#a06a44', bird: '#f2a23a', human: '#ff9a76' };
const PRINTS = {};
function printTexture(hand) {
  const kind = hand && PRINT_COLOR[hand.kind] ? hand.kind : 'cat';
  const color = (hand && hand.print) || PRINT_COLOR[kind];
  const key = `${kind}:${color}`;
  if (PRINTS[key]) return PRINTS[key];
  PRINTS[key] = canvasTex(128, 128, (g) => {
    const shapes = [];
    const pad = (x, y, rx, ry) => shapes.push((w) => { g.beginPath(); g.ellipse(x, y, rx + w, ry + w, 0, 0, Math.PI * 2); g.fill(); });
    const bar = (x0, y0, x1, y1, r) => shapes.push((w) => { g.beginPath(); g.moveTo(x0, y0); g.lineTo(x1, y1); g.lineWidth = 2 * (r + w); g.stroke(); });
    if (kind === 'human') {   // a small hand print: palm, thumb and four fingers
      pad(64, 84, 25, 24); bar(44, 86, 22, 62, 8); bar(50, 66, 46, 26, 7.5); bar(63, 64, 63, 18, 7.5); bar(76, 66, 80, 26, 7.5); bar(86, 74, 98, 44, 6.5);
    } else if (kind === 'bird') {   // three toes in front, one behind
      bar(64, 92, 64, 34, 6); bar(64, 92, 30, 52, 6); bar(64, 92, 98, 52, 6); bar(64, 92, 64, 116, 5);
    } else if (kind === 'rabbit') {
      pad(64, 84, 22, 28); pad(38, 44, 10, 14); pad(56, 32, 10, 14); pad(74, 32, 10, 14); pad(92, 44, 10, 14);
    } else if (kind === 'dog' || kind === 'bear') {
      pad(64, 84, 31, 24); pad(30, 52, 13, 15); pad(51, 31, 13, 15); pad(77, 31, 13, 15); pad(98, 52, 13, 15);
    } else {
      pad(64, 82, 30, 25); pad(30, 50, 12, 15); pad(50, 30, 12, 15); pad(78, 30, 12, 15); pad(98, 50, 12, 15);
    }
    g.lineCap = 'round'; g.lineJoin = 'round';
    g.fillStyle = g.strokeStyle = '#ffffff'; shapes.forEach((s) => s(3.5));
    g.fillStyle = g.strokeStyle = color; shapes.forEach((s) => s(0));
  });
  return PRINTS[key];
}

// feeling marks above a character ("mark"): drawn once each, shared
export const MARK_NAMES = ['!', '?', 'note', 'heart', 'sweat', 'zzz', 'idea', 'angry'];
const MARKS = {};
function markTexture(kind, font) {
  if (MARKS[kind]) return MARKS[kind];
  MARKS[kind] = canvasTex(160, 160, (g) => {
    g.lineJoin = 'round'; g.lineCap = 'round';
    const ink = (fill, draw) => {  // dark edge, white edge, colour: the same look as the sound words
      g.save(); draw(); g.lineWidth = 18; g.strokeStyle = '#4a3360'; g.stroke(); g.restore();
      g.save(); draw(); g.lineWidth = 9; g.strokeStyle = '#ffffff'; g.stroke(); g.restore();
      g.save(); draw(); g.fillStyle = fill; g.fill(); g.restore();
    };
    const text = (t, fill, size, x = 80, y = 84) => {
      g.font = `bold ${size}px ${font}`; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.lineWidth = 22; g.strokeStyle = '#4a3360'; g.strokeText(t, x, y);
      g.lineWidth = 12; g.strokeStyle = '#ffffff'; g.strokeText(t, x, y);
      g.fillStyle = fill; g.fillText(t, x, y);
    };
    const strokes = (col, draw) => {
      for (const [w, c] of [[22, '#4a3360'], [13, '#ffffff'], [7, col]]) { g.beginPath(); draw(); g.lineWidth = w; g.strokeStyle = c; g.stroke(); }
    };
    if (kind === '!') text('！', '#ff5a4a', 120);
    else if (kind === '?') text('？', '#3fa9e0', 120);
    else if (kind === 'zzz') { text('Z', '#6a6ae8', 74, 62, 96); text('z', '#6a6ae8', 50, 112, 50); }
    else if (kind === 'heart') ink('#ff6b8a', () => { g.beginPath(); g.moveTo(80, 132); g.bezierCurveTo(20, 92, 22, 36, 56, 34); g.bezierCurveTo(70, 33, 78, 42, 80, 52); g.bezierCurveTo(82, 42, 90, 33, 104, 34); g.bezierCurveTo(138, 36, 140, 92, 80, 132); g.closePath(); });
    else if (kind === 'sweat') ink('#7cc8f2', () => { g.beginPath(); g.moveTo(80, 22); g.bezierCurveTo(98, 56, 118, 78, 118, 102); g.arc(80, 102, 38, 0, Math.PI); g.bezierCurveTo(42, 78, 62, 56, 80, 22); g.closePath(); });
    else if (kind === 'note') {
      ink('#b07ae8', () => {
        g.beginPath(); g.ellipse(52, 118, 20, 15, -0.4, 0, Math.PI * 2); g.ellipse(112, 104, 20, 15, -0.4, 0, Math.PI * 2);
        g.rect(64, 40, 10, 80); g.rect(124, 26, 10, 80);
        g.moveTo(64, 40); g.lineTo(134, 26); g.lineTo(134, 48); g.lineTo(64, 62); g.closePath();
      });
    } else if (kind === 'idea') {
      strokes('#ffcf3a', () => { for (const a of [-2.4, -1.57, -0.74, -3.0, -0.14]) { g.moveTo(80 + Math.cos(a) * 56, 72 + Math.sin(a) * 56); g.lineTo(80 + Math.cos(a) * 72, 72 + Math.sin(a) * 72); } });
      ink('#ffe066', () => { g.beginPath(); g.arc(80, 74, 34, Math.PI * 0.8, Math.PI * 2.2); g.lineTo(96, 120); g.lineTo(64, 120); g.closePath(); });
      ink('#b8b0c8', () => { g.beginPath(); g.rect(64, 122, 32, 16); });
    } else if (kind === 'angry') {
      strokes('#ff5a4a', () => {
        for (const [sx, sy] of [[1, 1], [-1, 1], [1, -1], [-1, -1]]) {
          g.moveTo(80 + sx * 14, 80 + sy * 50); g.quadraticCurveTo(80 + sx * 16, 80 + sy * 16, 80 + sx * 50, 80 + sy * 14);
        }
      });
    }
  });
  return MARKS[kind];
}

// speech bubbles and marks go where their character is, smoothly: a quick hop or a big move of the character
// does not shake them (the anchor is the character's place, not its turning picture: see page.js anchor()).
// Far away (a new place, the page turned): there at once.
function follow(d, want, dt) {
  if (!d.at || !dt || d.at.distanceTo(want) > 0.25) { d.at = want.clone(); return; }
  d.at.lerp(want, 1 - Math.exp(-dt * 7));
}

// ---------- texts kept ready ----------
// A speech bubble or a word, once drawn, is kept (it often comes again), and the ones a page can show are drawn
// before they are needed (page.js warmTexts: a few in each frame while the story is read): no drawing nor sending to the
// screen when a finger touches. Up to KEEP_TEXTS are kept; the ones used least lately and not shown now go.
const TEXTS = new Map(), KEEP_TEXTS = 120;
let UPLOAD = null;   // sends a texture to the screen now (core.js: the renderer's initTexture)
export const setTextUpload = (fn) => { UPLOAD = fn; };
function keptText(key, make) {
  let t = TEXTS.get(key);
  if (t) { TEXTS.delete(key); TEXTS.set(key, t); return t; }
  t = make(); t.users = 0; TEXTS.set(key, t);
  if (UPLOAD) UPLOAD(t.tex);
  for (const [k, v] of TEXTS) { if (TEXTS.size <= KEEP_TEXTS) break; if (!v.users) { v.tex.dispose(); TEXTS.delete(k); } }
  return t;
}
// a sprite that uses a kept text lets it go (it stays kept); any other sprite's texture is thrown away
function letGo(sp) { const d = sp.userData; if (d.text) d.text.users--; else if (d.kind !== 'stamp' && !d.shared) sp.material.map.dispose(); sp.material.dispose(); }
// one sprite that is never thrown away: the screen keeps its drawing program, so the first word or bubble after a
// quiet while does not have to make it again (core.js puts it in the scene)
export function spriteKeeper() {
  const c = document.createElement('canvas'); c.width = c.height = 2;
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, depthTest: false, depthWrite: false, transparent: true }));
  sp.visible = false; sp.name = 'keeper';
  return sp;
}

// Words, bubbles and marks that overlap: the ones from the thing touched last are in front.
// Every touch starts a new "layer"; what a touch makes (also later, through pg.later) is drawn in that layer.
// In one layer: mark < word < bubble.
let TOUCHES = 0;
const RANK = { mark: 1, ono: 2, bubble: 3 };
export class Labels {
  constructor(root, font) { this.root = root; this.font = font; this.items = []; this.bubbles = {}; this.gauges = {}; this.layer = 0; }
  // a new touch: what it shows goes in front of everything shown before
  touched() { this.layer = ++TOUCHES; return this.layer; }
  // run fn with what it shows in an earlier touch's layer (a reaction that comes a little later)
  inLayer(layer, fn) { const was = this.layer; this.layer = layer; try { return fn(); } finally { if (this.layer === layer) this.layer = was; } }
  _order(kind) { return 1000 + this.layer * 10 + RANK[kind]; }

  // the print and the feeling marks drawn and sent to the screen before the first touch (page.js warmTexts)
  warmMarks(hand, kinds) {
    const t = [printTexture(hand), ...kinds.map((k) => markTexture(k, this.font))];
    if (UPLOAD) t.forEach((x) => UPLOAD(x));
    return t;
  }
  // a picture just made ready is drawn in this frame, too small to be seen (some phones get a picture ready only
  // when it is first drawn); warmHide: the ones of the frame before go
  warmShow(i, tex) {
    const ws = this._warmSp || (this._warmSp = []);
    let sp = ws[i];
    if (!sp) {
      sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthTest: false, depthWrite: false, transparent: true }));
      sp.scale.set(0.00001, 0.00001, 1); sp.frustumCulled = false; sp.name = 'warm';
      this.root.add(sp); ws[i] = sp;
    }
    sp.material.map = tex; sp.visible = true;
  }
  warmHide() { if (this._warmSp) for (const sp of this._warmSp) sp.visible = false; }
  // tap feedback: a little print of the main character's hand (paw, hand …) that pops and fades (unlike any sparkle or glow)
  stamp(p, hand) {
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: printTexture(hand), depthTest: false, depthWrite: false, transparent: true }));
    sp.renderOrder = 940; sp.material.rotation = (Math.random() - 0.5) * 0.7;
    const s = 0.05 * (this.scale || 1);
    sp.userData = { kind: 'stamp', age: 0, life: 0.75, s };
    sp.position.set(p.x, p.y, p.z + 0.012); sp.scale.set(0.001, 0.001, 1);
    this.root.add(sp); this.items.push(sp);
  }

  // a feeling mark (MARK_NAMES) right above a character's head; it pops, bobs and fades.
  // When the character speaks, the mark goes (the words say it): see bubble()
  speaking(owner) { const b = this.bubbles[owner]; return !!(b && b.userData.age < b.userData.life); }
  mark(kind, anchorFn, owner = null) {
    if (owner && this.speaking(owner)) return;
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: markTexture(kind, this.font), depthTest: false, depthWrite: false, transparent: true }));
    sp.center.set(0.5, 0); sp.renderOrder = this._order('mark');
    const s = 0.07 * (this.scale || 1);
    sp.userData = { kind: 'mark', shared: true, age: 0, life: 1.8, s, anchorFn, owner };
    sp.position.copy(anchorFn()); sp.scale.set(0.001, 0.001, 1);
    this.root.add(sp); this.items.push(sp);
  }

  // ring timer / power bar that follows a point. kind: 'ring' | 'bar'
  gauge(key, kind, anchorFn, text = '', color = '#5fc46a') {
    this.removeGauge(key);
    const W = kind === 'bar' ? 300 : 140, H = kind === 'bar' ? 96 : 140;
    const c = document.createElement('canvas'); c.width = W; c.height = H;
    const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthTest: false, depthWrite: false, transparent: true }));
    sp.center.set(0.5, 0); sp.renderOrder = 990;
    sp.userData = { kind, anchorFn, c, tex, text, color, frac: -1, W, H, age: 0, blink: false };
    this.root.add(sp); this.gauges[key] = sp;
    this.setGauge(key, 1);
    return sp;
  }
  setGauge(key, frac, blink = false) {
    const sp = this.gauges[key]; if (!sp) return;
    const d = sp.userData;
    frac = Math.max(0, Math.min(1, frac));
    if (Math.abs(frac - d.frac) < 0.01 && blink === d.blink) return;
    d.frac = frac; d.blink = blink;
    const g = d.c.getContext('2d'); g.clearRect(0, 0, d.W, d.H);
    if (d.kind === 'ring') {
      const cx = d.W / 2, cy = d.H / 2, r = 54;
      g.fillStyle = '#fffdf6'; g.beginPath(); g.arc(cx, cy, r + 8, 0, Math.PI * 2); g.fill();
      g.lineWidth = 6; g.strokeStyle = '#4a3360'; g.stroke();
      g.lineWidth = 14; g.strokeStyle = '#e8e2f0'; g.beginPath(); g.arc(cx, cy, r - 6, 0, Math.PI * 2); g.stroke();
      g.strokeStyle = frac > 0.35 ? d.color : '#ff8a3a'; g.lineCap = 'round';
      g.beginPath(); g.arc(cx, cy, r - 6, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * frac); g.stroke();
      g.fillStyle = '#3b2e5a'; g.font = `bold ${d.text.length > 2 ? 30 : 44}px ${this.font}`; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText(d.text, cx, cy + 2);
    } else {
      const x = 10, y = 40, w = d.W - 20, h = 44;
      g.fillStyle = '#fffdf6'; g.strokeStyle = '#4a3360'; g.lineWidth = 6;
      rrect(g, x, y, w, h, 22); g.fill(); g.stroke();
      const grd = g.createLinearGradient(x, 0, x + w, 0); grd.addColorStop(0, '#ffcf5a'); grd.addColorStop(1, '#ff5a4a');
      g.fillStyle = grd; if (frac > 0.01) { rrect(g, x + 6, y + 6, (w - 12) * frac, h - 12, 16); g.fill(); }
      if (d.text) {   // the label on a small light tag, so it can be read over a dark sky too
        g.font = `bold 28px ${this.font}`; const tw = Math.min(d.W - 24, g.measureText(d.text).width + 28);
        g.fillStyle = '#fffdf6'; g.strokeStyle = '#4a3360'; g.lineWidth = 4;
        rrect(g, (d.W - tw) / 2, 2, tw, 34, 17); g.fill(); g.stroke();
        g.fillStyle = '#3b2e5a'; g.textAlign = 'center'; g.textBaseline = 'middle';
        g.fillText(d.text, d.W / 2, 20, d.W - 40);
      }
    }
    d.tex.needsUpdate = true;
  }
  removeGauge(key) {
    const g = this.gauges[key]; if (!g) return;
    this.root.remove(g); g.material.map.dispose(); g.material.dispose(); delete this.gauges[key];
  }

  _onoTex(text, color) {
    const fs = 96, pad = 26;
    const meas = document.createElement('canvas').getContext('2d');
    meas.font = `bold ${fs}px ${this.font}`;
    const w = Math.ceil(meas.measureText(text).width + pad * 2), h = Math.ceil(fs * 1.45);
    const tex = canvasTex(w, h, (g) => {
      g.font = `bold ${fs}px ${this.font}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineJoin = 'round';
      g.lineWidth = 26; g.strokeStyle = '#4a3360'; g.strokeText(text, w / 2, h / 2);
      g.lineWidth = 15; g.strokeStyle = '#ffffff'; g.strokeText(text, w / 2, h / 2);
      g.fillStyle = color; g.fillText(text, w / 2, h / 2);
    });
    return { tex, W: w, H: h };
  }
  onoText(text, color = '#ff6a5a') { return keptText(`o|${color}|${text}`, () => this._onoTex(text, color)); }
  bubbleText(text, color) { return keptText(`b|${color}|${text}`, () => this._bubbleTex(text, color)); }
  ono(text, p, color = '#ff6a5a', size = 1) {
    const T = this.onoText(text, color), w = T.W, h = T.H; T.users++;
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: T.tex, depthTest: false, depthWrite: false, transparent: true }));
    sp.center.set(0.5, 0); sp.renderOrder = this._order('ono');
    const k = 0.00052 * size * (this.scale || 1);
    sp.material.rotation = (Math.random() - 0.5) * 0.3;
    sp.userData = { kind: 'ono', age: 0, life: 1.25, w: w * k, h: h * k, p0: p.clone(), text: T };
    sp.position.copy(p); sp.scale.set(0.001, 0.001, 1);
    this.root.add(sp); this.items.push(sp);
  }

  _bubbleTex(text, color) {
    const fs = 46, pad = 30, maxW = 600;
    const meas = document.createElement('canvas').getContext('2d');
    meas.font = `bold ${fs}px ${this.font}`;
    const lines = [];
    // a word of letters (English, Português) stays on one line; Japanese breaks between any two characters
    for (const para of text.split('\n')) {
      let cur = '';
      for (const tok of para.match(/[\p{L}\p{N}'’.,!?;:\-]+(?<![\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}])\s*|\s+|./gu) || []) {
        const word = /^[\p{Script=Latin}\p{N}]/u.test(tok) && meas.measureText(tok.trimEnd()).width <= maxW ? [tok] : [...tok];
        for (const w of word) {
          if (meas.measureText((cur + w).trimEnd()).width > maxW && cur.trim()) { lines.push(cur.trimEnd()); cur = w.trimStart(); } else cur += w;
        }
      }
      if (cur.trim()) lines.push(cur.trimEnd());
    }
    const tw = Math.max(...lines.map((l) => meas.measureText(l).width));
    const bw = Math.ceil(tw + pad * 2), lh = fs * 1.3, bh = Math.ceil(lines.length * lh + pad * 1.6), tail = 34;
    const W = bw + 16, H = bh + tail + 16;
    const tex = canvasTex(W, H, (g) => {
      const x = 8, y = 8, r = 34;
      g.beginPath();
      g.moveTo(x + r, y); g.lineTo(x + bw - r, y); g.quadraticCurveTo(x + bw, y, x + bw, y + r);
      g.lineTo(x + bw, y + bh - r); g.quadraticCurveTo(x + bw, y + bh, x + bw - r, y + bh);
      g.lineTo(x + bw / 2 + 22, y + bh); g.lineTo(x + bw / 2, y + bh + tail); g.lineTo(x + bw / 2 - 22, y + bh);
      g.lineTo(x + r, y + bh); g.quadraticCurveTo(x, y + bh, x, y + bh - r);
      g.lineTo(x, y + r); g.quadraticCurveTo(x, y, x + r, y); g.closePath();
      g.fillStyle = '#fffdf6'; g.fill();
      g.lineWidth = 7; g.strokeStyle = color; g.lineJoin = 'round'; g.stroke();
      g.fillStyle = '#3b2e5a'; g.font = `bold ${fs}px ${this.font}`; g.textBaseline = 'middle'; g.textAlign = 'center';
      lines.forEach((l, i) => g.fillText(l, x + bw / 2, y + pad * 0.8 + lh * (i + 0.5)));
    });
    return { tex, W, H };
  }

  bubble(key, text, color, anchorFn) {
    this.removeBubble(key);
    // the one who speaks: its mark goes at once (no mark while it speaks)
    for (const m of this.items) if (m.userData.kind === 'mark' && m.userData.owner === key) m.userData.life = Math.min(m.userData.life, m.userData.age + 0.12);
    for (const b of Object.values(this.bubbles)) b.userData.life = Math.min(b.userData.life, b.userData.age + 0.6);
    const T = this.bubbleText(text, color), W = T.W, H = T.H; T.users++;
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: T.tex, depthTest: false, depthWrite: false, transparent: true }));
    sp.center.set(0.5, 0); sp.renderOrder = this._order('bubble');
    const k = 0.00048 * (this.scale || 1);
    sp.userData = { kind: 'bubble', anchorFn, w: W * k, h: H * k, age: 0, life: 2.4 + text.length * 0.09, text: T };
    sp.scale.set(0.001, 0.001, 1);
    this.root.add(sp); this.bubbles[key] = sp;
    this._place(sp);
  }
  removeBubble(key) {
    const b = this.bubbles[key]; if (!b) return;
    this.root.remove(b); letGo(b); delete this.bubbles[key];
  }
  clear() {
    Object.keys(this.bubbles).forEach((k) => this.removeBubble(k));
    Object.keys(this.gauges).forEach((k) => this.removeGauge(k));
    for (const s of this.items) { this.root.remove(s); letGo(s); }
    this.items = [];
  }
  // a word that would rise onto a gauge (power bar, timer ring) goes up beside it instead, so both can be read.
  // With several gauges in a row (みんなで: a ring over each one), it takes the free place nearest to where it was
  // (so it stays by the thing that was touched), not the side of one gauge and then of the next, and the next …
  _beside(d, up) {
    const boxes = Object.values(this.gauges).map((g) => {
      const gd = g.userData, base = (gd.kind === 'bar' ? 0.00062 : 0.00036) * (this.scale || 1);
      return { w: gd.W * base, h: gd.H * base, c: gd.anchorFn() };
    });
    if (!boxes.length) return;
    const hitsAt = (x) => boxes.some((b) => {
      const a = d.p0.clone().sub(b.c).dot(up) + 0.07;   // the word's bottom when it has risen, above the gauge's bottom
      return a < b.h && a + d.h > 0 && Math.abs(x - b.c.x) < (b.w + d.w) / 2;
    });
    if (!hitsAt(d.p0.x)) return;
    const lim = 0.5 - d.w / 2, cand = [];
    for (const b of boxes) for (const s of [-1, 1]) cand.push(b.c.x + s * ((b.w + d.w) / 2 + 0.01));
    const free = cand.filter((x) => Math.abs(x) <= lim && !hitsAt(x)).sort((a, b) => Math.abs(a - d.p0.x) - Math.abs(b - d.p0.x));
    if (free.length && Math.abs(free[0] - d.p0.x) < 0.25) { d.p0.x = free[0]; return; }
    // no free place near: it stays by the thing, and does not rise up onto the gauges
    d.noRise = true;
  }
  _place(sp, dt = 0) {
    const d = sp.userData;
    follow(d, d.anchorFn(), dt);
    const v = d.at.clone(), half = d.w / 2;
    v.x = Math.min(0.52 - half, Math.max(-0.52 + half, v.x));
    sp.position.copy(v);
  }
  update(dt, up) {
    this.items = this.items.filter((s) => {
      const d = s.userData; d.age += dt;
      const u = d.age / d.life;
      if (u >= 1) { this.root.remove(s); letGo(s); return false; }
      if (d.kind === 'stamp') {
        const k = easeOutBack(Math.min(1, d.age / 0.18)) * d.s;
        s.scale.set(k, k, 1); s.material.opacity = u > 0.45 ? 1 - (u - 0.45) / 0.55 : 1;
        return true;
      }
      if (d.kind === 'mark') {
        const k = easeOutBack(Math.min(1, d.age / 0.22)) * d.s, bob = Math.sin(d.age * 7) * 0.004;
        // always right above its own character: another character's speech bubble does not move it
        follow(d, d.anchorFn(), dt);
        s.position.copy(d.at).add(up.clone().multiplyScalar(bob));
        s.scale.set(k, k, 1); s.material.opacity = u > 0.75 ? 1 - (u - 0.75) / 0.25 : 1;
        return true;
      }
      if (!d.placed) { d.placed = true; this._beside(d, up); }
      const k = easeOutBack(Math.min(1, d.age / 0.25));
      s.scale.set(d.w * k, d.h * k, 1);
      const rise = d.noRise ? 0.012 : 0.07 * easeOutBack(Math.min(1, u * 1.4));
      s.position.set(d.p0.x + up.x * rise, d.p0.y + up.y * rise, d.p0.z + up.z * rise);
      s.material.opacity = u > 0.75 ? 1 - (u - 0.75) / 0.25 : 1;
      return true;
    });
    for (const g of Object.values(this.gauges)) {
      const d = g.userData; d.age += dt;
      const v = d.anchorFn(); g.position.copy(v);
      const base = (d.kind === 'bar' ? 0.00062 : 0.00036) * (this.scale || 1);
      const pop = easeOutBack(Math.min(1, d.age / 0.25));
      const vis = d.blink ? (Math.sin(d.age * 18) > -0.2 ? 1 : 0.35) : 1;
      g.scale.set(d.W * base * pop, d.H * base * pop, 1); g.material.opacity = vis;
    }
    for (const [key, b] of Object.entries(this.bubbles)) {
      const d = b.userData; d.age += dt;
      this._place(b, dt);
      const k = easeOutBack(Math.min(1, d.age / 0.28));
      b.scale.set(d.w * k, d.h * k, 1);
      const out = d.age - d.life;
      b.material.opacity = out > 0 ? Math.max(0, 1 - out / 0.3) : 1;
      if (out > 0.3) this.removeBubble(key);
    }
  }
}
