// The book currently loaded: title, characters, voices, colours, settings.
// Everything book-specific the engine needs comes from book.json through here.
export const BOOK = {
  title: '', subtitle: '', cast: [], byId: {},
  narrator: { pitch: 1.0, rate: 0.92 },
  settings: { readFirst: true, voiceOn: true },
};

// the readers' age (book.json "age": 3 / 5 / 7) → how easy the games are, unless a goal says otherwise
//   seconds: gather time · times: mash taps · hintAfter: seconds before a hint · stay: pop-up time
//   popTimes: pop / fall catches · growTimes: taps per grow stage · rub: finger movement to rub clean · strict: order starts again
//   copyRounds: how many to remember in each round of まねっこ · holdSeconds: how long to keep pressing (ながおし)
//   pairs: how many pairs of cards ペアさがし is played with (of the ones drawn)
export const AGE = {
  3: { seconds: 12, times: 12, hintAfter: 6, stay: 2.6, popTimes: 5, growTimes: 6, rub: 500, strict: false, copyRounds: [2, 2, 3], holdSeconds: 2, pairs: 3 },
  5: { seconds: 8, times: 18, hintAfter: 10, stay: 1.8, popTimes: 6, growTimes: 8, rub: 800, strict: false, copyRounds: [3, 3, 4, 4], holdSeconds: 2.5, pairs: 4 },
  7: { seconds: 6, times: 24, hintAfter: 15, stay: 1.3, popTimes: 8, growTimes: 10, rub: 1100, strict: true, copyRounds: [3, 3, 4, 5, 6], holdSeconds: 3, pairs: 5 },
};
export const age = () => AGE[BOOK.age] || AGE[5];
// ひかえめモード: fewer flashes and particles, slower and smaller moves (switched on the start screen)
export const CALM = { on: false };

export function setBook(b) {
  Object.assign(BOOK, b);
  BOOK.narrator = { pitch: 1.0, rate: 0.92, ...(b.narrator || {}) };
  BOOK.settings = { readFirst: true, voiceOn: true, ...(b.settings || {}) };
  BOOK.byId = {};
  for (const c of BOOK.cast || []) BOOK.byId[c.id] = c;
}

// voice for a speaker id ('n' or unknown = narrator)
export const voice = (id) => (BOOK.byId[id] && BOOK.byId[id].voice) || BOOK.narrator;
// speech-bubble / text colour
export const castColor = (id) => (BOOK.byId[id] && BOOK.byId[id].color) || '#7a5aa0';
// firework colour for a character
export const fireworkColor = (id) => (BOOK.byId[id] && (BOOK.byId[id].firework || BOOK.byId[id].color)) || '#ffd84a';
// colour of the character's dot in the progress bar
export const markColor = (id) => (BOOK.byId[id] && (BOOK.byId[id].mark || BOOK.byId[id].color)) || '#ffe36b';
// meow sound settings
export const meowOf = (id) => (BOOK.byId[id] && BOOK.byId[id].meow) || null;
export const isCast = (id) => !!BOOK.byId[id];
export const castIds = () => (BOOK.cast || []).map((c) => c.id);
