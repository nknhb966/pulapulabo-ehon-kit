// npm run lang  → makes / updates books/<id>/lang/<l>.json for the other languages in book.json "languages"
//   every text readers see or hear is a line "Japanese": "translation"; new texts get "" (write the translation there),
//   texts no longer in the book are taken out. Japanese stays the original (no file for it).
import fs from 'node:fs';
import path from 'node:path';
import { args, config, loadBook, exists, readJSON } from './lib/common.mjs';
import { bookTexts } from './lib/texts.mjs';

const A = args();
const B = loadBook(A.book || config().book);
const langs = (B.book.languages || []).filter((l) => l !== 'ja');
if (!langs.length) { console.log('\n  book.json の "languages" に ほかの言葉がありません（例: ["ja", "en", "pt"]）。\n'); process.exit(0); }
const texts = bookTexts(B);
fs.mkdirSync(path.join(B.dir, 'lang'), { recursive: true });
console.log('');
for (const l of langs) {
  const file = path.join(B.dir, 'lang', `${l}.json`);
  const old = exists(file) ? readJSON(file) : {};
  const next = {};
  for (const t of texts) next[t] = typeof old[t] === 'string' ? old[t] : '';
  const added = texts.filter((t) => !(t in old)).length, removed = Object.keys(old).filter((k) => !(k in next)).length;
  fs.writeFileSync(file, JSON.stringify(next, null, 2) + '\n');
  const empty = Object.values(next).filter((v) => !v).length;
  console.log(`  ✅ lang/${l}.json  ${texts.length} 文（新しく ${added}、消した ${removed}）${empty ? `  ← 訳のない文が ${empty} こ。"" に訳を書いてください` : ''}`);
}
console.log('');
