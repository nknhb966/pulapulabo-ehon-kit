// npm run put-png -- <folder or ZIP>   → puts pictures drawn in a drawing app (PNG) or a vector app (SVG) into the book (guide/09)
// npm run put-svg -- <folder or ZIP>   → the same tool (PNG and SVG are both taken by either name)
//   p1/cat.png      → books/<id>/pages/p1/layers/cat.png   (the old cat.svg is kept in books/<id>/old-pictures/)
//   p1/cat.svg      → books/<id>/pages/p1/layers/cat.svg   (the same, as SVG)
//   p1_cat.png      → the same (no page folder: "page_name")
//   cat.png         → the same, when only one page has "cat"
//   cover.png|svg   → books/<id>/cover.*      cast/cat.* → books/<id>/cast/    items/net.* → books/<id>/items/
// Pictures that are the same as now (not drawn over) are left as they are, so the whole folder from
// npm run png / svg can be given back. _下絵.png, _ガイド.* and other files starting with _ (except _background) are not used.
// When a character's picture is new, the faces the face tool made from its old picture (cat@blink …) are taken out
// when they cannot be made again (a PNG, or an SVG without class="eye" / "mouth"); draw cat@happy etc. to have them.
//
// npm run put-png -- <path> --book <id>   another book
// npm run put-png -- <path> --dry         only tells what would happen
import fs from 'node:fs';
import path from 'node:path';
import sharp from 'sharp';
import { Resvg } from '@resvg/resvg-js';
import { ROOT, args, config, loadBook, exists, mkdirp, FONT_FILES, FONT_FAMILY } from './lib/common.mjs';
import { listPictures, findPicture, findBackground, rasterize, BACKGROUND } from './lib/layers.mjs';
import { readZip, filesOf } from './lib/zip.mjs';
import { COVER_W, COVER_H } from './lib/cover.mjs';

const A = args();
const input = A._ && A._[0];
if (!input) {
  console.error('\n  使い方: npm run put-png -- 描いた絵のフォルダ（または ZIP）\n  （npm run png・npm run svg でできたフォルダと同じ形: p1/cat.png、p1/cat.svg、cover.png など。guide/09）\n');
  process.exit(1);
}
const B = loadBook(A.book || config().book);
const dry = !!A.dry;
const src = path.resolve(process.env.INIT_CWD || process.cwd(), String(input));
if (!exists(src)) { console.error(`\n  「${input}」が見つかりません。\n`); process.exit(1); }

// ---- what was given: [{ name: 'p1/cat.png', data }] ----
let given;
try {
  if (fs.statSync(src).isDirectory()) given = filesOf(src);
  else if (/\.zip$/i.test(src)) given = readZip(fs.readFileSync(src));
  else given = [{ name: path.basename(src), data: fs.readFileSync(src) }];
} catch (e) { console.error(`\n  ❌ ${e.message}\n`); process.exit(1); }

const pageIds = B.pages.map((p) => p.id);
const pageOf = Object.fromEntries(B.pages.map((p) => [p.id, p]));
const pieceIds = (p) => new Set((p.def.pieces || []).map((d) => d.id));
const baseOf = (n) => (n.includes('@') ? n.slice(0, n.indexOf('@')) : n);
const known = (p, n) => BACKGROUND.includes(n) || pieceIds(p).has(baseOf(n));
const resvgOpts = (w) => ({ fitTo: { mode: 'width', value: w }, font: { fontFiles: FONT_FILES, loadSystemFonts: false, defaultFontFamily: FONT_FAMILY }, background: 'rgba(0,0,0,0)' });
const MARK = 'pulapulabo-faces';
const hasFaceMarks = (svg) => /class\s*=\s*["'][^"']*\b(eye|mouth)\b/.test(svg);
const done = [], same = [], bad = [], notes = [];
const planned = {};   // "p1/cat" → { ext, data } (what the main picture will be)
let printed = false;

for (const g of given) {
  const parts = g.name.normalize('NFC').split('/').filter(Boolean);
  if (parts.some((s) => s.startsWith('.') || s === '__MACOSX')) continue;
  const file = parts[parts.length - 1].trim();
  const ext = path.extname(file).toLowerCase();
  if (ext !== '.png' && ext !== '.svg') {
    if (/^\.(jpe?g|psd|heic|webp|gif|tiff?|clip|procreate|ipv|mdp|kra|ai|eps|pdf|afdesign|fig)$/.test(ext)) bad.push(`${g.name}：PNG か SVG ではないので入れませんでした。PNG（お絵かきアプリ）か SVG（ベクターアプリ）で書き出してください`);
    continue;
  }
  let n = file.slice(0, -ext.length).trim();
  if (n.startsWith('_') && !BACKGROUND.includes(n)) continue;   // _下絵.png・_ガイド.png など
  const dirs = parts.slice(0, -1);

  // where it goes
  let kind = null, page = null;
  const pd = [...dirs].reverse().find((d) => pageIds.includes(d));
  if (pd) { kind = 'page'; page = pageOf[pd]; }
  else {
    const pre = pageIds.filter((id) => n.startsWith(`${id}_`) || n.startsWith(`${id}-`)).sort((a, b) => b.length - a.length)[0];
    if (pre && known(pageOf[pre], n.slice(pre.length + 1))) { kind = 'page'; page = pageOf[pre]; n = n.slice(pre.length + 1); }
    else if (dirs.includes('cast')) kind = 'cast';
    else if (dirs.includes('items')) kind = 'items';
    else if (n === 'cover') kind = 'cover';
    else {
      const on = B.pages.filter((p) => known(p, n) && !BACKGROUND.includes(n));
      if (on.length === 1) { kind = 'page'; page = on[0]; }
      else if (on.length > 1) { bad.push(`${g.name}：「${n}」は ${on.map((p) => p.id).join('・')} にあるので、どのページの絵か わかりません。p1/ のような フォルダに入れるか、p1_${n}${ext} のような名前にしてください`); continue; }
      else { bad.push(`${g.name}：「${n}」という絵は この絵本にありません。npm run png・svg でできたファイルと同じ名前（cat${ext} など）にしてください（アプリが付けた名前（作品名-1 など）のときは、名前を変えます）`); continue; }
    }
  }
  if (kind === 'page' && !known(page, n)) {
    bad.push(`${g.name}：${page.id} に「${baseOf(n)}」という絵はありません（page.json の pieces の id か、_background にします。アプリが付けた名前（作品名-1 など）のときは、cat${ext} のような id の名前に変えてください）`);
    continue;
  }
  const dir = kind === 'page' ? path.join(page.dir, 'layers') : kind === 'cover' ? B.dir : path.join(B.dir, kind);
  const where = kind === 'page' ? `${page.id}/${n}` : kind === 'cover' ? '表紙 cover' : `${kind}/${n}`;

  // is it a good picture? (its size, and the picture as 400 px wide pixels)
  let w, h, mine;
  try {
    if (ext === '.svg') {
      const text = g.data.toString('utf8');
      const linked = [...text.matchAll(/<image\b[^>]*?(?:xlink:)?href\s*=\s*["']([^"']+)["']/g)].map((m) => m[1]).filter((x) => !x.startsWith('data:'));
      if (linked.length) { bad.push(`${g.name}：外の画像ファイル（${linked[0]}）を読みこんでいます。画像は 埋め込みにするか、使わないでください`); continue; }
      const r = new Resvg(text, resvgOpts(400));
      w = r.width; h = r.height;
    } else ({ width: w, height: h } = await sharp(g.data).metadata());
  } catch { bad.push(`${g.name}：${ext === '.svg' ? 'SVG' : 'PNG'} として読めません`); continue; }
  if (kind === 'page' && Math.abs(w / h - 4 / 3) > 0.01) { bad.push(`${g.name}：縦横の比が 4:3 ではありません（${Math.round(w)}×${Math.round(h)}）。キャンバス（アートボード）の大きさのまま、切り抜かずに書き出してください。例: PNG 2400×1800、SVG 1600×1200`); continue; }
  if (kind === 'cover' && Math.abs(w / h - COVER_W / COVER_H) > 0.03) notes.push(`${where}：表紙の絵は 横:たて = 1600:936 です（いまは ${Math.round(w)}×${Math.round(h)}）。はみ出たところは 切られます`);
  const cw = 400, ch = Math.max(1, Math.round(cw * h / w));
  const png = ext === '.svg' ? new Resvg(g.data.toString('utf8'), resvgOpts(cw)).render().asPng() : g.data;
  mine = await sharp(png).resize(cw, ch, { fit: 'fill' }).ensureAlpha().raw().toBuffer();
  let clear = 0, solid = 0;
  for (let i = 3; i < mine.length; i += 4) { if (mine[i] < 8) clear++; else if (mine[i] > 200) solid++; }
  const px = cw * ch;
  if (solid < px * 0.0005) { bad.push(`${g.name}：何も描かれていません（ぜんぶ透明）`); continue; }
  if (kind === 'page' && !BACKGROUND.includes(n) && clear < px * 0.02) { bad.push(`${g.name}：まわりが透明になっていません。背景・用紙・下絵のレイヤーを かくして、透明のまま書き出してください`); continue; }

  // the same as now? (given back without drawing over it)
  const now = kind === 'page' && BACKGROUND.includes(n) ? findBackground(dir, page.def) : findPicture(dir, n);
  if (now) {
    // compared where either picture has something (a small change on a small character counts too)
    const old = await rasterize(now, cw, ch);
    let sum = 0, far = 0, area = 0;
    for (let i = 0; i < px; i++) {
      const o = i * 4, a1 = mine[o + 3], a2 = old[o + 3];
      if (a1 < 8 && a2 < 8) continue;
      area++;
      let dmax = Math.abs(a1 - a2);
      for (let c = 0; c < 3; c++) dmax = Math.max(dmax, Math.abs(mine[o + c] * a1 - old[o + c] * a2) / 255);
      sum += dmax; if (dmax > 40) far++;
    }
    if (!area || (sum / area < 2 && far <= area * 0.002)) { same.push(where); continue; }
  }

  // put it in (the old picture goes to books/<id>/old-pictures/)
  const isPrinted = kind === 'cover' || (kind === 'page' && (BACKGROUND.includes(n) || (!n.includes('@') && !(page.def.pieces || []).find((d) => d.id === n)?.hidden)));
  if (!dry) {
    mkdirp(dir);
    for (const e of ['.svg', '.png']) {
      const f = path.join(dir, n + e);
      if (!exists(f)) continue;
      const keep = path.join(B.dir, 'old-pictures', path.relative(B.dir, f));
      mkdirp(path.dirname(keep));
      fs.renameSync(f, keep);
    }
    fs.writeFileSync(path.join(dir, n + ext), g.data);
  }
  if (kind === 'page') planned[`${page.id}/${n}`] = { ext, data: g.data };
  done.push({ kind, page: page && page.id, n, ext, where });
  if (isPrinted) printed = true;
}

// faces made from an old picture: taken out when the new picture cannot make them again;
// faces drawn by hand for the old picture: told about
const madeGone = [];
for (const p of B.pages) {
  const L = path.join(p.dir, 'layers');
  const newMain = (base) => {
    const pl = planned[`${p.id}/${base}`];
    if (pl) return pl.ext === '.png' ? { png: true } : { png: false, marks: hasFaceMarks(pl.data.toString('utf8')) };
    return null;
  };
  for (const f of listPictures(L)) {
    if (!f.alt) continue;
    const nm = newMain(f.base);
    if (!nm) continue;                                                                // its character was not drawn anew
    if (planned[`${p.id}/${f.name}`]) continue;                                       // this face was given too
    const made = f.ext === '.svg' && fs.readFileSync(f.file, 'utf8').includes(MARK);
    if (made) {
      if (nm.png || !nm.marks) { if (!dry) fs.rmSync(f.file); madeGone.push(`${p.id}/${f.name}`); }
      // (an SVG with class="eye" / "mouth": the build makes this face again from the new picture)
    } else notes.push(`${p.id}/${f.fileName} は 前の ${f.base} に合わせて描いた絵のままです。見た目が合わないときは、${f.name} も描いてください`);
  }
}

const list = (arr) => {
  const by = {};
  for (const d of arr) { const k = d.kind === 'page' ? d.page : d.kind === 'cover' ? '表紙' : d.kind; (by[k] = by[k] || []).push(d.n + d.ext); }
  return Object.entries(by).map(([k, v]) => `       ${k}: ${v.join('・')}`).join('\n');
};
console.log(`\n🖼  「${B.book.title}」に、描いた絵を入れ${dry ? 'たら どうなるかを 見ま' : 'ま'}す（${path.relative(process.env.INIT_CWD || ROOT, src) || src}）`);
if (done.length) console.log(`\n  ✅ ${dry ? '入れかわる絵' : '入れかえた絵'}（${done.length} まい）\n${list(done)}`);
if (same.length) console.log(`\n  ・前と同じ絵なので、そのままにした絵（${same.length} まい）`);
if (madeGone.length) console.log(`\n  ・新しい絵に合わないので${dry ? ' 消す' : ' 消した'}表情の絵（表情ツールが前の絵から作ったもの）\n       ${madeGone.join('・')}\n       描くと使われます（${madeGone[0].split('/').pop()}.png など。SVG なら 目と口に class="eye"・"mouth" を付けると自動でできます）。描かないときは、まばたき・口パク・クリアしたときの笑顔が出ないだけです`);
for (const m of notes) console.log(`  ⚠️  ${m}`);
for (const m of bad) console.log(`  ❌ ${m}`);
if (!done.length && !bad.length) console.log('\n  入れかえる絵は ありませんでした（どれも前と同じ絵です）');
if (done.length && !dry) {
  console.log(`\n  前の絵は books/${B.id}/old-pictures/ に しまいました（もとに戻すときは、そこから layers/ などへ戻して、新しい絵を消します）`);
  console.log(`\n  次にすること: npm run check → npm run build${printed ? '\n  背景・飛び出す絵・表紙を描きかえたので、できたら 印刷し直してください（カメラは 印刷した絵で ページを見分けます）' : ''}`);
}
console.log('');
process.exit(bad.length && !done.length ? 1 : 0);
