import { spoken } from './read.js';
import { LANG, LANGS } from './lang.js';
import { meowOf, CALM, BOOK } from './book.js';
// かわいい声 (book.json settings "voice": "kid", the default): a woman's voice when there is one, a little higher
const kidVoice = () => (BOOK.settings.voice || 'kid') === 'kid';
const KID_PITCH = 1.3;
// Sound: synthesized effects (effect toggle) + speech synthesis for narration and voices (narration toggle).
export class Sound {
  constructor() {
    this.sfxOn = true; this.narrationOn = false; // narration starts off; the toggle turns it on
    this.ctx = null; this.voice = null;
    this._pickVoice();
    if (typeof speechSynthesis !== 'undefined') speechSynthesis.onvoiceschanged = () => this._pickVoice();
  }
  // called on every touch (core.js, before the page handles the touch): makes the sound and the voice ready,
  // and wakes the sound again. (The phone's usual sound output: no "audioSession" type is set — set to "playback",
  // an iPhone shows the page as music playing, also on a paired Apple Watch.)
  unlock() {
    this._primeVoice();
    try {
      if (!this.ctx) {
        const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
        this.ctx = new AC();
        this.master = this.ctx.createGain(); this.master.gain.value = 0.5; this.master.connect(this.ctx.destination);
        const b = this.ctx.createBuffer(1, 1, 22050), s = this.ctx.createBufferSource();
        s.buffer = b; s.connect(this.ctx.destination); s.start(0);
        this._noiseBuf = this.ctx.createBuffer(1, this.ctx.sampleRate * 2, this.ctx.sampleRate);
        const d = this._noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
        this.ctx.onstatechange = () => this._awake();
        // back from another app, a call or the lock screen: the sound may have been stopped ("suspended" / "interrupted")
        const again = () => { if (document.visibilityState !== 'hidden') this._wake(); };
        document.addEventListener('visibilitychange', again);
        window.addEventListener('pageshow', again);
        window.addEventListener('focus', again);
      }
      this._wake();
      if (this.ctx.state === 'running') this._flush();
    } catch (e) { /* no audio */ }
    this.syncAmbience();
  }
  // start the sound again whenever it is not playing (outside a touch some phones refuse; the next touch tries again)
  _wake() {
    const c = this.ctx; if (!c || c.state === 'running' || c.state === 'closed') return;
    try { const p = c.resume(); if (p && p.then) p.then(() => this._awake(), () => { /* waits for the next touch */ }); } catch (e) { /* no audio */ }
  }
  _awake() { if (this.ctx && this.ctx.state === 'running') this._flush(); this.syncAmbience(); }
  // effects asked for while the sound was getting ready (the very first touch, or waking up): played as soon as it runs
  _flush() {
    const q = this._queue || []; this._queue = [];
    const now = performance.now();
    q.forEach((j) => { if (now - j.t < 1200 && this.ok) { try { j.R.call(this, j.arg); } catch (e) { /* no audio */ } } });
  }
  get ok() { return this.sfxOn && this.ctx && this.ctx.state === 'running'; }

  // ---- building blocks ----
  tone({ type = 'sine', f0, f1, f2, t = 0, dur = 0.3, vol = 0.3, attack = 0.01, filter = null, vib = 0, trem = 0, dest = this.master }) {
    const c = this.ctx, now = c.currentTime + t;
    const o = c.createOscillator(); o.type = type;
    o.frequency.setValueAtTime(f0, now);
    if (f2) { o.frequency.exponentialRampToValueAtTime(f1, now + dur * 0.35); o.frequency.exponentialRampToValueAtTime(f2, now + dur * 0.95); }
    else if (f1) o.frequency.exponentialRampToValueAtTime(f1, now + dur * 0.9);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, now); g.gain.exponentialRampToValueAtTime(vol, now + attack); g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
    let node = o;
    if (filter) { const fl = c.createBiquadFilter(); fl.type = filter.type || 'lowpass'; fl.frequency.value = filter.f; fl.Q.value = filter.q || 1; node.connect(fl); node = fl; }
    if (vib) { const l = c.createOscillator(), lg = c.createGain(); l.frequency.value = 7; lg.gain.value = vib; l.connect(lg); lg.connect(o.frequency); l.start(now); l.stop(now + dur + 0.05); }
    let out = g;
    if (trem) { const tg = c.createGain(), l = c.createOscillator(), lg = c.createGain(); l.frequency.value = trem; lg.gain.value = 0.5; tg.gain.value = 0.5; l.connect(lg); lg.connect(tg.gain); l.start(now); l.stop(now + dur + 0.05); g.connect(tg); out = tg; }
    node.connect(g); out.connect(dest);
    o.start(now); o.stop(now + dur + 0.05);
  }
  noise({ t = 0, dur = 0.3, vol = 0.3, f0 = 1800, f1, type = 'lowpass', q = 1, attack = 0.02, dest = this.master }) {
    const c = this.ctx, now = c.currentTime + t;
    const s = c.createBufferSource(); s.buffer = this._noiseBuf;
    const fl = c.createBiquadFilter(); fl.type = type; fl.Q.value = q;
    fl.frequency.setValueAtTime(f0, now); if (f1) fl.frequency.exponentialRampToValueAtTime(f1, now + dur);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, now); g.gain.exponentialRampToValueAtTime(vol, now + attack); g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
    s.connect(fl); fl.connect(g); g.connect(dest);
    s.start(now, Math.random()); s.stop(now + dur + 0.05);
  }
  clicks(n, gap, f, { type = 'square', vol = 0.12, dur = 0.04, jitter = 0, t = 0 } = {}) {
    for (let i = 0; i < n; i++) this.tone({ type, f0: f * (1 + (Math.random() - 0.5) * jitter), t: t + i * gap, dur, vol });
  }

  // ---- 環境音: one quiet sound that goes on while a page is open (page.json "ambience") ----
  ambience(kind, owner) { this._amb = { kind, owner }; this.syncAmbience(); }
  stopAmbience(owner) { if (this._amb && this._amb.owner === owner) { this._amb = null; this.syncAmbience(); } }
  syncAmbience() {
    const want = this.ok && this._amb && AMBIENCE[this._amb.kind] ? this._amb.kind : null;
    if (this._ambNow && this._ambNow.kind === want) return;
    if (this._ambNow) {
      const a = this._ambNow; this._ambNow = null;
      clearInterval(a.timer); a.gain.gain.setTargetAtTime(0.0001, this.ctx.currentTime, 0.25);
      setTimeout(() => { a.nodes.forEach((n) => { try { n.stop(); } catch (e) { /* already stopped */ } }); a.gain.disconnect(); }, 1500);
    }
    if (!want) return;
    const c = this.ctx, gain = c.createGain(); gain.gain.value = 0.0001; gain.connect(this.master);
    const a = { kind: want, gain, nodes: [], timer: null, level: AMBIENCE[want].level };
    AMBIENCE[want].start.call(this, a);
    // quieter under the reading and the characters' lines, and in ひかえめモード
    const duck = () => {
      const v = a.level * (this.narrating || this._talking ? 0.35 : 1) * (CALM.on ? 0.6 : 1);
      gain.gain.setTargetAtTime(v, c.currentTime, 0.4);
      if (a.tick) a.tick();
    };
    duck(); a.timer = setInterval(duck, 250);
    this._ambNow = a;
  }
  // a looping noise through a filter (with an optional slow swell)
  _loopNoise(a, { type = 'lowpass', f = 800, q = 0.7, vol = 1, swell = 0, rate = 0.1, sweep = 0 }) {
    const c = this.ctx, s = c.createBufferSource(); s.buffer = this._noiseBuf; s.loop = true;
    const fl = c.createBiquadFilter(); fl.type = type; fl.frequency.value = f; fl.Q.value = q;
    const g = c.createGain(); g.gain.value = vol;
    s.connect(fl); fl.connect(g); g.connect(a.gain);
    s.start(0, Math.random()); a.nodes.push(s);
    if (swell || sweep) {
      const l = c.createOscillator(); l.frequency.value = rate;
      if (swell) { const lg = c.createGain(); lg.gain.value = vol * swell; l.connect(lg); lg.connect(g.gain); }
      if (sweep) { const lf = c.createGain(); lf.gain.value = sweep; l.connect(lf); lf.connect(fl.frequency); }
      l.start(); a.nodes.push(l);
    }
    return g;
  }

  // ---- effect bank ----
  sfx(name, arg) {
    if (!this.sfxOn) return;
    const R = this.R[name]; if (!R) return;
    if (this.ok) { R.call(this, arg); return; }
    // not ready yet: kept for a moment (a few at most) and played once the sound runs
    const q = this._queue = this._queue || [];
    q.push({ R, arg, t: performance.now() }); if (q.length > 6) q.shift();
    this._wake();
  }
  get R() {
    return this._R || (this._R = {
      twinkle() { const n = [1047, 1175, 1319, 1568, 1760, 2093]; const f = n[Math.floor(Math.random() * n.length)]; this.tone({ type: 'triangle', f0: f, dur: 0.6, vol: 0.18 }); this.tone({ f0: f * 2, t: 0.05, dur: 0.4, vol: 0.05 }); },
      meow(id) {
        const m = meowOf(id) || {}; const k = m.pitch || 1, len = m.length || 0.6;
        const c = this.ctx, now = c.currentTime;
        const o = c.createOscillator(); o.type = 'sawtooth';
        o.frequency.setValueAtTime(540 * k, now); o.frequency.exponentialRampToValueAtTime(840 * k, now + len * 0.25); o.frequency.exponentialRampToValueAtTime(460 * k, now + len);
        const fl = c.createBiquadFilter(); fl.type = 'bandpass'; fl.Q.value = 5;
        fl.frequency.setValueAtTime(900 * k, now); fl.frequency.exponentialRampToValueAtTime(2300 * k, now + len * 0.3); fl.frequency.exponentialRampToValueAtTime(1000 * k, now + len);
        const g = c.createGain(); g.gain.setValueAtTime(0.0001, now); g.gain.exponentialRampToValueAtTime(0.8, now + 0.05); g.gain.setValueAtTime(0.8, now + len * 0.65); g.gain.exponentialRampToValueAtTime(0.0001, now + len);
        o.connect(fl); fl.connect(g); g.connect(this.master); o.start(now); o.stop(now + len + 0.05);
      },
      boing() { this.tone({ type: 'triangle', f0: 240, f1: 640, dur: 0.18, vol: 0.35 }); this.tone({ type: 'triangle', f0: 640, f1: 300, t: 0.16, dur: 0.2, vol: 0.28 }); },
      pon() { this.tone({ f0: 320, f1: 980, dur: 0.16, vol: 0.4 }); },
      // a bell with its own pitch (まねっこ, なぞって つなぐ): note(0) … note(5)
      note(i = 0) { const n = [523, 587, 659, 784, 880, 1047]; const f = n[((i % 6) + 6) % 6]; this.tone({ type: 'triangle', f0: f, dur: 0.55, vol: 0.28 }); this.tone({ f0: f * 2, dur: 0.35, vol: 0.08 }); },
      pyoko() { this.tone({ type: 'triangle', f0: 380, f1: 1100, dur: 0.12, vol: 0.26 }); this.tone({ f0: 1400, t: 0.1, dur: 0.08, vol: 0.08 }); },
      kyu() { this.tone({ type: 'sawtooth', f0: 1700, f1: 2500, dur: 0.09, vol: 0.06, filter: { type: 'bandpass', f: 2400, q: 3 } }); },
      po() { this.tone({ f0: 500, f1: 900, dur: 0.12, vol: 0.25 }); },
      gara() { this.noise({ dur: 0.28, vol: 0.3, f0: 1500, type: 'bandpass', q: 2 }); this.clicks(5, 0.045, 700, { type: 'triangle', vol: 0.1, jitter: 0.4 }); },
      patan() { this.tone({ f0: 160, f1: 60, dur: 0.18, vol: 0.5 }); this.noise({ dur: 0.1, vol: 0.3, f0: 700 }); },
      chikutaku() { for (let i = 0; i < 6; i++) this.tone({ type: 'square', f0: i % 2 ? 1500 : 2000, t: i * 0.26, dur: 0.035, vol: 0.12, filter: { f: 3000 } }); },
      poppo() { this.tone({ f0: 720, f1: 690, dur: 0.28, vol: 0.4, attack: 0.03, filter: { f: 1400 } }); this.tone({ f0: 580, f1: 560, t: 0.34, dur: 0.38, vol: 0.4, attack: 0.03, filter: { f: 1400 } }); },
      fuwa() { this.noise({ dur: 0.7, vol: 0.22, f0: 900, f1: 300, attack: 0.15 }); },
      garagara() { for (let i = 0; i < 9; i++) this.tone({ type: 'triangle', f0: 300 + Math.random() * 500, t: i * 0.06 + Math.random() * 0.02, dur: 0.07, vol: 0.18 }); this.noise({ dur: 0.5, vol: 0.12, f0: 900 }); },
      korokoro() { for (let i = 0; i < 7; i++) this.tone({ f0: 1300 + (i % 2) * 300, t: i * 0.09, dur: 0.06, vol: 0.14 }); },
      chirin() { [2637, 3520, 5274].forEach((f, i) => this.tone({ f0: f, dur: 1.6 - i * 0.4, vol: 0.16 / (i + 1) })); this.tone({ f0: 2637, t: 0.35, dur: 1.2, vol: 0.08 }); },
      shushu() { for (let i = 0; i < 3; i++) this.noise({ t: i * 0.22, dur: 0.18, vol: 0.22, f0: 4200, type: 'bandpass', q: 0.8 }); },
      kasa() { for (let i = 0; i < 5; i++) this.noise({ t: i * 0.07 + Math.random() * 0.03, dur: 0.09, vol: 0.2, f0: 3200, type: 'bandpass', q: 1.2, attack: 0.005 }); },
      yusa() { this.noise({ dur: 0.8, vol: 0.2, f0: 1200, f1: 600, attack: 0.1 }); this.R.kasa.call(this); },
      poyon() { this.tone({ type: 'triangle', f0: 300, f1: 760, f2: 260, dur: 0.4, vol: 0.32 }); },
      kuru() { this.clicks(12, 0.045, 1700, { type: 'square', vol: 0.06, dur: 0.02 }); },
      kaa() { for (let i = 0; i < 2; i++) this.tone({ type: 'sawtooth', f0: 760, f1: 520, t: i * 0.42, dur: 0.32, vol: 0.32, filter: { type: 'bandpass', f: 1300, q: 4 } }); },
      pata() { for (let i = 0; i < 3; i++) this.noise({ t: i * 0.16, dur: 0.12, vol: 0.18, f0: 1300, type: 'bandpass', q: 1 }); },
      pichan() { this.tone({ f0: 1500, f1: 480, dur: 0.12, vol: 0.32 }); this.tone({ f0: 900, f1: 1400, t: 0.1, dur: 0.1, vol: 0.18 }); },
      nosso() { this.tone({ f0: 220, f1: 130, dur: 0.5, vol: 0.2, attack: 0.08 }); },
      gugu() { this.tone({ type: 'sawtooth', f0: 75, f1: 58, dur: 0.6, vol: 0.28, filter: { f: 320 } }); this.noise({ dur: 0.5, vol: 0.18, f0: 380 }); },
      sawa() { this.noise({ dur: 0.9, vol: 0.18, f0: 2600, type: 'bandpass', q: 0.7, attack: 0.2 }); },
      kero() { for (let i = 0; i < 2; i++) for (let j = 0; j < 3; j++) this.tone({ type: 'square', f0: 240, f1: 190, t: i * 0.32 + j * 0.035, dur: 0.05, vol: 0.12, filter: { type: 'bandpass', f: 900, q: 3 } }); },
      kirarin() { [1568, 2093, 2637, 3136, 4186].forEach((f, i) => this.tone({ f0: f, t: i * 0.06, dur: 0.7, vol: 0.14 })); },
      powa() { this.tone({ f0: 660, dur: 1.0, vol: 0.14, attack: 0.25 }); this.tone({ f0: 990, dur: 1.0, vol: 0.08, attack: 0.3 }); this.tone({ f0: 1320, t: 0.1, dur: 0.8, vol: 0.05, attack: 0.3 }); },
      riin() { for (let i = 0; i < 2; i++) this.tone({ f0: 4200, t: i * 0.5, dur: 0.38, vol: 0.08, trem: 32 }); },
      gata() { this.clicks(7, 0.05, 420, { type: 'triangle', vol: 0.2, jitter: 0.3, dur: 0.05 }); },
      konkon() { this.tone({ f0: 900, f1: 500, dur: 0.08, vol: 0.3, filter: { f: 1800 } }); this.tone({ f0: 900, f1: 500, t: 0.18, dur: 0.08, vol: 0.3, filter: { f: 1800 } }); },
      mogu() { for (let i = 0; i < 4; i++) this.noise({ t: i * 0.14, dur: 0.08, vol: 0.2, f0: 700, type: 'bandpass', q: 2 }); },
      shuwa() { this.noise({ dur: 0.9, vol: 0.12, f0: 6000, type: 'highpass' }); for (let i = 0; i < 14; i++) this.tone({ f0: 3000 + Math.random() * 3000, t: Math.random() * 0.8, dur: 0.02, vol: 0.05 }); },
      karan() { this.tone({ f0: 2400, dur: 0.8, vol: 0.18 }); this.tone({ f0: 3610, dur: 0.6, vol: 0.08 }); this.tone({ f0: 2400, t: 0.16, dur: 0.5, vol: 0.08 }); },
      moku() { this.noise({ dur: 1.0, vol: 0.2, f0: 500, f1: 250, attack: 0.25 }); },
      sui() { this.tone({ f0: 1800, f1: 2600, dur: 0.35, vol: 0.08, attack: 0.08 }); },
      zawa() { this.noise({ dur: 1.0, vol: 0.18, f0: 1800, type: 'bandpass', q: 0.6, attack: 0.25 }); },
      waiwai() { this.noise({ dur: 1.0, vol: 0.12, f0: 900, type: 'bandpass', q: 1.5, attack: 0.2 }); for (let i = 0; i < 8; i++) this.tone({ type: 'triangle', f0: 300 + Math.random() * 400, t: Math.random() * 0.8, dur: 0.12, vol: 0.05, vib: 20 }); },
      gottsun() { this.tone({ f0: 180, f1: 70, dur: 0.22, vol: 0.55 }); this.noise({ dur: 0.12, vol: 0.35, f0: 900 }); this.tone({ type: 'triangle', f0: 1200, f1: 1600, t: 0.15, dur: 0.3, vol: 0.12, vib: 40 }); },
      gorogoro() { this.tone({ type: 'sawtooth', f0: 70, f1: 50, dur: 1.4, vol: 0.3, filter: { f: 260 }, trem: 9 }); this.noise({ dur: 1.4, vol: 0.2, f0: 300, attack: 0.1 }); },
      doteh() { this.tone({ f0: 140, f1: 60, dur: 0.25, vol: 0.5 }); this.noise({ dur: 0.18, vol: 0.3, f0: 500 }); },
      chime() { [1047, 1319, 1568, 2093].forEach((f, i) => { this.tone({ f0: f, t: i * 0.09, dur: 1.2, vol: 0.2 }); this.tone({ f0: f * 2.01, t: i * 0.09, dur: 0.6, vol: 0.05 }); }); },
      hoot() { this.tone({ f0: 420, f1: 380, dur: 0.32, vol: 0.45, attack: 0.05, filter: { f: 900 }, vib: 6 }); this.tone({ f0: 380, f1: 340, t: 0.42, dur: 0.45, vol: 0.45, attack: 0.05, filter: { f: 900 }, vib: 6 }); },
      puff() { this.noise({ dur: 0.45, vol: 0.3, f0: 2400, f1: 300 }); },
      undo() { this.tone({ type: 'triangle', f0: 700, f1: 330, dur: 0.35, vol: 0.18 }); },
      gu() { this.tone({ f0: 120, f1: 70, dur: 0.14, vol: 0.45 }); this.noise({ dur: 0.08, vol: 0.2, f0: 600 }); },
      ready() { this.tone({ type: 'triangle', f0: 880, f1: 1320, dur: 0.18, vol: 0.18 }); },
      strain() { this.tone({ type: 'triangle', f0: 200, f1: 240, dur: 0.5, vol: 0.18, vib: 8 }); },
      door() { this.tone({ type: 'sawtooth', f0: 180, f1: 320, dur: 0.6, vol: 0.12, filter: { type: 'bandpass', f: 900, q: 6 } }); this.tone({ f0: 800, f1: 500, t: 0.62, dur: 0.1, vol: 0.25 }); },
      found() { [784, 1047, 1319, 1568].forEach((f, i) => this.tone({ type: 'square', f0: f, t: i * 0.08, dur: 0.22, vol: 0.07, filter: { f: 2500 } })); this.tone({ f0: 2093, t: 0.32, dur: 0.8, vol: 0.15 }); },
      fanfare() { [523, 659, 784, 1047, 784, 1047].forEach((f, i) => this.tone({ type: 'square', f0: f, t: i * 0.13, dur: 0.24, vol: 0.08, filter: { f: 2200 } })); [523, 659, 784, 1047].forEach((f) => this.tone({ type: 'triangle', f0: f, t: 0.8, dur: 1.6, vol: 0.1 })); },
      finale() {
        const seq = [523, 659, 784, 1047, 1319, 1568, 2093];
        seq.forEach((f, i) => this.tone({ type: 'square', f0: f, t: i * 0.11, dur: 0.3, vol: 0.07, filter: { f: 2600 } }));
        [523, 659, 784, 1047].forEach((f) => this.tone({ type: 'triangle', f0: f, t: 0.85, dur: 2.8, vol: 0.11, attack: 0.05 }));
        [1047, 1319, 1568, 2093].forEach((f) => this.tone({ f0: f, t: 0.85, dur: 2.2, vol: 0.05, attack: 0.1 }));
        for (let i = 0; i < 14; i++) this.tone({ f0: 1568 + Math.random() * 2000, t: 1.0 + i * 0.14, dur: 0.6, vol: 0.05 });
      },
      fwLaunch() { this.tone({ f0: 500, f1: 1900, dur: 0.8, vol: 0.06, attack: 0.05 }); this.noise({ dur: 0.7, vol: 0.05, f0: 3000, type: 'bandpass', q: 1 }); },
      fwBoom() { this.noise({ dur: 1.3, vol: 0.7, f0: 1400, f1: 120, attack: 0.005 }); this.tone({ f0: 90, f1: 38, dur: 0.6, vol: 0.6 }); },
      fwCrackle() { for (let i = 0; i < 26; i++) this.noise({ t: Math.random() * 0.9, dur: 0.03, vol: 0.12, f0: 5000, type: 'highpass', attack: 0.002 }); },
    });
  }

  // ---- speech ----
  // the voice for each language. "kid" (かわいい声, the default): a woman's voice when the device has one, spoken higher.
  // Otherwise: the higher-quality voices first.
  _pickVoice() {
    if (typeof speechSynthesis === 'undefined') return;
    const all = speechSynthesis.getVoices(), kid = kidVoice();
    const GOOD = /enhanced|premium|拡張|強化|高品質|natural|neural/i;
    const best = (re, female, male, names) => {
      const vs = all.filter((v) => re.test(v.lang));
      if (kid) {
        return vs.find((v) => female.test(v.name) && GOOD.test(v.name)) || vs.find((v) => female.test(v.name))
          || vs.find((v) => !male.test(v.name) && GOOD.test(v.name)) || vs.find((v) => !male.test(v.name)) || vs[0] || null;
      }
      return vs.find((v) => GOOD.test(v.name)) || vs.find((v) => names.test(v.name)) || vs[0] || null;
    };
    const jaF = /kyoko|o-ren|nanami|haruka|ayumi|sayaka|mizuki|google|female|女性/i, jaM = /otoya|hattori|ichiro|keita|daichi|naoki|male|男性/i;
    const enF = /samantha|karen|moira|tessa|fiona|victoria|allison|ava|susan|zira|aria|jenny|google us english|female/i, enM = /alex|daniel|fred|tom|aaron|david|mark|guy|ralph|\bmale/i;
    const ptF = /luciana|joana|francisca|maria|fernanda|google português|female|feminin/i, ptM = /felipe|antonio|daniel|\bmale|masculin/i;
    this.voices = {
      ja: best(/^ja/i, jaF, jaM, /kyoko|o-ren|otoya|hattori|google|nanami|haruka|ayumi|ichiro/i),
      en: best(/^en[-_]US/i, enF, enM, /samantha|google|aria|jenny|zira/i) || best(/^en/i, enF, enM, /google/i),
      pt: best(/^pt[-_]BR/i, ptF, ptM, /luciana|google|francisca|maria/i) || best(/^pt/i, ptF, ptM, /google/i),
    };
    this.voice = this.voices.ja;
  }
  get canSpeak() { return typeof speechSynthesis !== 'undefined' && typeof SpeechSynthesisUtterance !== 'undefined'; }
  // iPhone / iPad: the voice speaks only after it has once been started by a touch. セリフ is on from the start, so
  // the first reading (when a page or the cover is found) comes from a timer, not a touch, and would stay silent.
  // So each touch, until the voice has worked once, starts a silent, empty utterance.
  _primeVoice() {
    if (this._voiceOK || !this.canSpeak) return;
    try {
      const u = new SpeechSynthesisUtterance(' ');
      u.volume = 0;
      u.onstart = u.onend = () => { this._voiceOK = true; };
      this._primeU = u;   // (kept, so its events come)
      speechSynthesis.speak(u);
    } catch (e) { /* no voice */ }
  }
  stopSpeech() {
    this._run = (this._run || 0) + 1;   // ends a page reading that is going on
    if (this.canSpeak) speechSynthesis.cancel();
    this.narrating = false; this._talking = false; this._dropLines(); clearTimeout(this._safety);
  }
  // the line being said and the one waiting: over (job.done)
  _dropLines() {
    if (this._job) this._job.done = true;
    if (this._pending) this._pending.done = true;
    this._job = this._pending = null;
  }
  _utt(text, { pitch = 1, rate = 0.95 } = {}) {
    const u = new SpeechSynthesisUtterance(spoken(text));
    // かわいい声: everyone a little higher (the differences between the characters stay)
    u.lang = LANGS[LANG.voice].speech; u.pitch = Math.min(2, pitch * (kidVoice() ? KID_PITCH : 1)); u.rate = rate;
    const v = this.voices && this.voices[LANG.voice]; if (v) u.voice = v;
    return u;
  }
  // character lines: only with セリフ on, never on top of the page reading, and never cut off.
  // If a character is still talking, the newest line waits and plays right after (older waiting lines are dropped).
  // a line (セリフ) by voice; returns its job, whose "done" tells when it has been said (or will not be said)
  say(text, opts) {
    if (!this.narrationOn || !this.canSpeak || this.narrating) return null;
    const job = { text, opts, t: Date.now(), done: false };
    if (this._talking) { if (this._pending) this._pending.done = true; this._pending = job; return job; }
    this._line(job);
    return job;
  }
  _line(job) {
    this._talking = true; this._job = job;
    const u = this._utt(job.text, job.opts);
    let finished = false;
    const done = () => {
      if (finished) return; finished = true;
      clearTimeout(this._safety); this._talking = false; job.done = true; if (this._job === job) this._job = null;
      const next = this._pending; this._pending = null;
      // a line that waited too long no longer matches what is on screen
      if (next && Date.now() - next.t < 2500 && this.narrationOn && !this.narrating) this._line(next);
      else if (next) next.done = true;
    };
    u.onend = done; u.onerror = done; u.onstart = () => { this._voiceOK = true; };
    this._safety = setTimeout(done, 1800 + spoken(job.text).length * 260); // some browsers never fire onend
    speechSynthesis.speak(u);
  }
  // page reading: one utterance per printed line, read as whole sentences.
  // The lines are spoken one after another (not queued all at once): some phones never tell when a queued line starts,
  // so the line's onstart (the reading highlight) is called here, as each line is handed to the voice.
  narrate(segs, onend) {
    if (!this.canSpeak || !segs.length) { onend && onend(); return false; }
    speechSynthesis.cancel(); clearTimeout(this._safety); this._talking = false; this._dropLines();
    this.narrating = true;
    const run = this._run = (this._run || 0) + 1;   // a newer reading, or stopSpeech, ends this one
    const next = (i) => {
      if (run !== this._run) return;
      if (i >= segs.length) { clearTimeout(this._safety); this.narrating = false; onend && onend(); return; }
      const sg = segs[i], u = this._utt(sg.text, sg.voice);
      let finished = false;
      const fin = () => { if (finished) return; finished = true; clearTimeout(this._safety); setTimeout(() => next(i + 1), 150); };
      u.onend = fin; u.onerror = fin; u.onstart = () => { this._voiceOK = true; };
      this._u = u;   // keep it: some browsers drop the events of an utterance nothing points to
      if (sg.onstart) sg.onstart();
      this._safety = setTimeout(fin, 3000 + spoken(sg.text).length * 300 / (u.rate || 1));   // some browsers never fire onend
      speechSynthesis.speak(u);
    };
    next(0);
    return true;
  }
}

// 環境音 (page.json "ambience"). level: how loud at most (the effects are about 0.1–0.3)
const chance = (p) => Math.random() < p;
export const AMBIENCE = {
  waves: { level: 0.16, start(a) { this._loopNoise(a, { f: 520, vol: 0.6, swell: 0.9, rate: 0.11, sweep: 260 }); } },   // なみ
  wind: { level: 0.12, start(a) { this._loopNoise(a, { type: 'bandpass', f: 600, q: 1.4, vol: 0.7, swell: 0.6, rate: 0.07, sweep: 380 }); } }, // かぜ
  rain: { level: 0.1, start(a) { this._loopNoise(a, { type: 'highpass', f: 1400, vol: 0.6 }); this._loopNoise(a, { f: 380, vol: 0.4 }); } }, // あめ
  stream: {                                                                                                         // おがわ
    level: 0.1,
    start(a) { const g = this._loopNoise(a, { type: 'bandpass', f: 1700, q: 0.9, vol: 0.7 }); a.tick = () => g.gain.setTargetAtTime(0.45 + Math.random() * 0.45, this.ctx.currentTime, 0.05); },
  },
  insects: {                                                                                                        // むしの こえ（リーン リーン）
    level: 0.22,
    start(a) { a.tick = () => { if (chance(0.3)) [0, 0.22].forEach((t) => this.tone({ f0: 4300 + Math.random() * 300, t, dur: 0.18, vol: 0.05, trem: 38, dest: a.gain })); }; },
  },
  birds: {                                                                                                          // ことり（チュンチュン）
    level: 0.22,
    start(a) {
      a.tick = () => {
        if (!chance(0.12)) return;
        const f = 2400 + Math.random() * 900, n = 2 + Math.floor(Math.random() * 3);
        for (let k = 0; k < n; k++) this.tone({ type: 'sine', f0: f, f1: f * 1.45, t: k * 0.13, dur: 0.09, vol: 0.05, dest: a.gain });
      };
    },
  },
  fire: {                                                                                                           // たきび（パチパチ）
    level: 0.14,
    start(a) {
      this._loopNoise(a, { f: 300, vol: 0.5, swell: 0.3, rate: 0.3 });
      a.tick = () => { for (let k = 0; k < 3; k++) if (chance(0.25)) this.noise({ t: Math.random() * 0.25, dur: 0.03, vol: 0.12, f0: 2600, type: 'highpass', attack: 0.002, dest: a.gain }); };
    },
  },
};
