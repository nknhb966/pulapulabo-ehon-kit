// One pop-up page: flat paper + cards that stand up, plus animation helpers used by the page scripts.
import * as THREE from 'three';
import { Particles, Labels, easeOutBack, easeInOut, MARK_NAMES } from './fx.js';
import { voice, castColor, fireworkColor, castIds, CALM, BOOK } from './book.js';
import { weatherTick, darken, IDLE, MOODS, light, walk, reveal, lastingTick } from './scene.js';
import { shown, getItem } from './story.js';
import { addHalo, blinkHalo } from './glow.js';
import { drawTextBox, textBoxMesh } from './textbox.js';
import { LANG } from './lang.js';
import { handOf } from './tool.js';

const S = 1 / 1600, PH = 0.75;
const px2x = (px) => px * S - 0.5;
const py2y = (py) => PH / 2 - py * S;


export function cardMaterial(map) {
  const m = new THREE.MeshBasicMaterial({ map, side: THREE.DoubleSide, alphaTest: 0.5, transparent: false });
  m.alphaToCoverage = true;
  m.onBeforeCompile = (sh) => {
    sh.fragmentShader = sh.fragmentShader.replace('#include <map_fragment>',
      '#include <map_fragment>\nif (!gl_FrontFacing) { diffuseColor.rgb = vec3(0.95, 0.90, 0.80); }');
  };
  return m;
}
function shadowMaterial(map) {
  return new THREE.ShaderMaterial({
    uniforms: { map: { value: map }, opacity: { value: 0 } },
    vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
    fragmentShader: 'uniform sampler2D map; uniform float opacity; varying vec2 vUv; void main(){ float a = texture2D(map, vUv).a; gl_FragColor = vec4(0.03,0.03,0.12, a * opacity); }',
    transparent: true, depthWrite: false,
  });
}

let MEAS = null;   // a canvas to measure words with

const TALK_MAX = 15;   // seconds: the longest a line keeps its piece from being touched again

export class PageView {
  constructor({ n, manifest, tex, alpha, plateImg, maskImg, font, sound, ui, logic }) {
    this.n = n; this.tex = tex; this.alpha = alpha; this.sound = sound; this.ui = ui; this.logic = logic;
    this.story = manifest.story;
    this.lines = manifest.lines || []; // where each printed line of the story is (page pixels), for the reading highlight
    this.manifest = manifest; this.font = font;
    this.root = new THREE.Group();
    this.cards = {}; this.tweens = []; this.timers = [];
    this.open = false; this.playing = false; this.viewTheta = 0.9; this.time = 0; this.mode = 'cover';
    this.busyUntil = {};
    this.state = {};
    this._extras = []; // things added for a while (a rainbow…), taken away on reset
    this.up = new THREE.Vector3(0, Math.cos(0.9), Math.sin(0.9));

    // paper
    const plateTex = new THREE.Texture(plateImg); plateTex.colorSpace = THREE.SRGBColorSpace; plateTex.needsUpdate = true;
    this.plate = new THREE.Mesh(new THREE.PlaneGeometry(1, PH), new THREE.MeshBasicMaterial({ map: plateTex }));
    this.plate.name = 'plate'; this.root.add(this.plate);
    this.margin = new THREE.Mesh(new THREE.PlaneGeometry(1.07, PH + 0.07), new THREE.MeshBasicMaterial({ color: 0xf8f4ea }));
    this.margin.position.z = -0.0006; this.root.add(this.margin);
    // patch = plate only where the printed pieces were (built from the plate + a small mask)
    this.plateImg = plateImg; this.maskImg = maskImg;
    const patchTex = new THREE.CanvasTexture(this._patchCanvas(plateImg)); patchTex.colorSpace = THREE.SRGBColorSpace;
    this.patch = new THREE.Mesh(new THREE.PlaneGeometry(1, PH), new THREE.MeshBasicMaterial({ map: patchTex, transparent: true, depthWrite: false }));
    this.patch.position.z = 0.0003; this.patch.visible = false; this.root.add(this.patch);
    this.guide = this._guide(); this.root.add(this.guide);

    // cards
    const P = manifest.pieces;
    const ids = Object.keys(P);
    ids.forEach((cid, idx) => {
      const m = P[cid];
      const w = m.w * S, h = m.h * S;
      const geo = new THREE.PlaneGeometry(w, h);
      let pvx = m.x + m.w / 2, pvy = m.y + m.h;
      if (m.pivot === 'top') { geo.translate(0, -h / 2, 0); pvy = m.y; }
      else if (m.pivot === 'left') { geo.translate(w / 2, h / 2, 0); pvx = m.x; }
      else if (m.pivot === 'right') { geo.translate(-w / 2, h / 2, 0); pvx = m.x + m.w; }   // (ドアの ちょうつがいが 右)
      else geo.translate(0, h / 2, 0);
      const mesh = new THREE.Mesh(geo, cardMaterial(tex[m.tex[0]]));
      mesh.name = cid; mesh.userData.tex = m.tex[0];
      const body = new THREE.Group(); body.add(mesh);
      const still = new THREE.Group(); still.add(body);   // "idle" (ふわふわ・すやすや) moves this one, so it never fights the touch moves
      const pivot = new THREE.Group(); pivot.add(still);
      const card = { id: cid, m, w, h, mesh, body, still, pivot, pvx, pvy, theta: 0, vel: 0, delay: 0, fold: 1, hidden: m.hidden, flat: m.flat, order: idx, phase: idx * 1.7, flipX: 1 };
      if (m.hidden) body.visible = false;
      this.cards[cid] = card;
    });
    // 奥行き: a piece stands where its bottom is drawn (up to 5 rows, with small steps inside a row).
    // Pieces drawn on the same line (within 6 px) that overlap side to side stand a few px apart,
    // in "pieces" order (the later one in front), so they never stand in the very same place.
    const standing = ids.map((i) => this.cards[i]).filter((c) => !c.m.parent && !c.m.flat && (c.m.pivot || 'bottom') === 'bottom');
    standing.forEach((b, i) => {
      for (const a of standing.slice(0, i)) {
        if (Math.abs(a.pvy + (a.nudge || 0) * 4 - b.pvy) > 6) continue;
        if (a.m.x + a.m.w <= b.m.x || b.m.x + b.m.w <= a.m.x) continue;
        b.nudge = Math.max(b.nudge || 0, (a.nudge || 0) + 1);
      }
    });
    for (const cid of ids) {
      const cd = this.cards[cid], m = cd.m;
      if (m.parent) {
        // pieces on one piece (つみき・かべの 時計や ドア …) are each a little apart, in "pieces" order (the later one in front),
        // so where they overlap — also after a move (くずれる・ひらく) — they never flicker; "behind" ones go back the same way
        const p = this.cards[m.parent];
        // "depth": stands that many px behind it (戸口・まどの むこうの 外の けしき)
        const sib = ids.filter((i) => this.cards[i].m.parent === m.parent && !!this.cards[i].m.behind === !!m.behind && !this.cards[i].m.depth);
        const k = sib.indexOf(cid), step = 0.0006;
        cd.pivot.position.set((cd.pvx - p.pvx) * S, (p.pvy - cd.pvy) * S, m.depth ? -m.depth * S : m.behind ? -0.0015 - (sib.length - 1 - k) * step : 0.0015 + k * step);
        p.body.add(cd.pivot);
      } else {
        cd.pivot.position.set(px2x(cd.pvx), py2y(cd.pvy + (cd.nudge || 0) * 4), 0.0015 + cd.order * 0.0005);
        this.root.add(cd.pivot);
        if (!m.flat) {
          const sh = new THREE.Mesh(cd.mesh.geometry, shadowMaterial(cd.mesh.material.map));
          sh.position.copy(cd.pivot.position); sh.position.z = 0.0008; sh.renderOrder = 1;
          cd.shadow = sh; this.root.add(sh);
        }
      }
    }
    for (const cid of ids) this.cards[cid].pivotHome = this.cards[cid].pivot.position.clone();
    this.topCards = ids.map((i) => this.cards[i]).filter((c) => !c.m.parent);
    // pieces with their own life: idle moves, blinking (<id>@blink), talking (<id>@talk)
    this.idleCards = ids.map((i) => this.cards[i]).filter((c) => IDLE[c.m.idle]);
    this.blinkCards = ids.map((i) => this.cards[i]).filter((c) => tex[`${c.id}@blink`]);
    this.blinkCards.forEach((c) => { c.blinkT = 1 + Math.random() * 3; });
    // "glow": true — a soft light behind the piece that keeps blinking (ほたる・星・ランプ)
    this.glowCards = ids.map((i) => this.cards[i]).filter((c) => c.m.glow);
    this.glowCards.forEach((c) => { addHalo(this, c.id, Math.max(0.08, Math.min(0.2, c.w * 1.4))); c.glowing = true; c.glowFlash = -9; });
    this.pickables = [this.plate, ...ids.map((i) => this.cards[i].mesh)];

    // invisible sky behind the page (for "skyFireworks"); stands at the back edge
    if (logic.sky) {
      const geo = new THREE.PlaneGeometry(1.6, 0.9); geo.translate(0, 0.45, 0);
      const sky = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ visible: false, side: THREE.DoubleSide }));
      sky.name = 'sky';
      const sp = new THREE.Group(); sp.position.set(0, PH / 2, 0.001); sp.add(sky);
      this.root.add(sp); this.skyPivot = sp; this.pickables.push(sky);
    }

    this.fx = new Particles(logic.maxParticles || 1500); this.root.add(this.fx.points);
    this.labels = new Labels(this.root, font);
    // ambient twinkles
    this.twinkleT = 0;
    if (logic.dark) darken(this, logic.dark, 0);
    logic.init && logic.init(this);
  }

  _guide() {
    const gr = new THREE.Group();
    const pts = [[-0.5, -PH / 2], [0.5, -PH / 2], [0.5, PH / 2], [-0.5, PH / 2]].map(([x, y]) => new THREE.Vector3(x, y, 0.0005));
    const loop = new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineDashedMaterial({ color: 0xfff3d9, dashSize: 0.018, gapSize: 0.012, transparent: true, opacity: 0.55 }));
    loop.computeLineDistances(); gr.add(loop);
    const cm = new THREE.MeshBasicMaterial({ color: 0xfff3d9, transparent: true, opacity: 0.9, depthWrite: false });
    const L = 0.06, T = 0.007;
    for (const [sx, sy] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) {
      const a = new THREE.Mesh(new THREE.PlaneGeometry(L, T), cm); a.position.set(sx * (0.5 - L / 2), sy * (PH / 2), 0.0006);
      const b = new THREE.Mesh(new THREE.PlaneGeometry(T, L), cm); b.position.set(sx * 0.5, sy * (PH / 2 - L / 2), 0.0006);
      gr.add(a, b);
    }
    gr.visible = false; return gr;
  }

  // ---------- modes / open state ----------
  setMode(mode) {
    this.mode = mode;
    const cover = mode === 'cover';
    this.plate.material.colorWrite = cover; this.margin.material.colorWrite = cover;
    this.patch.visible = !cover; this.guide.visible = mode === 'arOnly';
  }
  setOpen(open, instant = false) {
    this.open = open;
    this.topCards.forEach((c, i) => {
      c.delay = open ? 0.12 + (this.topCards.length - i) * 0.035 : 0;
      if (instant && !open) { c.theta = 0; c.vel = 0; c.pivot.rotation.x = 0; }
    });
    if (!open) { this.labels.clear(); }
    if (this.logic.ambience) { if (open) this.sound.ambience(this.logic.ambience, this); else this.sound.stopAmbience(this); }
    if (open && this.logic.opening) this.logic.opening(this);   // (right away: what is not there now is never seen)
    if (open && this.logic.open) this.later(900, () => this.logic.open(this));
  }
  setViewDir(camLocal) {
    const thetaCam = Math.atan2(-camLocal.y, camLocal.z);
    let t = thetaCam + 0.35 * (Math.PI / 2 - thetaCam);
    t = Math.min(1.45, Math.max(0.45, t));
    this.viewTheta += (t - this.viewTheta) * 0.06;
  }
  measure(camera, viewportW, viewportH) {
    this.camera = camera;
    const a = new THREE.Vector3(-0.5, 0, 0), b = new THREE.Vector3(0.5, 0, 0);
    this.root.localToWorld(a); this.root.localToWorld(b); a.project(camera); b.project(camera);
    const px = Math.abs(b.x - a.x) / 2 * viewportW;
    if (px > 10) this.labels.scale = Math.min(1.9, Math.max(0.9, 560 / px));
    this.fx.setPixelScale(viewportH * Math.min(2, window.devicePixelRatio || 1));
  }
  _patchCanvas(img) {
    const c = document.createElement('canvas'); c.width = 1600; c.height = 1200;
    const g = c.getContext('2d', { willReadFrequently: true });
    g.drawImage(img, 0, 0, 1600, 1200);
    const id = g.getImageData(0, 0, 1600, 1200);
    if (!this._maskData) {
      const m2 = document.createElement('canvas'); m2.width = 800; m2.height = 600;
      const mg = m2.getContext('2d', { willReadFrequently: true }); mg.drawImage(this.maskImg, 0, 0, 800, 600);
      this._maskData = mg.getImageData(0, 0, 800, 600).data;
    }
    const md = this._maskData;
    for (let y = 0; y < 1200; y++) for (let x = 0; x < 1600; x++) id.data[(y * 1600 + x) * 4 + 3] = md[((y >> 1) * 800 + (x >> 1)) * 4];
    g.putImageData(id, 0, 0);
    return c;
  }
  // ぬりえ: the paper with the coloured background (null: the printed one again)
  setPlate(img) {
    const t = this.plate.material.map, want = img || this.plateImg;
    if (t.image === want) return;
    t.image = want; t.needsUpdate = true;
    const p = this.patch.material.map; p.image = this._patchCanvas(want); p.needsUpdate = true;
  }
  // put piece `id` somewhere else for a while: on piece `parentId` ("behind" it or in front), or standing on its own
  // (parentId null), with its bottom at page pixels `at` = [x, y]. reset() puts it back where it is drawn.
  // (かくれんぼ: hiding at another place each time; a found one that comes out and stands in front)
  placePiece(id, parentId, at, { behind = false } = {}) {
    const c = this.cards[id]; if (!c) return null;
    if (!c.home) c.home = { m: c.m, pvx: c.pvx, pvy: c.pvy };
    const wasParent = c.m.parent ? this.cards[c.m.parent] : null;
    const [x, y] = at || [c.pvx, c.pvy];
    if (c.pivot.parent) c.pivot.parent.remove(c.pivot);
    this.topCards = this.topCards.filter((t) => t !== c);
    c.m = { ...c.home.m, parent: parentId || null, behind: !!(parentId && behind) };
    c.pvx = x; c.pvy = y;
    if (parentId) {
      const p = this.cards[parentId];
      c.pivot.position.set((x - p.pvx) * S, (p.pvy - y) * S, behind ? -0.0015 : 0.004);
      c.pivot.rotation.x = 0;
      p.body.add(c.pivot);
      if (c.shadow) c.shadow.visible = false;
    } else {
      c.pivot.position.set(px2x(x), py2y(y), 0.0015 + c.order * 0.0005);
      if (wasParent) { c.theta = wasParent.theta; c.vel = 0; }
      c.fold = 1; c.delay = 0; c.pivot.rotation.x = c.theta;
      this.root.add(c.pivot); this.topCards.push(c);
      if (!c.shadow && !c.m.flat) {
        const sh = new THREE.Mesh(c.mesh.geometry, shadowMaterial(c.mesh.material.map));
        sh.position.copy(c.pivot.position); sh.position.z = 0.0008; sh.renderOrder = 1;
        c.shadow = sh; this.root.add(sh);
      }
      if (c.shadow) c.shadow.visible = true;
    }
    return c;
  }
  // a piece moved by placePiece goes back to where it is drawn
  _placeBack(c) {
    if (!c.home) return;
    if (c.pivot.parent) c.pivot.parent.remove(c.pivot);
    this.topCards = this.topCards.filter((t) => t !== c);
    c.m = c.home.m; c.pvx = c.home.pvx; c.pvy = c.home.pvy; c.home = null; c.stillNow = false;
    if (c.m.parent) { this.cards[c.m.parent].body.add(c.pivot); c.pivot.rotation.x = 0; if (c.shadow) c.shadow.visible = false; }
    else { this.root.add(c.pivot); this.topCards.push(c); if (c.shadow) c.shadow.visible = true; }
  }
  reset() {
    this.timers.forEach(clearTimeout); this.timers = [];
    this.tweens = []; this.resets = (this.resets || 0) + 1; this.labels.clear(); this.fx.clear();
    for (const c of Object.values(this.cards)) this._placeBack(c);
    for (const c of Object.values(this.cards)) {
      c.body.position.set(0, 0, 0); c.body.rotation.set(0, 0, 0); c.body.scale.set(1, 1, 1);
      c.body.userData.base = null; // moved pieces (moveTo / slide) start again from their own place
      c.body.visible = !c.m.hidden; c.fold = 1;
      c.pivot.position.copy(c.pivotHome); c.still.position.set(0, 0, 0); c.still.rotation.set(0, 0, 0); c.still.scale.set(1, 1, 1); c.flipX = 1;
      c.talkUntil = 0; c.lit = false; if (c.lamp) c.lamp.material.opacity = 0;
      this.swap(c.id, c.m.tex[0]);
    }
    this._extras.forEach((o) => this.root.remove(o)); this._extras = []; this._lasting = null; this._rainbow = null;
    this._talk = {}; this._voice = {};
    if (this._hl) this._hl.material.opacity = 0;
    if (this._dark || this.logic.dark) darken(this, this.logic.dark || 0, 0);
    this.state = {}; this.busyUntil = {}; this.playing = false;
    this.done = false; this.ui && this.ui.setDone(this.n, false);
    this.logic.init && this.logic.init(this);
  }
  complete() { const was = this.done; this.done = true; this.ui && this.ui.setDone(this.n, true); if (!was && this.onComplete) this.onComplete(this.n); }
  // story time (false) / play time (true)
  setPlaying(on) { const was = this.playing; this.playing = on; if (on && !was) this.logic.play && this.logic.play(this); }
  // the "let's play!" cue when story time ends
  playSignal() {
    const p = new THREE.Vector3(0, 0.05, 0.02).add(this.up.clone().multiplyScalar(0.12));
    this.labels.ono(shown('あそぼう！'), p, '#5fc46a', 1.3);
    for (let i = 0; i < 5; i++) this.later(i * 120, () => this.fx.burst(new THREE.Vector3(-0.35 + i * 0.175, 0.0, 0.03), 12, 1.0, ['#fff2a8', '#ffffff', '#b8f0a0']));
    this.sfx('kirarin');
  }

  // ---------- helpers for page scripts ----------
  C(id) { return this.cards[id]; }
  // "can't be touched for a while": pg.busy('clock', 3) … if (pg.isBusy('clock')) return;
  // (any name works; touch reactions in page.json use the names "touch:<id>" or "touch:<lock>")
  busy(key, seconds) { this.busyUntil[key] = Math.max(this.busyUntil[key] || 0, this.time + seconds); }
  isBusy(key) { return (this.busyUntil[key] || 0) > this.time; }
  // (what happens later belongs to the touch that started it: its words and bubbles stay in that touch's layer)
  later(ms, fn) { const layer = this.labels ? this.labels.layer : 0; const t = setTimeout(() => (this.labels ? this.labels.inLayer(layer, fn) : fn()), ms); this.timers.push(t); return t; }
  tween(dur, fn, done) { this.tweens.push({ t: 0, dur, fn, done }); }
  swap(id, texName) {
    const c = this.cards[id]; if (!c || !this.tex[texName]) return;
    c.mesh.userData.tex = texName; c.blinking = 0; this._face(c, texName);
    // what a piece holds (a child piece) changes with it: when いちろう becomes ichiro@banzai, his kingyo_bag becomes
    // kingyo_bag@banzai if there is one (and goes back with him)
    const look = texName.includes('@') ? texName.slice(texName.indexOf('@') + 1) : '';
    for (const k of Object.values(this.cards)) {
      if (k.m.parent !== id) continue;
      if (look && this.tex[`${k.id}@${look}`]) { k._follow = true; this.swap(k.id, `${k.id}@${look}`); }
      else if (k._follow) { k._follow = false; this.swap(k.id, k.m.tex[0]); }
    }
  }
  // the picture on screen only (blinking / talking); texOf() still tells the real one
  _face(c, texName) {
    if (c.mesh.material.map === this.tex[texName]) return;
    c.mesh.material.map = this.tex[texName];
    if (c.shadow) c.shadow.material.uniforms.map.value = this.tex[texName];
  }
  texOf(id) { return this.cards[id].mesh.userData.tex; }
  show(id) { this.cards[id].body.visible = true; this.cards[id].hidden = false; }
  hide(id) { this.cards[id].body.visible = false; this.cards[id].hidden = true; }
  // the touch print: the main character's hand (book.json "hand": "human" / "cat" / …, or { "kind": …, "print": "#…" })
  handPrint() {
    if (!this._hand) { const h = handOf(), b = BOOK.hand; this._hand = { kind: h.kind, print: (b && typeof b === 'object' && (b.print || b.pad)) || null }; }
    return this._hand;
  }
  base(c) { const b = c.body; if (!b.userData.base) b.userData.base = { x: 0, y: 0, z: 0 }; return b.userData.base; }

  // (the usual speeds are a little slow, for small children: a hop 0.7 s, a turn 1.2 s)
  hop(id, height = 0.05, dur = 0.7, times = 1) {
    const c = this.cards[id], b = c.body, bs = this.base(c);
    this.tween(dur * times, (t) => {
      const u = (t * times) % 1;
      b.position.y = bs.y + Math.sin(Math.PI * u) * height;
      // ちぢんで（ため）→ のびて とぶ → ついたら ちぢんで もどる（つながった形の かわりかた）
      const lerp = (a, z, k) => a + (z - a) * (k < 0 ? 0 : k > 1 ? 1 : k);
      const sq = u < 0.12 ? lerp(1, 0.9, u / 0.12) : u < 0.3 ? lerp(0.9, 1.05, (u - 0.12) / 0.18) : u < 0.8 ? 1.05 : u < 0.92 ? lerp(1.05, 0.92, (u - 0.8) / 0.12) : lerp(0.92, 1, (u - 0.92) / 0.08);
      b.scale.set(2 - sq, sq, 1);
    }, () => { b.position.y = bs.y; b.scale.set(1, 1, 1); });
  }
  wobble(id, amp = 0.1, dur = 1.1, freq = 4) {
    const b = this.cards[id].body;
    this.tween(dur, (t) => { b.rotation.z = Math.sin(t * Math.PI * freq) * amp * (1 - t); }, () => { b.rotation.z = 0; });
  }
  shake(id, amp = 0.008, dur = 0.5) {
    const c = this.cards[id], b = c.body, bs = this.base(c);
    this.tween(dur, (t) => { b.position.x = bs.x + Math.sin(t * 70) * amp * (1 - t); }, () => { b.position.x = bs.x; });
  }
  spin(id, axis = 'y', turns = 1, dur = 1.2, onHalf) {
    const b = this.cards[id].body; let done = false;
    this.tween(dur, (t) => {
      b.rotation[axis] = easeInOut(t) * Math.PI * 2 * turns;
      if (!done && t > 0.25 / turns) { done = true; onHalf && onHalf(); }
    }, () => { b.rotation[axis] = 0; });
  }
  rise(id, from = -0.1, dur = 0.85) {
    const c = this.cards[id], b = c.body, bs = this.base(c); this.show(id);
    // ゆっくり 出はじめて、ゆっくり とまる（パッと とび出さない）
    this.tween(dur, (t) => { b.position.y = bs.y + from * (1 - easeInOut(t)); }, () => { b.position.y = bs.y; });
  }
  moveTo(id, x, y, z, dur = 0.6, ease = easeOutBack) {
    const c = this.cards[id], b = c.body, bs = this.base(c);
    const f = { x: bs.x, y: bs.y, z: bs.z }, to = { x: x ?? bs.x, y: y ?? bs.y, z: z ?? bs.z };
    this.tween(dur, (t) => {
      const k = ease(t);
      bs.x = f.x + (to.x - f.x) * k; bs.y = f.y + (to.y - f.y) * k; bs.z = f.z + (to.z - f.z) * k;
      b.position.set(bs.x, bs.y, bs.z);
    });
  }
  swing(id, amp = 0.35, dur = 2.0, freq = 3) { this.wobble(id, amp, dur, freq); }
  topple(id, dur = 1.4) {
    const c = this.cards[id];
    this.tween(dur, (t) => { c.fold = t < 0.3 ? 1 - easeInOut(t / 0.3) : easeOutBack((t - 0.3) / 0.7); }, () => { c.fold = 1; });
  }
  pulse(id, k = 1.15, dur = 0.7) {
    const b = this.cards[id].body;
    this.tween(dur, (t) => { const s = 1 + (k - 1) * Math.sin(Math.PI * t); b.scale.set(s, s, 1); }, () => b.scale.set(1, 1, 1));
  }
  // the picture shown now, inside the piece's box (page px x0, y0, x1, y1): the pictures of one piece can differ
  // in size (a pot and the flower that grows from it), and words, marks and gauges go by the one shown now
  seenBox(c) { return (c.m.boxes && c.m.boxes[c.mesh.userData.tex]) || [0, 0, c.m.w, c.m.h]; }
  seenSize(c) { const [x0, y0, x1, y1] = this.seenBox(c); return { w: (x1 - x0) * S, h: (y1 - y0) * S }; }
  // a point of the picture shown now, from where the piece turns: the middle, at f of its height (0 = foot, 1 = top)
  _seen(c, f) {
    const [x0, y0, x1, y1] = this.seenBox(c);
    const x = (x0 + x1) / 2 * S - (c.m.pivot === 'left' ? 0 : c.m.pivot === 'right' ? c.w : c.w / 2);
    const y = c.m.pivot === 'top' ? -y1 * S + (y1 - y0) * S * f : (c.m.h - y1) * S + (y1 - y0) * S * f;
    return [x, y];
  }
  top(id, f = 1.0, dz = 0.01) {
    const c = this.cards[id], [x, y] = this._seen(c, f);
    const v = new THREE.Vector3(x, y, dz);
    c.body.localToWorld(v); return this.root.worldToLocal(v);
  }
  // where words and marks stand over piece `id`: its place, not its turning picture — a spin, a flip or a lean
  // does not swing them around (a hop or a walk still takes them along, smoothly: fx.js follow)
  anchor(id, f = 1.0, dz = 0.01) {
    const c = this.cards[id], [x, y] = this._seen(c, f);
    const v = new THREE.Vector3(x, y, dz).add(c.still.position).add(c.body.position);
    c.pivot.localToWorld(v); return this.root.worldToLocal(v);
  }
  // speech bubble above piece `id`, spoken in the voice of `who` (a character id; defaults to id)
  say(id, text, key = id, who = id) {
    if (!this.cards[id]) return;
    const color = castColor(who), show = shown(text);
    this.labels.bubble(key, show, color, () => this.anchor(id, 1.0, 0.004));
    if (this.tex[`${id}@talk`]) this.cards[id].talkUntil = this.time + Math.min(3.5, 0.8 + show.length * 0.08);
    (this._voice = this._voice || {})[key] = this.sound.say(text.replace(/\n/g, ' '), voice(who));
  }
  // `who` is still saying its line: its bubble is up, or its voice is still speaking
  saying(who) { const j = this._voice && this._voice[who]; return this.labels.speaking(who) || !!(j && !j.done); }
  // a touch that makes a line (presets.js react): that piece waits until the line has been said —
  // at least until `at` seconds (when a later step says it), and never longer than TALK_MAX seconds
  talkLock(key, who, at) { (this._talk = this._talk || {})[key] = { who, from: this.time, until: this.time + at + 0.35 }; }
  talking(key) {
    const k = this._talk && this._talk[key]; if (!k) return false;
    if (this.time - k.from < TALK_MAX && (this.time < k.until || k.who.some((w) => this.saying(w)))) return true;
    delete this._talk[key]; return false;
  }
  // the scene (see scene.js): an ending for the mood, lights, darkness, walking, jumping out of a box
  mood(name) { if (MOODS[name]) MOODS[name](this); }
  light(id, on = true) { light(this, id, on); }
  darken(amount, dur = 1.5) { darken(this, amount, dur); }
  walk(id, points, opts) { return walk(this, id, points, opts); }
  reveal(boxId, itemId) { return reveal(this, boxId, itemId); }
  // もちもの: put a thing in the bag (core.js shows it); true when it is new
  getItem(id) { return getItem(id); }
  // AR の文章: the story box drawn again in the language being used, over the printed one (on / off)
  setText(on) {
    if (!this.manifest.panel) return;
    if (!this._tb) { this._tb = textBoxMesh(); this.root.add(this._tb); }
    if (on && this._tbLang !== LANG.now) {
      const d = drawTextBox(this.manifest, this.font);
      const t = new THREE.CanvasTexture(d.canvas); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
      if (this._tb.material.map) this._tb.material.map.dispose();
      this._tb.material.map = t; this._tb.material.needsUpdate = true;
      this._tbBoxes = d.boxes; this._tbLang = LANG.now;
    }
    this._tb.visible = !!on;
  }
  // the reading highlight on line i of the story (-1: none) — on the AR box when it is shown, else on the paper
  highlight(i) {
    const L = (this._tb && this._tb.visible ? this._tbBoxes : this.lines)[i];
    if (!this._hl) {
      const c = document.createElement('canvas'); c.width = 256; c.height = 64;
      const g = c.getContext('2d'); g.fillStyle = 'rgba(255,214,70,0.55)';
      g.beginPath(); g.roundRect ? g.roundRect(2, 2, 252, 60, 28) : g.rect(2, 2, 252, 60); g.fill();
      const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
      this._hl = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: t, transparent: true, depthWrite: false, opacity: 0 }));
      this._hl.position.z = 0.00078; this._hl.renderOrder = 2; this.root.add(this._hl);
    }
    const m = this._hl.material, from = m.opacity, to = L ? 1 : 0;
    if (L) { this._hl.scale.set(L.w * S, L.h * S, 1); this._hl.position.x = px2x(L.x + L.w / 2); this._hl.position.y = py2y(L.y + L.h / 2); }
    this.tween(0.25, (t) => { m.opacity = from + (to - from) * t; });
  }
  // a feeling mark beside the head: '!' '?' 'note' 'heart' 'sweat' 'zzz' 'idea' 'angry'
  // a feeling mark right above the head — not while that one speaks (the words say it)
  mark(id, kind) {
    if (!this.cards[id]) return;
    this.labels.mark(kind, () => this.anchor(id, 1.02, 0.008), id);
  }
  // a word that pops up (ポン！): at piece `at` (by its head) or at a point. While the words of the touches just
  // before are still there (touched again and again), it comes at another place close around that spot
  ono(text, at, color) {
    const p = typeof at === 'string' ? this.top(at, 0.75, 0.03) : at.clone().add(new THREE.Vector3(0, 0, 0.02));
    const t = shown(text), R = this._wordRoom(t);
    if (R.area(p, R.words) > 0.2) return this._onoNear(t, p, color, R);
    this.labels.ono(t, p, color);
  }
  // the size of word `t`, the words still floating, the gauges, and the tests for a place
  _wordRoom(t) {
    const L = this.labels, up = this.up, sy = (v) => v.dot(up);
    const k = 0.00052 * (L.scale || 1);
    const meas = (MEAS = MEAS || document.createElement('canvas').getContext('2d'));
    meas.font = `bold 96px ${L.font}`;
    const lw = (meas.measureText(t).width + 52) * k, lh = 96 * 1.45 * k, rise = 0.07;
    const gauges = [], words = [];
    for (const g of Object.values(L.gauges)) {
      const gd = g.userData, base = (gd.kind === 'bar' ? 0.00062 : 0.00036) * (L.scale || 1), gc = gd.anchorFn();
      gauges.push([gc.x - gd.W * base / 2, gc.x + gd.W * base / 2, sy(gc), sy(gc) + gd.H * base]);
    }
    for (const w of L.items) {
      const d = w.userData; if (d.kind !== 'ono' || d.age > d.life * 0.9) continue;
      words.push([d.p0.x - d.w / 2, d.p0.x + d.w / 2, sy(d.p0), sy(d.p0) + rise + d.h]);
    }
    // how much of the word at place q would cover the boxes in `list` (0 … 1)
    const area = (q, list) => {
      const x0 = q.x - lw / 2, x1 = q.x + lw / 2, y0 = sy(q), y1 = sy(q) + rise + lh;
      let a = 0;
      for (const [bx0, bx1, by0, by1] of list) a += Math.max(0, Math.min(x1, bx1) - Math.max(x0, bx0)) * Math.max(0, Math.min(y1, by1) - Math.max(y0, by0));
      return a / (lw * (rise + lh));
    };
    // on the screen (not under the buttons at the top and bottom): checked with the camera when there is one
    const cam = this.camera, tmp = new THREE.Vector3();
    const seen = (v) => { tmp.copy(v); this.root.localToWorld(tmp); tmp.project(cam); return tmp.x > -0.95 && tmp.x < 0.95 && tmp.y > -0.72 && tmp.y < 0.7; };
    const topLine = sy(new THREE.Vector3(0, PH / 2, 0)) + 0.13;
    const onScreen = (q) => {
      if (!cam) return Math.abs(q.x) <= 0.5 - lw / 2 && sy(q) + rise + lh <= topLine;
      const hi = up.clone().multiplyScalar(rise + lh);
      return [q.clone().setX(q.x - lw / 2), q.clone().setX(q.x + lw / 2), q.clone().setX(q.x - lw / 2).add(hi), q.clone().setX(q.x + lw / 2).add(hi)].every(seen);
    };
    // the last places used, so the next word goes somewhere else
    const recent = (this._onoRecent = this._onoRecent || []);
    const near = (q, f = 0.8) => recent.some((r) => Math.hypot(r.x - q.x, sy(r) - sy(q)) < lw * f);
    return { lw, lh, rise, sy, words, gauges, area, onScreen, recent, near };
  }
  // a word close around point p: beside it, a little above or below it, or to the side (within NEAR words of it) —
  // as little as it can over the floating words or the gauges, not where the last words were
  _onoNear(t, p, color, R = this._wordRoom(t)) {
    const { lw, lh, rise, sy } = R, row = lh + rise, jit = () => (Math.random() - 0.5) * 0.007, NEAR = 0.7;
    let best = null, bs = -Infinity;
    for (const dx of [-1.05, -0.55, 0, 0.55, 1.05]) for (const dy of [-0.6, 0, 0.55, 1.05]) {
      if (!dx && !dy) continue;
      const q = p.clone(); q.x += dx * NEAR * lw + jit(); q.add(this.up.clone().multiplyScalar(dy * NEAR * row));
      if (!R.onScreen(q)) continue;
      const v = -5 * R.area(q, R.gauges) - 2.5 * R.area(q, R.words) - (R.near(q, 0.8 * NEAR) ? 1.5 : 0) - Math.hypot(q.x - p.x, sy(q) - sy(p)) * 8 + Math.random() * 0.6;
      if (v > bs) { bs = v; best = q; }
    }
    if (!best) best = p;
    R.recent.push(best); if (R.recent.length > 3) R.recent.shift();
    this.labels.ono(t, best, color);
  }
  // a word around piece `id` (なんども タッチ): each time at another place close
  // around it — beside it, above it, on its edge — not over the gauges, not where the last words were, and if it can
  // be, not over other pieces (being close to the piece counts more than that)
  onoAround(text, id, color) {
    const c = this.cards[id], t = shown(text);
    if (!c || !c.body.visible) { this.labels.ono(t, this.top(id, 0.75, 0.03), color); return; }
    const R = this._wordRoom(t), { lw, lh, rise, sy } = R;
    // the other pieces standing now (not the target and what it stands on): covered only a little
    const mine = new Set([id]); for (let q = c.m.parent; q; q = this.cards[q] && this.cards[q].m.parent) mine.add(q);
    const pieces = [];
    for (const o of Object.values(this.cards)) {
      if (mine.has(o.id) || !o.body.visible || o.m.flat || !o.pivot.visible) continue;
      const b0 = this.top(o.id, 0), b1 = this.top(o.id, 1), ow = this.seenSize(o).w;
      pieces.push([b0.x - ow / 2, b0.x + ow / 2, Math.min(sy(b0), sy(b1)), Math.max(sy(b0), sy(b1))]);
    }
    // places close around it: beside it at a few heights (just touching its edge, or a little out), above it,
    // and on its upper part when it is big
    const { w: cw, h: ch } = this.seenSize(c);
    const cand = [], step = (lh + rise) / Math.max(ch, 0.05), jit = () => (Math.random() - 0.5) * 0.012;
    for (const f of [0.1, 0.35, 0.6, 0.85]) for (const side of [-1, 1]) for (const out of [-lw * 0.3, 0.004, lw * 0.35]) {
      const q = this.top(id, f, 0.03); q.x += side * (cw / 2 + lw / 2 + out) + jit(); cand.push(q);
    }
    for (const dx of [-0.4, -0.2, 0, 0.2, 0.4]) for (const f of [0.95, 1.0 + step * 0.6]) {
      const q = this.top(id, f, 0.03); q.x += dx * cw + jit(); cand.push(q);
    }
    if (cw > lw * 1.6) for (const dx of [-0.25, 0.25]) for (const f of [0.45, 0.7]) {
      const q = this.top(id, f, 0.03); q.x += dx * cw + jit(); cand.push(q);
    }
    // how far a place is from the piece's outline (0 = on it or touching it)
    const b0 = this.top(id, 0), b1 = this.top(id, 1), cx = b0.x, lo = Math.min(sy(b0), sy(b1)), hi = Math.max(sy(b0), sy(b1));
    const gap = (q) => { const mx = q.x, my = sy(q) + (rise + lh) / 2; return Math.hypot(Math.max(0, Math.abs(mx - cx) - cw / 2 - lw / 2), Math.max(0, my - hi, lo - my)); };
    // the best: on the screen, close to the piece, not over the gauges or the floating words, not where the last
    // ones were; over other pieces only a little — and a little chance, so it changes each time
    let best = null, bs = -Infinity;
    for (const q of cand) {
      if (!R.onScreen(q)) continue;
      const v = -5 * R.area(q, R.gauges) - 2.5 * R.area(q, R.words) - 1.2 * R.area(q, pieces) - (R.near(q) ? 1.5 : 0) - gap(q) * 12 + Math.random() * 0.6;
      if (v > bs) { bs = v; best = q; }
    }
    if (!best) best = this.top(id, 0.75, 0.03);
    R.recent.push(best); if (R.recent.length > 3) R.recent.shift();
    this.labels.ono(t, best, color);
  }
  sfx(name, ...args) { this.sound.sfx(name, ...args); }
  burst(at, n = 14, power = 1, colors) {
    const p = typeof at === 'string' ? this.top(at, 0.6) : at;
    this.fx.burst(p, n, power, colors);
  }
  // rings sit beside the head (speech bubbles use the spot above it); bars sit above
  gauge(key, kind, id, text, color, f = 1.12) {
    const c = this.cards[id];
    const fn = kind === 'ring'
      ? () => this.top(id, 0.78, 0.008).add(new THREE.Vector3(this.seenSize(c).w * 0.5, 0, 0))
      : () => this.top(id, f, 0.006);
    return this.labels.gauge(key, kind, fn, shown(text), color);
  }
  setGauge(key, frac, blink) { this.labels.setGauge(key, frac, blink); }
  removeGauge(key) { this.labels.removeGauge(key); }
  progress(done, total) { this.ui && this.ui.setProgress(this.n, done, total); }
  toast(t, ms) { this.ui && this.ui.toast(t, ms); }

  // steam / dust / bubbles rising from a point
  puff(at, n = 10, color = '#ffffff', spread = 0.03, rise = 0.12, size = 0.03) {
    const p = typeof at === 'string' ? this.top(at, 0.9) : at;
    for (let k = 0; k < n; k++) {
      const v = { x: (Math.random() - 0.5) * spread * 4, y: this.up.y * rise * (0.6 + Math.random() * 0.6), z: this.up.z * rise * (0.6 + Math.random() * 0.6) };
      this.fx.emit({ x: p.x + (Math.random() - 0.5) * spread, y: p.y, z: p.z + 0.01 }, v, color, size * (0.7 + Math.random() * 0.6), 0.9 + Math.random() * 0.5, 0.97, 0.02, 0);
    }
  }
  // falling leaves / petals
  leaves(at, n = 10, colors = ['#7cc27a', '#ffb36b', '#f2d04a']) {
    const p = typeof at === 'string' ? this.top(at, 0.8) : at;
    for (let k = 0; k < n; k++) {
      this.fx.emit({ x: p.x + (Math.random() - 0.5) * 0.15, y: p.y, z: p.z + 0.02 }, { x: (Math.random() - 0.5) * 0.12, y: 0, z: 0.05 }, colors[k % colors.length], 0.028, 1.4 + Math.random() * 0.6, 0.96, -0.18, 1);
    }
  }
  ripple(at, color = '#bfe8ff') {
    for (let r = 0; r < 2; r++) for (let k = 0; k < 18; k++) {
      const a = k / 18 * Math.PI * 2, s = 0.12 + r * 0.06;
      this.fx.emit({ x: at.x, y: at.y, z: 0.004 }, { x: Math.cos(a) * s, y: Math.sin(a) * s * 0.4, z: 0 }, color, 0.018, 0.8, 0.93, 0, 0);
    }
  }
  trail(points, color = '#fff07a', n = 40) {
    for (let k = 0; k < n; k++) {
      const u = k / (n - 1), i = Math.min(points.length - 2, Math.floor(u * (points.length - 1))), f = u * (points.length - 1) - i;
      const a = points[i], b = points[i + 1];
      this.later(k * 35, () => this.fx.emit({ x: a[0] + (b[0] - a[0]) * f, y: a[1] + (b[1] - a[1]) * f, z: 0.01 }, { x: 0, y: 0, z: 0.05 }, color, 0.03, 1.6, 0.95, 0, 1));
    }
  }
  // ---------- fireworks ----------
  // opts: { quiet: true } no sound, { scale: 0.55 } a small one
  firework(target, color = '#ffd84a', color2 = '#ffffff', kind = 'peony', from = null, onBurst = null, opts = {}) {
    const up = this.up.clone();
    const start = from || new THREE.Vector3(target.x + (Math.random() - 0.5) * 0.05, -0.05, 0.01);
    const dur = 0.75;
    if (!opts.quiet) this.sfx('fwLaunch');
    const head = new THREE.Vector3();
    this.tween(dur, (t) => {
      const k = easeInOut(t);
      head.lerpVectors(start, target, k);
      this.fx.emit(head, { x: (Math.random() - 0.5) * 0.02, y: 0, z: 0 }, '#ffe9b0', 0.016, 0.35, 0.9, -0.1, 0);
    }, () => { this._explode(target, color, color2, kind, up, opts); onBurst && onBurst(); });
  }
  _explode(p, color, color2, kind, up, opts = {}) {
    if (!opts.quiet) this.sfx('fwBoom');
    const sc = opts.scale || 1;
    const right = new THREE.Vector3(1, 0, 0);
    const back = new THREE.Vector3().crossVectors(right, up).normalize();
    if (kind === 'ring') {
      const N = Math.round(48 * sc);
      for (let i = 0; i < N; i++) {
        const a = i / N * Math.PI * 2;
        const v = right.clone().multiplyScalar(Math.cos(a) * 0.5 * sc).add(up.clone().multiplyScalar(Math.sin(a) * 0.5 * sc));
        this.fx.emit(p, v, i % 2 ? color : color2, 0.026 * Math.max(0.7, sc), 1.4, 0.92, -0.08, 1);
      }
      for (let i = 0; i < Math.round(16 * sc); i++) { const a = Math.random() * Math.PI * 2; this.fx.emit(p, right.clone().multiplyScalar(Math.cos(a) * 0.15 * sc).add(up.clone().multiplyScalar(Math.sin(a) * 0.15 * sc)), '#ffffff', 0.02, 1.0, 0.92, -0.08, 1); }
    } else if (kind === 'willow') {
      const N = 64;
      for (let i = 0; i < N; i++) {
        const a = Math.random() * Math.PI * 2, s = 0.25 + Math.random() * 0.2;
        const v = right.clone().multiplyScalar(Math.cos(a) * s).add(up.clone().multiplyScalar(Math.abs(Math.sin(a)) * s * 0.8 + 0.05));
        this.fx.emit(p, v, i % 3 ? color : '#fff6c8', 0.024, 2.4 + Math.random() * 0.6, 0.95, -0.22, 1);
      }
    } else if (kind === 'heart') {
      const N = 90;
      for (let i = 0; i < N; i++) {
        const t = i / N * Math.PI * 2;
        const hx = 16 * Math.pow(Math.sin(t), 3) / 17, hy = (13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)) / 17;
        const v = right.clone().multiplyScalar(hx * 0.62).add(up.clone().multiplyScalar(hy * 0.62));
        const cols = castIds().map(fireworkColor); if (!cols.length) cols.push('#ff6aa0');
        this.fx.emit(p, v, cols[Math.floor(i / N * cols.length)], 0.03, 1.8, 0.92, -0.04, 1);
      }
    } else {
      const N = Math.round(70 * sc);
      for (let i = 0; i < N; i++) {
        const a = Math.random() * Math.PI * 2, b = Math.acos(2 * Math.random() - 1);
        const d = new THREE.Vector3(Math.sin(b) * Math.cos(a), Math.cos(b), Math.sin(b) * Math.sin(a));
        const v = right.clone().multiplyScalar(d.x).add(up.clone().multiplyScalar(d.y)).add(back.clone().multiplyScalar(d.z * 0.4)).multiplyScalar(0.55 * sc);
        this.fx.emit(p, v, i % 4 === 0 ? color2 : color, 0.028 * Math.max(0.7, sc), 1.3 + Math.random() * 0.5, 0.92, -0.12, 1);
      }
      for (let i = 0; i < 20; i++) {
        const a = i / 20 * Math.PI * 2;
        const v = right.clone().multiplyScalar(Math.cos(a) * 0.28 * sc).add(up.clone().multiplyScalar(Math.sin(a) * 0.28 * sc));
        this.fx.emit(p, v, color2, 0.022, 1.0, 0.92, -0.1, 1);
      }
    }
    if (CALM.on || opts.quiet) return; // ひかえめモード (and a quiet one): no white crackle flashes
    this.later(450, () => {
      this.sfx('fwCrackle');
      for (let i = 0; i < 26; i++) {
        const q = p.clone().add(new THREE.Vector3((Math.random() - 0.5) * 0.22, 0, 0)).add(up.clone().multiplyScalar((Math.random() - 0.5) * 0.18));
        this.later(Math.random() * 500, () => this.fx.emit(q, { x: 0, y: 0, z: 0 }, '#ffffff', 0.018, 0.25, 0.9, 0, 1));
      }
    });
  }

  // ---------- picking ----------
  // the nearest piece under the finger ("behind": the ones behind it, nearest first)
  pick(raycaster) { const all = this._hits(raycaster, true), hit = all[0] || null; if (hit) hit.behind = all.slice(1); return hit; }
  // what is under the finger, nearest first: visible, and not where the picture is see-through
  // (all = false: only the nearest one)
  // is the picture of piece `id` shown now solid at page pixel (px, py)?
  solidAt(id, px, py) {
    const c = this.cards[id], a = c && this.alpha[c.mesh.userData.tex]; if (!a) return false;
    const ox = c.home ? c.pvx - c.home.pvx : 0, oy = c.home ? c.pvy - c.home.pvy : 0;   // (moved by placePiece: where it is now)
    const u = (px - c.m.x - ox) / c.m.w, v = (py - c.m.y - oy) / c.m.h;
    if (u < 0 || u >= 1 || v < 0 || v >= 1) return false;
    return a.data[Math.floor(v * a.h) * a.w + Math.floor(u * a.w)] > 60;
  }
  // the place of page pixel (px, py) on the picture of standing piece `id`, in the page's space (it leans with the piece)
  pointOn(id, px, py, dz = 0.01) {
    const c = this.cards[id], v = new THREE.Vector3((px - c.pvx) * S, (c.pvy - py) * S, dz);
    c.body.localToWorld(v); return this.root.worldToLocal(v);
  }
  // piece `id` can be touched a little around its picture too (px: page pixels around the picture shown now;
  // without it, 30 px or a third of its smaller side): an invisible board just behind it, which moves and grows with it
  reach(id, px) {
    const c = this.cards[id]; if (!c || c.reachBoard) return;
    const [x0, y0, x1, y1] = this.seenBox(c), [cx, cy] = this._seen(c, 0.5);
    if (px === undefined) px = Math.max(30, Math.min(x1 - x0, y1 - y0) / 3);
    const geo = new THREE.PlaneGeometry((x1 - x0 + px * 2) * S, (y1 - y0 + px * 2) * S);
    const board = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ visible: false, side: THREE.DoubleSide }));
    board.name = id; board.userData.reach = true; board.position.set(cx, cy, -0.0004);
    c.body.add(board); c.reachBoard = board; this.pickables.push(board);
  }
  _hits(raycaster, all) {
    const out = [];
    for (const h of raycaster.intersectObjects(this.pickables, false)) {
      let o = h.object, vis = true;
      if (o.name !== 'sky') { while (o) { if (!o.visible) { vis = false; break; } o = o.parent; } }
      if (!vis) continue;
      if (h.object === this.plate || h.object.name === 'sky') {
        const point = this.root.worldToLocal(h.point.clone());
        out.push({ id: h.object.name, point, at: [(point.x + 0.5) / S, (PH / 2 - point.y) / S] });
        if (!all) break; continue;
      }
      const a = this.alpha[h.object.userData.tex];
      if (a && h.uv) {
        const x = Math.min(a.w - 1, Math.floor(h.uv.x * a.w)), y = Math.min(a.h - 1, Math.floor((1 - h.uv.y) * a.h));
        if (a.data[y * a.w + x] < 60) continue;
      }
      // "at": the touched place on the picture, in page pixels (1600 × 1200) — for "area" (この絵の この あたり)
      const m = !h.object.userData.reach && this.cards[h.object.name] && this.cards[h.object.name].m;
      const at = m && h.uv ? [m.x + h.uv.x * m.w, m.y + (1 - h.uv.y) * m.h] : null;
      out.push({ id: h.object.name, point: this.root.worldToLocal(h.point.clone()), at });
      if (!all) break;
    }
    return out;
  }

  tap(hit, playable = true) {
    if (!hit) return;
    const L = this.logic;
    this.labels.stamp(hit.point, this.handPrint());
    if (!playable) return; // story time: only the paw print
    this.labels.touched();   // what this touch shows comes in front of what earlier touches showed
    if (L.tap && L.tap(hit.id, this, hit)) return;
    const a = L.ambient && L.ambient[hit.id];
    if (a) { a(this, hit); return; }
    this.sfx('twinkle');
  }

  // a finger on the page: what it touches (as pick) and where it is on the paper ("ground"), also off the pieces
  // "under": the ids of every piece under the finger, nearest first (also the ones behind the nearest one: carry)
  touchAt(raycaster) {
    const all = this._hits(raycaster, true), hit = all[0] || null;
    const under = all.map((h) => h.id).filter((id) => this.cards[id]);
    this.root.updateMatrixWorld();
    const n = new THREE.Vector3(0, 0, 1).transformDirection(this.root.matrixWorld), o = new THREE.Vector3().setFromMatrixPosition(this.root.matrixWorld);
    const p = raycaster.ray.intersectPlane(new THREE.Plane().setFromNormalAndCoplanarPoint(n, o), new THREE.Vector3());
    const ground = p ? this.root.worldToLocal(p) : null;
    if (hit) { hit.ground = ground; hit.under = under; return hit; }
    return ground ? { id: null, point: ground, ground, under } : null;
  }
  // a finger pressed on a piece and moving over it (games like "rub", "carry", "hold", "trace"), then lifted
  grab(hit) { if (hit && this.playing) this.labels.touched(); return !!(hit && this.playing && this.logic.grab && this.logic.grab(hit.id, this, hit)); }
  rubAt(hit, px) { if (hit && this.playing && this.logic.rub) this.logic.rub(hit.id, this, hit, px); }
  release(hit) { if (this.playing && this.logic.release) this.logic.release(hit ? hit.id : null, this, hit); }

  narration() { return this.logic.narration ? this.logic.narration(this) : []; }

  // idle moves, blinking and talking (only on the piece's own main picture)
  _life(dt) {
    const k = CALM.on ? 0.5 : 1;
    for (const c of this.idleCards) {
      if (c.stillNow) continue;   // (hiding: it keeps still)
      if (c.idleK !== undefined && c.idleK < 1) c.idleK = Math.min(1, c.idleK + dt / 1.5);   // (out again: it starts moving little by little)
      IDLE[c.m.idle](c, this.time + c.phase, k * (c.idleK ?? 1));
    }
    for (const c of this.glowCards) { c.halo.visible = true; blinkHalo(c, this.time, c.phase, Math.max(0, 1 - (this.time - c.glowFlash) / 0.8)); }
    for (const c of this.blinkCards) {
      if (c.blinking > 0) { c.blinking -= dt; if (c.blinking <= 0) this._face(c, c.mesh.userData.tex); continue; }
      c.blinkT -= dt;
      if (c.blinkT <= 0) {
        c.blinkT = 2.2 + Math.random() * 3.2;
        if (c.mesh.userData.tex === c.m.tex[0] && !(c.talkUntil > this.time)) { c.blinking = 0.14; this._face(c, `${c.id}@blink`); }
      }
    }
    for (const c of Object.values(this.cards)) {
      if (!c.talkUntil) continue;
      const main = c.mesh.userData.tex;
      if (c.talkUntil > this.time && main === c.m.tex[0]) this._face(c, Math.floor(this.time / 0.15) % 2 ? `${c.id}@talk` : main);
      else { c.talkUntil = 0; if (!(c.blinking > 0)) this._face(c, main); }
    }
  }

  // its lines and words are drawn now, a few in each frame (core.js: when the page is opened, and when the
  // language changes), and each is shown once too small to be seen, so none has to be drawn or made ready when
  // a finger touches
  warmTexts() {
    const texts = this.logic.texts || [];
    this._warm = texts.map((x) => (x.kind === 'b' ? () => this.labels.bubbleText(shown(x.text), castColor(x.who)).tex : () => this.labels.onoText(shown(x.text), x.color).tex));
    this._warm.push(() => this.labels.onoText(shown('あそぼう！'), '#5fc46a').tex);
    this._warm.unshift(...this.labels.warmMarks(this.handPrint(), MARK_NAMES).map((t) => () => t));
  }

  // ---------- per frame ----------
  update(dt) {
    dt = Math.min(dt, 0.05); this.time += dt;
    this.labels.warmHide();   // (one word in each frame, a second one only if the first was quick)
    const w0 = performance.now();
    for (let i = 0; i < 2 && this._warm && this._warm.length && (i === 0 || performance.now() - w0 < 3); i++) this.labels.warmShow(i, this._warm.shift()());
    this.up.set(0, Math.cos(this.viewTheta), Math.sin(this.viewTheta));
    this.fx.up.copy(this.up);
    for (const c of this.topCards) {
      if (c.delay > 0) { c.delay -= dt; continue; }
      const target = c.flat ? 0 : (this.open ? this.viewTheta : 0) * c.fold;
      c.vel += (75 * (target - c.theta) - 9.5 * c.vel) * dt;
      c.theta += c.vel * dt;
      c.pivot.rotation.x = c.theta;
      if (c.shadow) {
        const st = Math.max(0, Math.sin(c.theta));
        c.shadow.scale.y = 0.45 * st + 0.001;
        c.shadow.material.uniforms.opacity.value = 0.34 * st * (c.body.visible ? 1 : 0);
        c.shadow.position.x = c.pivot.position.x + c.body.position.x;
        c.shadow.position.y = c.pivot.position.y;
      }
    }
    if (this.skyPivot) this.skyPivot.rotation.x = this.viewTheta;
    // (a move started when another one ends — in its "done" — is kept too: it goes on from the next frame.
    // If a "done" starts the page again, the moves that were going stop)
    const running = this.tweens, resets = this.resets; this.tweens = [];
    const going = running.filter((tw) => {
      tw.started = true;
      tw.t += dt; const u = Math.min(1, tw.t / tw.dur);
      tw.fn(u);
      if (u >= 1) { tw.done && tw.done(); return false; }
      return true;
    });
    if (this.resets === resets) this.tweens = going.concat(this.tweens);
    // ambient twinkle on the page
    this.twinkleT -= dt;
    if (this.open && this.twinkleT <= 0 && this.logic.twinkle !== false) {
      this.twinkleT = 0.35 + Math.random() * 0.5;
      const tw = this.logic.twinkleArea || [-0.48, 0.48, 0.05, 0.36];
      this.fx.emit({ x: tw[0] + Math.random() * (tw[1] - tw[0]), y: tw[2] + Math.random() * (tw[3] - tw[2]), z: 0.004 }, { x: 0, y: 0, z: 0 }, Math.random() < 0.5 ? '#fff2b0' : '#bfe3ff', 0.02, 1.4, 1, 0, 1);
    }
    this._life(dt);
    if (this.logic.weather) weatherTick(this, this.logic.weather, dt);
    lastingTick(this, dt);   // (after the page is cleared: the ending stays a little, see scene.js)
    this.logic.update && this.logic.update(this, dt);
    // a move started just now (by the game's update above) takes its first step before this frame is drawn:
    // a piece that comes out (pop: ほたる・もぐら) is never seen for a moment at its own place first
    for (const tw of this.tweens) if (!tw.started) { tw.started = true; tw.fn(0); }
    this.fx.update(dt);
    this.labels.update(dt, this.up);
  }
}
