// What a page's script.js can import:  import { seg, voice, ... } from 'pulapulabo-ehon';
// (three.js itself:  import * as THREE from 'three';)
import { voice } from './book.js';

export { BOOK, voice, castColor, fireworkColor, markColor, castIds, isCast } from './book.js';
export { addHalo, blinkHalo } from './glow.js';
export { MOVES, EFFECTS, react } from './presets.js';
export { easeOutBack, easeInOut } from './fx.js';
export { has as hasItem } from './story.js';   // もちもの: hasItem('key')
export { finale } from './goals.js';            // the big ending (done "effect": "finale"), for a page's own ending

// one narration line: seg('n', 'text') = narrator, seg('cat', 'text') = the voice of cast member "cat"
// line: which story line it is (0, 1, …), for the reading highlight and the text box (leave out for other lines)
export const seg = (who, text, onstart, line) => ({ text, voice: voice(who), onstart, line });
