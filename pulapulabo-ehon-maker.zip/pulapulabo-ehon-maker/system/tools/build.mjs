// npm run build                      → builds the book named in ar-book.config.json into publish/<book>/
// npm run build -- --book <id>       → builds another book (into publish/<id>/)
// npm run build -- --out <folder>    → choose another output folder
// Everything a reader needs ends up in publish/<book>/ — that folder's contents are what goes to GitHub.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import * as esbuild from 'esbuild';
import subsetFont from 'subset-font';
import { ROOT, rel, sys, publishDir, args, config, loadBook, exists, mkdirp, readJSON, log, FONT_FILES, W, H } from './lib/common.mjs';
import { checkBook } from './lib/check.mjs';
import { renderPage, processPage } from './lib/art.mjs';
import { compileTargets } from './lib/mind.mjs';
import { makePDF } from './lib/pdf.mjs';
import { findPicture, pictureFit, rasterize } from './lib/layers.mjs';
import { makeBookFaces } from './lib/faces.mjs';
import { coverPNG, colophonPNG, bookURL, repoURL, missingLetters, coverArt, autoCover, likeness } from './lib/cover.mjs';
import sharp from 'sharp';

const t0 = Date.now();
const A = args();
const cfg = config();
const bookId = A.book || cfg.book;
if (!bookId) { console.error('どの絵本を作るか決まっていません。ar-book.config.json に {"book": "フォルダ名"} を書いてください。'); process.exit(1); }
const outDir = A.out ? path.resolve(ROOT, A.out) : publishDir(bookId);
const work = rel('.cache', 'build', bookId);
mkdirp(work);

console.log(`\n📖 「${bookId}」を作ります → ${path.relative(ROOT, outDir) || '.'}/`);
const B = loadBook(bookId);
const ctx = { book: B.book, count: B.pages.length };

// 0) faces: characters with marked eyes / mouth get their other faces (guide/03)
const faces = makeBookFaces(B);
if (faces.made.length) log(`表情の絵を作りました: ${faces.made.join(', ')}`);

// 1) check
const { errors, warns } = await checkBook(B);
warns.forEach((w) => console.log('  ⚠️ ', w));
if (errors.length) { errors.forEach((e) => console.log('  ❌', e)); console.log(`\n${errors.length}こ 直すところがあります。上の ❌ を直してから、もう一度 npm run build してください。\n`); process.exit(1); }

// 2) art → textures
const pages = [];
for (const p of B.pages) {
  log(`ページ ${p.n}「${p.id}」の絵`);
  const art = await renderPage(p, ctx);
  pages.push({ p, out: await processPage(p, art, path.join(work, p.id)) });
}

// 3) cast portraits for the start screen: books/<id>/cast/<castId>.png|svg
const portraits = {};
for (const c of B.book.cast || []) {
  const f = findPicture(path.join(B.dir, 'cast'), c.id);
  if (f) portraits[c.id] = `data:image/png;base64,${(await pictureFit(f, 200, 232)).toString('base64')}`;
}

// 表紙と奥付 (book.json "print": { "cover": true, "colophon": true }), with a QR code to the published book
const pr = B.book.print || {};
const url = bookURL(B.book, bookId);
// the cover's picture: books/<id>/cover.svg|png, or the characters lined up — never a page's picture
// (the camera would take the printed cover for that page)
let coverImg = null;
if (pr.cover) {
  const f = findPicture(B.dir, 'cover');
  let pic;
  if (f) pic = await coverArt(f);
  else {
    const ps = [];
    for (const c of B.book.cast || []) { const cf = findPicture(path.join(B.dir, 'cast'), c.id); if (cf) ps.push({ id: c.id, png: await pictureFit(cf, 352, 408) }); }
    pic = autoCover(B.book, ps);
    console.log('  ℹ️  表紙の絵（books/' + bookId + '/cover.svg）がないので、登場人物を ならべた表紙にしました');
  }
  for (let i = 0; i < pages.length; i++) {
    const k = await likeness(pic, pages[i].out.screen);
    if (k > 0.8) console.log(`  ⚠️  表紙の絵が ${i + 1}ページの絵に にています（${Math.round(k * 100)}%）。カメラが 表紙を ${i + 1}ページと まちがえることがあります。表紙は どのページとも ちがう絵にしてください`);
  }
  coverImg = coverPNG(B.book, url, pic);
}
// 4) recognition data: the pages, then the printed cover (showing it asks to turn to page 1)
const coverTarget = coverImg ? await sharp(coverImg).resize(1200).png().toBuffer() : null;
const mind = await compileTargets([...pages.map((x) => x.out.target), ...(coverTarget ? [coverTarget] : [])]);

// 4b) もちもの: a small picture for each thing (books/<id>/items/<item>.svg|png, or the piece with the same id)
const items = {};
for (const it of B.book.items || []) {
  let file = findPicture(path.join(B.dir, 'items'), it.id), full = false;
  if (!file) for (const p of B.pages) { const f = findPicture(path.join(p.dir, 'layers'), it.id); if (f) { file = f; full = true; break; } }
  if (!file) continue;
  const buf = full ? await sharp(await rasterize(file, W, H), { raw: { width: W, height: H, channels: 4 } }).trim().png().toBuffer() : await pictureFit(file, 240, 240);
  items[it.id] = `data:image/png;base64,${(await sharp(buf).resize({ width: 128, height: 128, fit: 'inside' }).png().toBuffer()).toString('base64')}`;
}
// the book's own catching hand (items/hand.svg|png): used by the games with a tool when there is none
{ const f = findPicture(path.join(B.dir, 'items'), 'hand'); if (f) items.hand = `data:image/png;base64,${(await sharp(await pictureFit(f, 240, 240)).resize({ width: 160, height: 160, fit: 'inside' }).png().toBuffer()).toString('base64')}`; }

// 5) reading script, other languages + font subset
const readMap = exists(path.join(B.dir, 'read.json')) ? readJSON(path.join(B.dir, 'read.json')) : {};
for (const { p } of pages) for (const s of p.def.story || []) if (typeof s === 'object' && s.read) readMap[s.text] = s.read;
const langMaps = {};
for (const l of B.book.languages || []) if (l !== 'ja' && exists(path.join(B.dir, 'lang', `${l}.json`))) langMaps[l] = readJSON(path.join(B.dir, 'lang', `${l}.json`));
let text = JSON.stringify(B.book) + JSON.stringify(B.pages.map((p) => p.def)) + JSON.stringify(readMap) + JSON.stringify(langMaps);
for (const f of fs.readdirSync(sys('engine'))) if (/\.(js|html|css)$/.test(f)) text += fs.readFileSync(sys('engine', f), 'utf8');
for (const p of B.pages) if (p.script) text += fs.readFileSync(p.script, 'utf8');
const chars = [...new Set(text.replace(/[\x00-\x1f]/g, ''))].join('') + ' !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz{|}~';
const font = await subsetFont(fs.readFileSync(FONT_FILES[0]), chars, { targetFormat: 'woff2' });

// 6) the finished files: index.html / preview.html (short) + ehon/ (program, data, libraries)
const ehon = path.join(outDir, 'ehon');
fs.rmSync(ehon, { recursive: true, force: true });
mkdirp(ehon);
const ver = (buf) => crypto.createHash('sha1').update(buf).digest('hex').slice(0, 10);
const files = {};   // name → version (so phones never mix old and new files)
const put = (name, data) => { const buf = Buffer.isBuffer(data) ? data : Buffer.from(data); fs.writeFileSync(path.join(ehon, name), buf); files[name] = ver(buf); return buf.length; };
const uri = (buf, mime) => `data:${mime};base64,${buf.toString('base64')}`;

// book.js — settings, story, touches, goals (readable)
put('book.js', `// 「${B.book.title}」の設定・文章・しかけ。books/${bookId}/ から npm run build で作られます（直すときは books/ を直します）。\nwindow.EHON_BOOK = ${JSON.stringify({
  book: { title: B.book.title, subtitle: B.book.subtitle || '', cast: B.book.cast || [], narrator: B.book.narrator, settings: B.book.settings, age: B.book.age, calm: B.book.calm,
    author: B.book.author || '', url, repo: repoURL(B.book, bookId), adultNote: B.book.adultNote || '', languages: B.book.languages || ['ja'], hand: B.book.hand, items: (B.book.items || []).map(({ id, name }) => ({ id, name })) },
  read: readMap,
  lang: langMaps,
  pages: pages.map(({ p, out }) => ({ n: p.n, id: p.id, def: { ...p.def, pieces: undefined }, manifest: out.manifest })),
}, null, 2)};\n`);
// pictures.js — pictures and the font, as data (kept inside a .js file so preview.html also works when opened by double-click)
put('pictures.js', `// 「${B.book.title}」の絵と文字（データ）。npm run build で作られます。\nwindow.EHON_PICTURES = ${JSON.stringify({
  font: uri(font, 'font/woff2'),
  cast: portraits,
  items,
  thumbs: pages.map((x) => uri(x.out.thumb, 'image/jpeg')),
  coverTarget: !!coverTarget,   // targets.mind has the cover after the pages
  pages: pages.map(({ out }) => ({
    plate: uri(out.plate, 'image/jpeg'), mask: uri(out.mask, 'image/png'),
    tex: Object.fromEntries(Object.entries(out.tex).map(([k, v]) => [k, uri(v, 'image/png')])),
  })),
}, null, 2)};\n`);
// nurie.js — ぬりえ (coloring on a tablet): the SVG pictures as text. book.json "nurie": false leaves it out
const nurieOn = B.book.nurie !== false && pages.some(({ out }) => out.nurie && (out.nurie.bg || Object.keys(out.nurie.tex).length));
if (nurieOn) {
  const ol = B.book.outline || {};
  put('nurie.js', `// 「${B.book.title}」の ぬりえ用の絵（SVG）。npm run build で作られます（book.json の "nurie": false で 入れない）。\nwindow.EHON_NURIE = ${JSON.stringify({
    id: bookId,
    background: !!(B.book.nurie && B.book.nurie.background === true),   // 「はいけいも ぬる」の さいしょ（ふつうは オフ）
    outline: ol.enabled === false ? null : { color: ol.color || '#fff3d9', width: ol.width || 6 },
    pages: pages.map(({ out }) => ({ bg: out.nurie.bg, over: out.nurie.over ? { src: uri(out.nurie.over.png, 'image/png'), x: out.nurie.over.x, y: out.nurie.over.y, w: out.nurie.over.w, h: out.nurie.over.h } : null, tex: out.nurie.tex })),
  })};\n`);
}
// targets.mind — image-recognition data (used by index.html only)
put('targets.mind', mind);

// licences
const licenses = [
  `THIRD-PARTY SOFTWARE AND FONT LICENSES\nこの AR えほんに含まれている第三者のソフトウェアとフォントのライセンス表示です。\n`,
  ...(exists(rel('LICENSE')) ? [`==============================================================================\n越前市ぷらぷらぼ AR えほんキット（pulapulabo-ehon-kit）— MIT\n------------------------------------------------------------------------------\n${fs.readFileSync(rel('LICENSE'), 'utf8').split('\n\nThis applies')[0].trim()}\n`] : []),
  `==============================================================================\nthree.js 0.160.0 — MIT\nhttps://github.com/mrdoob/three.js\n------------------------------------------------------------------------------\n${fs.readFileSync(rel('node_modules/three/LICENSE'), 'utf8').trim()}\n`,
  // MindAR and what is bundled inside it (TensorFlow.js core / WebGL / CPU, long, seedrandom): maintain/mindar-src/
  fs.readFileSync(sys('vendor/mind-ar/THIRD_PARTY_NOTICES.txt'), 'utf8').trim() + '\n',
  `==============================================================================\nZen Maru Gothic (font, subset embedded) — SIL Open Font License 1.1\nhttps://github.com/googlefonts/zen-marugothic\n------------------------------------------------------------------------------\n${fs.readFileSync(sys('fonts/OFL.txt'), 'utf8').trim()}\n`,
].join('\n');
put('licenses.js', `// ライセンス表示（画面の「ライセンス表示」で出る文）\nwindow.EHON_LICENSES = ${JSON.stringify(licenses)};\n`);
put('style.css', fs.readFileSync(sys('engine', 'style.css')));

// three.js / MindAR as plain <script> files (they share one three.js through window.THREE)
const globalThree = { name: 'global-three', setup(b) {
  b.onResolve({ filter: /^three$/ }, () => ({ path: 'three', namespace: 'global-three' }));
  b.onLoad({ filter: /.*/, namespace: 'global-three' }, () => ({ contents: 'module.exports = window.THREE;', loader: 'js' }));
} };
const external = ['fs', 'util', 'buffer', 'node-fetch', 'path', 'crypto', 'os', 'string_decoder'];
async function bundle(name, contents, { minify = true, plugins = [globalThree] } = {}) {
  const r = await esbuild.build({
    stdin: { contents, resolveDir: work, sourcefile: name }, bundle: true, minify, format: 'iife', target: ['safari15', 'chrome90', 'firefox90'],
    write: false, charset: 'utf8', legalComments: 'inline', logLevel: 'error', alias: { 'pulapulabo-ehon': sys('engine', 'api.js') }, external, plugins,
  });
  return put(name, r.outputFiles[0].text);
}
await bundle('three.js', `import * as THREE from ${JSON.stringify(rel('node_modules/three/build/three.module.js'))}; window.THREE = THREE;`, { plugins: [] });
await bundle('mindar.js', `import { MindARThree } from ${JSON.stringify(sys('vendor/mind-ar/mindar-image-three.js'))}; window.MindARThree = MindARThree;`);
// engine.js — the picture-book program (not minified, so it can be read) + this book's page scripts
const scriptPages = B.pages.filter((p) => p.script);
await bundle('engine.js', `// AR えほん エンジン（元のプログラムは system/engine/、ページの特別なしかけは books/${bookId}/pages/*/script.js）
import { init, runAR } from ${JSON.stringify(sys('engine', 'core.js'))};
${scriptPages.map((p, i) => `import S${i} from ${JSON.stringify(p.script)};`).join('\n')}
const scripts = { ${scriptPages.map((p, i) => `${JSON.stringify(p.id)}: S${i}`).join(', ')} };
function assets() {
  const B = window.EHON_BOOK, P = window.EHON_PICTURES;
  return {
    book: B.book, read: B.read, lang: B.lang, font: P.font, cast: P.cast, items: P.items, thumbs: P.thumbs, coverTarget: P.coverTarget, nurie: window.EHON_NURIE || null,
    pages: B.pages.map((p, i) => ({ ...p, ...P.pages[i] })),
  };
}
// mode: 'ar' (index.html, camera) or 'preview' (preview.html, no camera)
window.EhonEngine = {
  start({ mode = 'preview', mind = 'ehon/targets.mind' } = {}) {
    const ar = mode === 'ar';
    return init({ ar, assets: assets(), scripts, startAR: ar ? (ctx) => runAR(ctx, window.MindARThree, mind) : null });
  },
};
`, { minify: false });

// index.html / preview.html
const template = fs.readFileSync(sys('engine', 'template.html'), 'utf8');
const escHTML = (t) => t.replace(/&/g, '&amp;').replace(/</g, '&lt;');
const src = (name) => `ehon/${name}?v=${files[name]}`;
function page(file, title, note, list, start) {
  const html = template.replace('__TITLE__', escHTML(title)).replace('__STYLE__', src('style.css')).replace('__NOTE__', note)
    .replace('__SCRIPTS__', list.map((n) => `<script src="${src(n)}"></script>`).join('\n'))
    .replace('__START__', start);
  fs.writeFileSync(path.join(outDir, file), html);
}
const fullTitle = `${B.book.title}${B.book.subtitle ? ' — ' + B.book.subtitle : ''}`;
page('index.html', fullTitle, `「${B.book.title}」AR 本体（スマホのカメラで 印刷したページを映す）`,
  ['three.js', 'mindar.js', 'licenses.js', 'pictures.js', ...(nurieOn ? ['nurie.js'] : []), 'book.js', 'engine.js'], `{ mode: 'ar', mind: '${src('targets.mind')}' }`);
page('preview.html', `${B.book.title} — カメラなしプレビュー`, `「${B.book.title}」カメラなしで 見られる版（ダブルクリックでも 開けます）`,
  ['three.js', 'licenses.js', 'pictures.js', ...(nurieOn ? ['nurie.js'] : []), 'book.js', 'engine.js'], `{ mode: 'preview' }`);

// 8) print files
mkdirp(path.join(outDir, 'print'));
for (const f of fs.readdirSync(path.join(outDir, 'print'))) fs.rmSync(path.join(outDir, 'print', f));
for (const f of ['.nojekyll']) if (exists(path.join(outDir, f))) fs.rmSync(path.join(outDir, f));
// 奥付, and the notes about the cover and colophon
const day = (d) => `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日`;
const colophonImg = pr.colophon ? colophonPNG(B.book, url, B.book.date || day(new Date())) : null;
if (coverImg || colophonImg) {
  const miss = missingLetters(B.book);
  if (miss.length) console.log(`  ⚠️  表紙・奥付の「${miss.join(' ')}」は、フォントにないので印刷されません（題名・作者名を直してください）`);
  if (!url) console.log('  ⚠️  book.json に 公開する場所（"github" の アカウント名、または ほかの場所の "url"）がないので、表紙と奥付に QR コードが入りません。あとで書いて作り直せます');
}
const jpg = (img) => (img ? sharp(img).jpeg({ quality: 90 }).toBuffer() : null);
fs.writeFileSync(path.join(outDir, 'print', `${bookId}_A4.pdf`), await makePDF(B.book, pages.map((x) => x.out.print), { cover: await jpg(coverImg), colophon: await jpg(colophonImg) }));
if (coverImg) fs.writeFileSync(path.join(outDir, 'print', 'cover.png'), await sharp(coverImg).resize(2400).png({ compressionLevel: 9 }).toBuffer());
if (colophonImg) fs.writeFileSync(path.join(outDir, 'print', 'colophon.png'), await sharp(colophonImg).resize(2400).png({ compressionLevel: 9 }).toBuffer());
pages.forEach(({ out }, i) => fs.writeFileSync(path.join(outDir, 'print', `page${i + 1}.png`), out.screen));
fs.writeFileSync(path.join(outDir, 'THIRD_PARTY_LICENSES.txt'), licenses);

const mb = (n) => (n / 1024 / 1024).toFixed(1);
const where = path.relative(ROOT, outDir) || '.';
const sizes = {};
const walk = (d) => { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) walk(p); else sizes[path.relative(outDir, p).split(path.sep).join('/')] = fs.statSync(p).size; } };
walk(outDir);
const total = Object.values(sizes).reduce((a, b) => a + b, 0);
const [bigName, bigSize] = Object.entries(sizes).sort((a, b) => b[1] - a[1])[0];
console.log(`\n✅ できました（${((Date.now() - t0) / 1000).toFixed(0)}秒）  → ${where}/   ぜんぶで ${mb(total)} MB
   index.html       AR 本体（カメラで映す）
   preview.html     カメラなしで遊べる版（ファイルを直接開いても見られます）
   ehon/            プログラム・絵・データ（index.html と preview.html が使う。必ず一緒に置く）
   print/           印刷用 PDF と画像
   THIRD_PARTY_LICENSES.txt  ライセンス表示

   見る             → npm run serve${A.book && A.book !== cfg.book ? ` -- --book ${bookId}` : ''}（または preview.html を開く）
   公開するとき     → ${where}/ の中身を ぜんぶ GitHub にアップロード（guide/06_公開と印刷.md）
`);
if (bigSize > 25 * 1024 * 1024) console.log(`   ⚠️  ${bigName} が 25 MB をこえています（${mb(bigSize)} MB）。GitHub のブラウザからのアップロードは 1ファイル 25 MB までです。\n      ページ数を分けるか、guide/06 の「GitHub Desktop で上げる」を使ってください。\n`);
