// The book's memory across pages (until "さいしょから"):
//   items  : もちもの — things picked up on one page and used on another ("get" / "need" / "give")
//   chosen : えらんだ方で変わる — what was chosen in a "choose" game with "remember": { gift: 'cake' }
//   counts : かぞえた数 — how many were caught or carried in a game with "count": "fish"
//   joined : なかま — friends who come along to the next pages ("join": "kitten")
//   looks  : きせかえ — the look a piece keeps on the other pages (dressup with "keep": true)
//   cleared / seen : the pages that were cleared / shown
//   stamps : ごほうびスタンプ — the pages that were cleared (with "ending")
// Texts can show what was chosen or counted: "{gift}、ありがとう！" → "ケーキ、ありがとう！", "{fish}ひき" → "3ひき"
import { BOOK } from './book.js';
import { tr, plain } from './lang.js';

// the pictures of もちもの (from the build): id → image
export const ICONS = {};
export const MEM = { items: [], chosen: {}, names: {}, stamps: {}, counts: {}, joined: [], looks: {}, cleared: {}, seen: {} };
const listeners = [];
export const onMemory = (fn) => listeners.push(fn);
const changed = (what, value) => listeners.forEach((fn) => fn(what, value));

export function forget() {
  Object.assign(MEM, { items: [], chosen: {}, names: {}, stamps: {}, counts: {}, joined: [], looks: {}, cleared: {}, seen: {} });
  changed('all');
}

// ---------- もちもの ----------
// a thing's name: book.json "items", else a character's name, else the id
export const itemOf = (id) => (BOOK.items || []).find((x) => x.id === id) || { id, name: (BOOK.byId[id] && BOOK.byId[id].name) || id };
export const has = (id) => MEM.items.includes(id);
export function getItem(id) {
  if (!id || has(id)) return false;
  MEM.items.push(id); changed('item', id);
  return true;
}
// "give": "dango" — handed over to someone: it leaves the bag
export function giveItem(id) {
  if (!has(id)) return false;
  MEM.items = MEM.items.filter((x) => x !== id); changed('give', id);
  return true;
}

// ---------- かぞえた数・なかま・きせかえ・ページ ----------
export function setCount(key, n) { MEM.counts[key] = n; MEM.names[key] = String(n); changed('count', key); }
export function join(id) { if (MEM.joined.includes(id)) return false; MEM.joined.push(id); changed('join', id); return true; }
export function keepLook(id, look) { MEM.looks[id] = look; changed('look', id); }
export function markSeen(n) { MEM.seen[n] = true; }
export function markCleared(n) { MEM.cleared[n] = true; }

// ---------- えらんだ方で変わる ----------
export function remember(key, id, name) { MEM.chosen[key] = id; MEM.names[key] = name || id; changed('chosen', key); }
// does a reaction's "need" / "if" hold now?
//   "need": "key" or ["key", "map"]      — all these things are in the bag
//   "if": { "gift": "cake" }              — what was chosen (a list: any of them)
//   "if": { "fish": 3 }                   — counted 3 or more ("fish": ">=3", "<3", "=0" also work)
//   "if": { "joined": "kitten" }          — the kitten came along
//   "if": { "cleared": 2 } / { "seen": [1, 2] } — those pages were cleared / shown
//   "if": { "stamps": "all" } / { "stamps": 3 } — every page / 3 pages cleared
// pg: the page, for "found" (さがす: the ones found on this page so far)
export function holds(spec, pg = null) {
  if (spec.need && ![].concat(spec.need).every(has)) return false;
  if (spec.if) for (const [k, v] of Object.entries(spec.if)) if (!(k === 'found' ? foundOn(pg, v) : test(k, v))) return false;
  return true;
}
// "if": { "found": "mama" } — on a page with さがす: true once mama has been found (["mama", "neko"]: both)
function foundOn(pg, v) { const f = pg && pg.gs && pg.gs.foundIds; return !!f && [].concat(v).every((id) => f[id]); }
function compare(have, want) {
  if (typeof want === 'number') return have >= want;
  const m = /^\s*(>=|<=|>|<|=)?\s*(\d+)\s*$/.exec(String(want));
  if (!m) return false;
  const v = Number(m[2]);
  switch (m[1]) { case '<=': return have <= v; case '<': return have < v; case '>': return have > v; case '=': return have === v; default: return have >= v; }
}
function test(k, v) {
  switch (k) {
    case 'cleared': return [].concat(v).every((n) => MEM.cleared[n]);
    case 'seen': return [].concat(v).every((n) => MEM.seen[n]);
    case 'joined': return [].concat(v).every((id) => MEM.joined.includes(id));
    case 'stamps': { const got = Object.keys(MEM.cleared).length; return v === 'all' ? got >= (BOOK.pageCount || 1) : compare(got, v); }
    default:
      if (k in MEM.counts || typeof v === 'number' || /^\s*[<>=]/.test(String(v))) return compare(MEM.counts[k] || 0, v);
      return [].concat(v).includes(MEM.chosen[k]);
  }
}
// "{gift}" → the name of what was chosen (in the language being used)
export function fill(text, l) {
  return String(text ?? '').replace(/\{([A-Za-z0-9_-]+)\}/g, (m, k) => (MEM.names[k] !== undefined ? plain(tr(MEM.names[k], l)) : m));
}
// a text ready to show in the app: translated, choices filled in, ふりがな as kana (l: another language, e.g. the voice's)
export const shown = (text, l) => plain(fill(tr(text, l), l));

// ---------- ごほうびスタンプ ----------
export function stamp(n) { if (MEM.stamps[n]) return false; MEM.stamps[n] = true; changed('stamp', n); return true; }
