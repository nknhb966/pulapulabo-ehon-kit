// The page's game ("goal" in page.json) and what happens when it is cleared ("done").
//   find    : かくれている ものを さがす        gather : じかんないに ぜんぶ タッチ      mash : なんども タッチ
//   order   : じゅんばんに タッチ              choose : えらぶ（クイズ）                pop  : でてきたら タッチ
//   fall    : おちてくる ものを キャッチ        grow   : そだてる（だんだん かわる）     dressup: きせかえ
//   rub     : こする・はらう
//   and in games.js: carry (はこぶ) · copy (まねっこ) · pairs (ペアさがし) · hold (ながおし) · trace (なぞって つなぐ)
// Numbers that make a game easier or harder come from the readers' age (book.json "age": 3 / 5 / 7)
// unless the goal says otherwise. When nothing happens for a while, the things to touch next shine (hint).
import * as THREE from 'three';
import { isCast, markColor, fireworkColor, castIds, age, CALM } from './book.js';
import { react, pick, altKey, nextIdx, moveOf } from './presets.js';
import { MOODS, walk, light, darken, canTravel } from './scene.js';
import { remember, itemOf, holds, setCount, keepLook } from './story.js';
import { easeInOut } from './fx.js';
import { glowTexture } from './glow.js';
import { toolStart, toolSwing, reach, hasTool } from './tool.js';
import { MORE_GAMES, moreHint, moreProgress, moreHintTargets } from './games.js';

export const param = (g, key, ageKey = key) => g[key] ?? age()[ageKey];
export const progressed = (pg) => { pg.gs.lastMove = pg.time; };
const noSwap = (spec) => { const o = { ...spec }; delete o.swap; return o; };

// ---------- texts and progress dots ----------
export function goalHint(g) {
  switch (g.type) {
    case 'find': return `かくれている ものを ${g.items.length}つ さがしてね`;
    case 'gather': return `${param(g, 'seconds')}びょうの うちに ぜんぶ タッチしてね`;
    case 'mash': return g.team ? 'みんなを タッチしてから、なんども タッチしてね' : 'なんども タッチしてね';
    case 'order': return 'じゅんばんに タッチしてね';
    case 'choose': return quizOf(g)[0].question || 'どれかな？ えらんで タッチしてね';
    case 'pop': return 'でてきたら タッチしてね';
    case 'grow': return 'なんども タッチして そだててね';
    case 'dressup': return g.answer ? 'おてほんと おなじに してね' : 'タッチして きせかえしてね';
    case 'rub': return 'ゆびで こすってね';
    case 'fall': return 'おちてくる ものを タッチしてね';
    default: return moreHint(g) || 'いろいろ さわってみてね';
  }
}
export function goalProgress(g) {
  const dots = (label, total, colors) => ({ label: g.label || label, total, colors });
  switch (g.type) {
    case 'find': return dots('みつけた', g.items.length);
    case 'choose': return quizTotal(g) > 1 ? dots('せいかい', quizTotal(g)) : null;
    case 'gather': return dots('タッチ', g.targets.length, g.targets.map((t) => (isCast(t) ? markColor(t) : '#ffe36b')));
    case 'mash': return g.team ? dots('みんな', g.team.length, g.team.map((t) => (isCast(t) ? markColor(t) : '#ffe36b'))) : null;
    case 'order': return dots('じゅんばん', g.targets.length);
    case 'pop': return dots('タッチ', param(g, 'times', 'popTimes'));
    case 'grow': return dots('そだつ', (g.stages || []).length);
    case 'dressup': return dots('きせかえ', Object.keys(g.answer || g.looks || {}).length);
    case 'rub': return dots('きれい', g.targets.length);
    case 'fall': return dots('キャッチ', param(g, 'times', 'popTimes'));
    default: return moreProgress(g, dots);
  }
}

// ---------- hints: after a while with no progress, the things to touch next shine ----------
function hintTargets(pg, g) {
  const gs = pg.gs;
  switch (g.type) {
    case 'find': return g.items.filter((it) => !gs.found[findKey(it)]).map((it) => (gs.place && gs.place[findKey(it)] ? gs.place[findKey(it)].spot : it.spot));
    case 'gather': return g.targets.filter((t) => !gs.ready[t]);
    case 'mash': { const wait = (g.team || []).filter((t) => !gs.ready[t]); return wait.length ? wait : [g.target]; }
    case 'grow': return [g.target];
    case 'order': return [g.targets[gs.next]];
    case 'choose': { const q = quizOf(g)[gs.q || 0] || g; return (q.options || []).filter((o) => !(gs.got && gs.got[o])); }
    case 'pop': return Object.keys(gs.up);
    case 'dressup': return Object.keys(g.looks || {}).filter((id) => !lookMatches(pg, g, id));
    case 'rub': return g.targets.filter((t) => !gs.cleared[t]);
    case 'fall': return Object.keys(gs.up);
    default: return moreHintTargets(pg, g);
  }
}
function showHint(pg, g) {
  const ids = hintTargets(pg, g).filter((id) => id && pg.C(id) && pg.C(id).body.visible);
  if (!ids.length) return;
  if (g.type === 'choose') ask(pg, quizOf(g)[pg.gs.q || 0] || g);
  ids.forEach((id, i) => pg.later(i * 160, () => { pg.pulse(id, 1.1, 0.6); if (!CALM.on) pg.burst(id, 8, 0.7, ['#fff2a8', '#ffffff']); }));
  pg.sfx('twinkle');
}

// ---------- when the page is cleared ----------
const skyPoint = (pg, x, h) => new THREE.Vector3(x, 0.1, 0.01).add(pg.up.clone().multiplyScalar(h));
// the big ending ("effect": "finale"): a barrage of fireworks, glitter over the sky, then one golden willow
export function finale(pg) {
  const ids = castIds().filter((id) => pg.C(id));
  const cols = [...ids.map(fireworkColor), '#ffe9a0', '#ffffff'];
  const kinds = ['peony', 'ring', 'peony', 'willow', 'ring', 'peony'];
  const shots = CALM.on ? 6 : 14;
  for (let i = 0; i < shots; i++) {
    pg.later(700 + i * (CALM.on ? 600 : 300) + Math.random() * 120, () => {
      const x = (i % 2 ? 1 : -1) * (0.08 + Math.random() * 0.32), h = 0.17 + Math.random() * 0.17;
      const c = cols[i % cols.length], c2 = cols[(i + 3) % cols.length];
      pg.firework(skyPoint(pg, x, h), c, c2, kinds[i % kinds.length], new THREE.Vector3(x * 0.8, -0.1, 0.01),
        i % 3 === 0 ? () => pg.ono(['ドーン！', 'パーン！', 'ドドーン！'][(i / 3) % 3], skyPoint(pg, x, h + 0.07), c) : null);
    });
  }
  if (!CALM.on) {
    pg.tween(6.5, () => {   // glitter drifting down over the whole sky
      for (let k = 0; k < 2; k++) {
        const p = skyPoint(pg, -0.5 + Math.random(), 0.32 + Math.random() * 0.14);
        pg.fx.emit(p, { x: (Math.random() - 0.5) * 0.02, y: -pg.up.y * 0.03, z: -pg.up.z * 0.03 }, Math.random() < 0.6 ? '#ffe9a0' : '#ffffff', 0.016 + Math.random() * 0.012, 2.4, 0.99, -0.03, 1);
      }
    });
  }
  ids.forEach((id, i) => pg.later(500 + i * 220, () => pg.burst(id, 20, 1.2, ['#fff2a8', '#ffffff', fireworkColor(id)])));
  pg.later(CALM.on ? 4800 : 5200, () => {
    pg.firework(skyPoint(pg, 0, 0.3), '#ffd84a', '#fff6c8', 'willow', new THREE.Vector3(0, -0.12, 0.01), () => {
      pg.ono('ドドーン！', skyPoint(pg, 0, 0.4), '#ffd84a');
      pg.sfx('finale');
      ids.forEach((id, i) => pg.later(i * 120, () => { pg.hop(id, 0.07); pg.burst(id, 16, 1.3, ['#fff2a8', '#ffffff', '#ffc2e2']); }));
    });
  });
}

const DONE_TOAST = {
  choose: 'せいかい！', pop: 'ぜんぶ つかまえたね！', fall: 'ぜんぶ キャッチしたね！', grow: 'おおきく なったね！', rub: 'ぴかぴかに なったね！',
  carry: 'ぜんぶ はこんだね！', copy: 'よく おぼえたね！', pairs: 'ぜんぶ そろったね！', trace: 'できあがり！',
};
export function goalDone(pg, g) {
  if (pg.gs.done) return;
  pg.gs.done = true;
  pg.complete();
  // "if" / "need" in done: when it does not hold, "else" is the ending instead (スタンプの数・かぞえた数 … で変わる)
  let d = g.done || {};
  if ((d.if || d.need) && !holds(d)) d = d.else || {};
  pg.later(400, () => {
    pg.sfx(d.sound || 'fanfare');
    if (d.toast !== '') pg.toast(d.toast || (g.type === 'choose' && !g.answer ? 'これに きめた！' : DONE_TOAST[g.type]) || 'できたね！ すごい！', 3000);
    if (d.get) [].concat(d.get).forEach((it, i) => pg.later(1200 + i * 500, () => pg.getItem(it)));   // もちもの
    const cast = castIds().filter((id) => pg.C(id));
    // happy faces: every character that has a <id>@happy picture on this page ("face": "cheer" = another name, false = none)
    const face = d.face === undefined ? 'happy' : d.face;
    if (face) cast.forEach((id) => { const k = `${id}@${face}`; if (pg.tex[k]) { clearTimeout(pg.C(id)._backT); pg.swap(id, k); } }); // (a picture that was going back later stays this face)
    if (d.hop !== false) cast.filter((id) => !(d.move && d.move[id])).forEach((id, i) => pg.later(i * 130, () => pg.hop(id, 0.05)));   // (one with its own "move" does that instead)
    // "move": { "door": "open" } — things that move when the page is cleared
    Object.entries(d.move || {}).forEach(([id, mv], i) => pg.C(id) && moveOf(pg, mv) && pg.later(i * 150, () => moveOf(pg, mv)(pg, id)));
    // "trail": { "points": [[x, y], …] in page pixels (1600 × 1200), "color": "#…" } — a path that lights up
    const tr = Array.isArray(d.trail) ? { points: d.trail } : d.trail;
    if (tr && Array.isArray(tr.points) && tr.points.length >= 2) pg.later(300, () => pg.trail(tr.points.map(([x, y]) => [x / 1600 - 0.5, 0.375 - y / 1600]), tr.color || '#ffe08a', 40));
    // "walk": { "cat": [[x, y], …] } — walking somewhere when the page is cleared
    Object.entries(d.walk || {}).forEach(([id, w], i) => canTravel(pg, id) && pg.later(i * 200, () => walk(pg, id, Array.isArray(w) ? w : w.points, { flip: !!w.flip })));
    // "light": ["window", "lamp"] — lights that turn on;  "dark": 0.5 — the page gets darker (0 = bright again)
    [].concat(d.light || []).forEach((id, i) => pg.C(id) && pg.later(300 + i * 250, () => light(pg, id, true)));
    if (typeof d.dark === 'number') darken(pg, d.dark, 2);
    // "mark": "heart" (everyone) or { "cat": "note" } — feeling marks
    // (not for the ones who say a line here: their words say it)
    const says = Array.isArray(d.say) ? d.say : d.say ? [d.say] : [];
    const speakers = new Set(says.map((s) => s && s.who));
    if (d.mark) Object.entries(typeof d.mark === 'string' ? Object.fromEntries(cast.map((id) => [id, d.mark])) : d.mark).filter(([id]) => !speakers.has(id)).forEach(([id, k], i) => pg.later(200 + i * 150, () => pg.mark(id, k)));
    if (MOODS[d.effect]) MOODS[d.effect](pg);
    else if (d.effect === 'finale') finale(pg);
    else if (d.effect === 'none') { /* nothing more (a page's own move can make the ending) */ }
    else if (d.effect === 'fireworks') {
      for (let k = 0; k < (CALM.on ? 3 : 6); k++) pg.later(200 + k * 320, () => {
        const x = -0.35 + Math.random() * 0.7, p = new THREE.Vector3(x, 0.05, 0.01).add(pg.up.clone().multiplyScalar(0.3 + Math.random() * 0.08));
        const ids = cast.length ? cast : ['_'];
        pg.firework(p, fireworkColor(ids[k % ids.length]), '#ffffff', k % 2 ? 'ring' : 'peony', new THREE.Vector3(x, -0.08, 0.01));
      });
    } else {
      for (let k = 0; k < 5; k++) pg.later(k * 160, () => pg.fx.burst(new THREE.Vector3(-0.36 + k * 0.18, -0.02 + Math.random() * 0.2, 0.04), 16, 1.2));
    }
    says.forEach((s, k) => pg.later(700 + k * 1700, () => pg.C(s.who) && pg.say(s.who, s.text)));
  });
}

// ---------- helpers for the games ----------
// "choose": the question, by a character's speech bubble or at the top of the screen
function ask(pg, g) {
  if (!g.question) return;
  if (g.who && pg.C(g.who)) pg.say(g.who, g.question); else pg.toast(g.question, 2600);
}
// "dressup": the look a piece is wearing now ("" = its own picture)
function lookOf(pg, g, id) { const list = ['', ...(g.looks[id] || [])]; return list[pg.gs.look[id] || 0]; }
function lookMatches(pg, g, id) {
  if (!g.answer || !(id in g.answer)) return true;
  const want = g.answer[id] === 'base' ? '' : g.answer[id];
  return lookOf(pg, g, id) === want;
}
// "rub": a piece goes away when it is rubbed clean (or changes to its "swap" picture)
function rubClear(pg, g, id) {
  pg.gs.cleared[id] = true; pg.removeGauge(`r_${id}`);
  pg.sfx(g.doneSound || 'kirarin'); pg.ono(g.doneWord || 'ぴかぴか！', id, g.color || '#3fa9e0');
  if (g.swap && pg.tex[`${id}@${g.swap}`]) { pg.swap(id, `${id}@${g.swap}`); pg.burst(id, 18, 1.1); }
  else {
    const b = pg.C(id).body; pg.puff(pg.top(id, 0.5), 18, '#ffffff', 0.02, 0.14, 0.03);
    pg.tween(0.5, (t) => b.scale.setScalar(1 - t), () => { pg.hide(id); b.scale.setScalar(1); });
  }
  const n = Object.keys(pg.gs.cleared).length;
  pg.progress(n, g.targets.length); progressed(pg);
  if (n === g.targets.length) pg.later(900, () => goalDone(pg, g));
}
function rubAdd(pg, g, id, amount, hit) {
  if (pg.gs.cleared[id]) return;
  pg.gs.rubbed[id] = Math.min(1, (pg.gs.rubbed[id] || 0) + amount);
  if (!pg.labels.gauges[`r_${id}`]) pg.gauge(`r_${id}`, 'bar', id, g.gauge || 'ぴかぴか', '#3fa9e0', 1.05);
  pg.setGauge(`r_${id}`, pg.gs.rubbed[id]);
  const t = pg.time;
  if (t - (pg.gs.fxT || 0) > 0.12) { pg.gs.fxT = t; pg.puff(hit ? hit.point : pg.top(id, 0.5), CALM.on ? 2 : 4, g.particle || '#e8f8ff', 0.012, 0.08, 0.02); }
  if (t - (pg.gs.sndT || 0) > 0.3) { pg.gs.sndT = t; pg.sfx(g.sound || 'kyu'); }
  if (t - (pg.gs.wordT || 0) > 1.0) { pg.gs.wordT = t; pg.ono(pick(g.word || ['ゴシゴシ', 'キュッキュッ'], nextIdx(pg, 'rub')), hit ? hit.point : id, g.color || '#3fa9e0'); }
  if (pg.gs.rubbed[id] >= 1) rubClear(pg, g, id);
}

// ---------- でてきたら タッチ (pop) and おちてくる (fall) ----------
// how a target comes out, stays, and goes back. Positions are the piece's own (body) offsets: y is "up" on the card.
const POP_STYLE = {
  rise: {
    inT: 0.5,
    come(pg, id, L) {
      const c = pg.C(id), b = c.body, bs = pg.base(c); pg.show(id);
      pg.tween(0.5, (t) => { b.position.y = bs.y + L - (c.h + L) * (1 - easeInOut(t)); });
    },
    stay(pg, id, e, L) { const c = pg.C(id); c.body.position.y = pg.base(c).y + L; },
    go(pg, id) {
      const c = pg.C(id), b = c.body, bs = pg.base(c), y0 = b.position.y;
      pg.tween(0.35, (t) => { b.position.y = y0 - (y0 - bs.y + c.h) * t * t; }, () => { pg.hide(id); b.position.y = bs.y; });
    },
  },
  swim: {
    inT: 0.9,
    come(pg, id, L) {
      const c = pg.C(id), b = c.body, bs = pg.base(c), k = Math.random() < 0.5 ? -1 : 1; c.popDir = k; pg.show(id);
      pg.tween(0.9, (t) => { const e = easeInOut(t); b.position.x = bs.x + k * 0.07 * (1 - e); b.position.y = bs.y + L - (c.h + L) * (1 - e); b.rotation.z = k * 0.25 * (1 - e); });
    },
    stay(pg, id, e, L) { const c = pg.C(id), b = c.body, bs = pg.base(c); b.position.y = bs.y + L + 0.006 * Math.sin(e * 3); b.rotation.z = 0.08 * Math.sin(e * 2.2); },
    go(pg, id) {
      const c = pg.C(id), b = c.body, bs = pg.base(c), k = -(c.popDir || 1), y0 = b.position.y;
      pg.tween(0.7, (t) => { const e = easeInOut(t); b.position.x = bs.x + k * 0.06 * e; b.position.y = y0 - (y0 - bs.y + c.h) * e; b.rotation.z = -k * 0.3 * e; },
        () => { pg.hide(id); b.position.set(bs.x, bs.y, bs.z); b.rotation.z = 0; });
    },
  },
  fly: {
    inT: 1.1,
    come(pg, id, L) {
      const c = pg.C(id), b = c.body, bs = pg.base(c); pg.show(id);
      pg.tween(1.1, (t) => { const e = easeInOut(t); b.position.y = bs.y + L - (c.h * 1.2 + L) * (1 - e); b.position.x = bs.x + 0.02 * Math.sin(Math.PI * 2 * t) * (1 - t); });
      c.glowFlash = pg.time;
    },
    stay(pg, id, e, L) { const c = pg.C(id), b = c.body, bs = pg.base(c); b.position.x = bs.x + 0.018 * Math.sin(e * 1.6); b.position.y = bs.y + L + 0.012 * Math.sin(e * 3.2); },
    go(pg, id) {
      const c = pg.C(id), b = c.body, bs = pg.base(c), x0 = b.position.x, y0 = b.position.y;
      pg.tween(1.0, (t) => { const e = easeInOut(t); b.position.x = x0 + (bs.x - x0) * e; b.position.y = y0 + (bs.y - c.h * 1.2 - y0) * e; },
        () => { pg.hide(id); b.position.set(bs.x, bs.y, bs.z); });
    },
  },
  fall: {
    inT: 0,
    come(pg, id) { const c = pg.C(id), b = c.body, bs = pg.base(c); pg.show(id); b.position.y = bs.y + FALL_H; c.fallT = 0; },
    stay() {},
    go(pg, id) {   // reached the ground: a small bounce, then it fades away
      const c = pg.C(id), b = c.body, bs = pg.base(c);
      pg.tween(0.7, (t) => { b.position.y = bs.y + 0.02 * Math.sin(Math.PI * t); b.scale.setScalar(Math.max(0.001, 1 - easeInOut(t))); }, () => { pg.hide(id); b.position.y = bs.y; b.scale.setScalar(1); });
    },
  },
};
const FALL_H = 0.3;   // how high above their place the falling ones start (page widths)
// how high above its own place a target comes out: over the front pieces it hides behind ("behind"), else "lift"
function liftOf(pg, g, id) {
  const c = pg.C(id);
  if (c.popLift !== undefined) return c.popLift;
  let L = typeof g.lift === 'number' ? g.lift * c.h : (g.style === 'fly' ? 0.02 : 0);
  if (typeof g.lift !== 'number') for (const k of [].concat(g.behind || [])) {
    const f = pg.C(k); if (!f) continue;
    const overlap = Math.min(c.m.x + c.m.w, f.m.x + f.m.w) - Math.max(c.m.x, f.m.x);
    if (overlap > 0 && f.m.y + f.m.h > c.m.y + c.m.h) L = Math.max(L, f.h * 0.85);
  }
  return (c.popLift = L);
}
const popStyle = (g) => POP_STYLE[g.type === 'fall' ? 'fall' : g.style] || POP_STYLE.rise;
const popTimes = (g) => param(g, 'times', 'popTimes');
// a target out now that is close enough to the touch (the tool reaches a little farther than a hand)
const GRACE = 0.5;   // seconds a target that has started to go back can still be caught
const catchable = (pg) => [...Object.keys(pg.gs.up), ...Object.keys(pg.gs.leaving).filter((id) => pg.time - pg.gs.leaving[id] < GRACE)];
function nearTarget(pg, g, hit) {
  if (!hit) return null;
  let best = null, bd = reach(pg);
  for (const id of catchable(pg)) {
    const d = pg.top(id, 0.5).distanceTo(hit.point);
    if (d < bd) { bd = d; best = id; }
  }
  return best;
}
// a place inside the box, not too close to the ones already there (and not in a neat row either)
function boxSlot(pg, box, size) {
  const used = pg.gs.slots, minD = Math.max(size * 1.4, box.w * 0.2);
  let best = null, bestD = -1;
  for (let k = 0; k < 24; k++) {
    const p = new THREE.Vector3((Math.random() - 0.5) * box.w * 0.56, box.h * (0.12 + Math.random() * 0.5), 0);
    const d = used.length ? Math.min(...used.map((q) => Math.hypot(q.x - p.x, q.y - p.y))) : 1;
    if (d >= minD) { best = p; break; }
    if (d > bestD) { bestD = d; best = p; }
  }
  used.push(best);
  return best.clone();
}
// a caught one goes into the "into" piece and stays there (glowing ones keep glowing; the piece lights up a little more)
function intoBox(pg, g, id) {
  const box = pg.C(g.into), c = pg.C(id); if (!box || !c) return;
  const n = pg.gs.inside.length; if (n >= 14) return;
  const mesh = new THREE.Mesh(c.mesh.geometry, c.mesh.material.clone());
  const k = Math.min(0.55, (box.w * 0.32) / c.w); mesh.renderOrder = 2;
  const slot = boxSlot(pg, box, c.w * k);
  slot.z = 0.0012 + n * 0.0001;
  if (box.m.pivot === 'top') slot.y -= box.h;
  const glow = c.m.glow ? new THREE.Mesh(new THREE.PlaneGeometry(c.w * 1.6, c.w * 1.6), new THREE.MeshBasicMaterial({ map: glowTexture(), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending })) : null;
  const from = pg.top(id, 0.5);
  pg.root.add(mesh); pg._extras.push(mesh);
  pg.tween(0.8, (t) => {
    const to = box.body.localToWorld(slot.clone()); pg.root.worldToLocal(to);
    const e = easeInOut(t), p = from.clone().lerp(to, e).add(pg.up.clone().multiplyScalar(0.08 * Math.sin(Math.PI * t)));
    const s = 1 + (k - 1) * e; mesh.scale.set(s, s, 1);
    mesh.position.copy(p); mesh.quaternion.copy(box.body.getWorldQuaternion(new THREE.Quaternion()));
    const pq = pg.root.getWorldQuaternion(new THREE.Quaternion()).invert(); mesh.quaternion.premultiply(pq);
  }, () => {
    pg.root.remove(mesh); mesh.position.copy(slot); mesh.quaternion.identity(); mesh.scale.set(k, k, 1); mesh.userData.caught = true; box.body.add(mesh);
    if (glow) { glow.position.set(slot.x, slot.y + c.h * k * 0.4, slot.z - 0.0004); glow.userData.caught = true; glow.userData.born = pg.time; glow.material.opacity = 0; box.body.add(glow); pg.gs.glows.push(glow); }
    pg.gs.inside.push(mesh); pg.pulse(g.into, 1.06, 0.5); pg.sfx('po');
    if (c.m.glow || g.intoLight) { light(pg, g.into, true); pg.later(600, () => { if (box.lamp) box.lamp.material.opacity = Math.min(1, 0.3 + 0.1 * pg.gs.inside.length); }); }
  });
}
function popGame(type) {
  return {
    init(pg, g) {
      pg.gs.up = {}; pg.gs.leaving = {}; pg.gs.caught = 0; pg.gs.nextAt = 0; pg.gs.inside = []; pg.gs.glows = []; pg.gs.slots = [];
      g.targets.forEach((t) => pg.C(t) && pg.hide(t));
      const box = g.into && pg.C(g.into);   // (from the last time: the ones in the box go)
      if (box) box.body.children.filter((o) => o.userData.caught).forEach((o) => box.body.remove(o));
    },
    play(pg, g) { pg.gs.nextAt = pg.time + 0.8 + toolStart(pg, g); },
    open(pg, g) { if (pg.playing && hasTool(g) && !pg.gs.tool) pg.gs.nextAt = Math.max(pg.gs.nextAt, pg.time + toolStart(pg, g)); },
    update(pg, g, dt) {
      for (const g2 of pg.gs.glows) g2.material.opacity = Math.min(1, (pg.time - g2.userData.born) / 0.6) * (0.55 + 0.35 * Math.sin(pg.time * 3 + g2.id));
      if (pg.gs.done || pg.gs.finishing || !pg.playing || !pg.open) return;
      const S = popStyle(g), stay = param(g, 'stay');
      for (const [id, t0] of Object.entries(pg.gs.up)) {
        const e = pg.time - t0;
        if (type === 'fall') {   // falling: "stay" × 2 seconds from the sky to the ground
          const c = pg.C(id), b = c.body, bs = pg.base(c), fallT = stay * 2;
          b.position.y = bs.y + FALL_H * Math.max(0, 1 - e / fallT); b.rotation.z = 0.15 * Math.sin(e * 2.5);
          if (e >= fallT) { delete pg.gs.up[id]; pg.gs.leaving[id] = pg.time; b.rotation.z = 0; S.go(pg, id); pg.sfx('po'); }
          continue;
        }
        if (e > S.inT) S.stay(pg, id, e - S.inT, liftOf(pg, g, id));
        if (e > S.inT + stay) { delete pg.gs.up[id]; pg.gs.leaving[id] = pg.time; S.go(pg, id); }
      }
      if (pg.time < pg.gs.nextAt || Object.keys(pg.gs.up).length >= (g.together || 1)) return;
      const free = g.targets.filter((t) => pg.C(t) && !pg.gs.up[t] && !pg.C(t).body.visible);
      for (const t of free) delete pg.gs.leaving[t];
      if (!free.length) return;
      const id = free[Math.floor(Math.random() * free.length)];
      pg.gs.up[id] = pg.time; S.come(pg, id, type === 'fall' ? 0 : liftOf(pg, g, id)); pg.sfx(g.upSound || (type === 'fall' ? 'sui' : 'pyoko'));
      pg.gs.nextAt = pg.time + S.inT + stay * 0.6 + 0.4;
    },
    tap(pg, g, id, hit) {
      const mine = g.targets.includes(id) || [].concat(g.behind || []).includes(id) || id === 'plate' || id === g.into;
      if (pg.gs.done) return false;
      if (pg.gs.finishing) return g.targets.includes(id);
      const t = g.targets.includes(id) && catchable(pg).includes(id) ? id : nearTarget(pg, g, hit);
      if (!t) { if (mine && hasTool(g)) { toolSwing(pg, g, hit && hit.point); return true; } return g.targets.includes(id); }
      const at = pg.top(t, 0.5);
      delete pg.gs.up[t]; delete pg.gs.leaving[t]; pg.gs.caught++; progressed(pg);
      toolSwing(pg, g, at);
      const r = g.react && g.react[t];
      if (r) react(pg, t, r, null, { free: true }); else pg.sfx(g.sound || 'pon');
      pg.ono(pick(g.word || ['ポン！', 'タッチ！'], nextIdx(pg, 'pop')), pg.top(t, 1.0), g.color || '#e8756a');
      const c = pg.C(t), b = c.body, bs = pg.base(c);
      if (g.into && pg.C(g.into)) {
        pg.burst(t, 10, 0.8, ['#fff2a8', '#ffffff']);
        intoBox(pg, g, t);
        pg.later(120, () => { pg.hide(t); b.position.set(bs.x, bs.y, bs.z); b.rotation.z = 0; b.scale.setScalar(1); });
      } else if (type === 'fall') {
        pg.burst(t, 14, 1.0);
        pg.tween(0.4, (k) => b.scale.setScalar(1 - k), () => { pg.hide(t); b.position.set(bs.x, bs.y, bs.z); b.rotation.z = 0; b.scale.setScalar(1); });
      } else {
        pg.burst(t, 14, 1.0);
        pg.later(250, () => { b.rotation.z = 0; POP_STYLE.rise.go(pg, t); });
      }
      if (g.count) setCount(g.count, pg.gs.caught);
      const times = popTimes(g);
      pg.progress(Math.min(pg.gs.caught, times), times);
      if (pg.gs.caught >= times) {
        pg.gs.finishing = true;
        // everyone comes out to celebrate (not the ones that went into a box)
        pg.later(900, () => { if (!g.into) g.targets.forEach((x, i) => pg.C(x) && pg.later(i * 120, () => (type === 'fall' ? POP_STYLE.rise : popStyle(g)).come(pg, x, type === 'fall' ? 0 : liftOf(pg, g, x)))); goalDone(pg, g); });
      }
      return true;
    },
  };
}

// ---------- さがす: hiding, coming out ----------
const findKey = (it) => it.item || it.spot;
// does it come out in front (it stands on the ground: 人・ねこ) or peek out where it is (up in a tree, flying, glowing)?
function comeOutMode(pg, it, spotId, feetY) {
  if (it.comeOut === 'front' || it.comeOut === 'here') return it.comeOut;
  const c = pg.C(it.item), s = pg.C(spotId);
  if (!c || !s || c.m.glow || ['fly', 'float'].includes(c.m.idle) || (c.m.pivot && c.m.pivot !== 'bottom')) return 'here';
  if ((s.m.pivot && s.m.pivot !== 'bottom') || s.m.flat || s.pvy < 600) return 'here';   // (a cloud in the sky, a hanging thing)
  return (feetY ?? c.pvy) >= s.pvy - 60 ? 'front' : 'here';
}
// hide at a place: "front" ones stand (hidden) just behind the spot, "here" ones go on the spot (behind it)
function hideAt(pg, it, pl) {
  const s = pg.C(pl.spot), c = pg.C(it.item); if (!s || !c) return;
  const [x, y] = pl.at || [s.pvx, s.pvy];
  if (comeOutMode(pg, it, pl.spot, y) === 'front') pg.placePiece(it.item, null, [x, Math.min(y, s.pvy - 14)]);
  else pg.placePiece(it.item, pl.spot, [x, y], { behind: true });
  pg.hide(it.item);
  const flip = (id) => { const k = pg.C(id); k.flipX = pl.flip ? -1 : 1; k.still.scale.x = k.flipX * Math.abs(k.still.scale.x); };
  flip(it.item);
  // the clue: a little of it shows at the edge of the place ("peek": where its bottom is, page pixels) — it is put
  // behind the place's picture, so only the part out of the picture is seen (やたいの はしから あたまが ちらっと)
  if (it.clue && pg.C(it.clue)) {
    pg.placePiece(it.clue, pl.spot, pl.peek || [x, y], { behind: true }); pg.hide(it.clue); flip(it.clue);
  }
}
// found: it comes out ("front": from behind the spot, out at its side, and stands a little in front of it)
function comeOut(pg, it, spotId) {
  const c = pg.C(it.item), s = pg.C(spotId);
  if (comeOutMode(pg, it, spotId, c.pvy) === 'here' || !s) {
    pg.rise(it.item, -c.h, 1.1); pg.later(550, () => pg.burst(it.item, 20, 1.2));
    return;
  }
  if (c.m.parent) pg.placePiece(it.item, null, [c.pvx, Math.min(c.pvy, s.pvy - 14)]);   // (a piece drawn behind the spot)
  const W = c.m.w, x0 = c.pvx, y0 = c.pvy, sx0 = s.m.x, sx1 = s.m.x + s.m.w;
  const sideX = (k) => (k < 0 ? sx0 - W / 2 - 8 : sx1 + W / 2 + 8);
  let k = x0 - sx0 < sx1 - x0 ? -1 : 1;
  if (sideX(k) - W / 2 < 10 || sideX(k) + W / 2 > 1590) k = -k;
  const xs = Math.max(W / 2 + 10, Math.min(1590 - W / 2, sideX(k)));
  const yf = Math.min(940, s.pvy + 34), xf = xs - k * W * 0.35;   // a little in front of the spot, near its side
  const pts = [[x0, y0], [xs, y0], [xs, yf], [xf, yf]].map(([x, y]) => new THREE.Vector3(x / 1600 - 0.5, 0.375 - y / 1600, c.pivot.position.z));
  const seg = pts.slice(1).map((p, i) => p.distanceTo(pts[i])), total = seg.reduce((a, b) => a + b, 0) || 1e-6;
  const b = c.body, bs = pg.base(c), dur = 1.3;
  pg.show(it.item);
  pg.tween(dur, (t) => {
    let d = easeInOut(t) * total, i = 0;
    while (i < seg.length - 1 && d > seg[i]) { d -= seg[i]; i++; }
    c.pivot.position.lerpVectors(pts[i], pts[i + 1], seg[i] ? Math.min(1, d / seg[i]) : 1);
    b.position.y = bs.y + Math.abs(Math.sin(t * Math.PI * 4)) * 0.014;   // とことこ
  }, () => {
    b.position.y = bs.y; c.pvx = xf; c.pvy = yf;
    if (c.shadow) c.shadow.position.set(c.pivot.position.x, c.pivot.position.y, 0.0008);
    pg.hop(it.item, 0.04); pg.burst(it.item, 18, 1.1);
  });
}
// not found for a while: it calls out from where it hides (the hint, or the spot), and the spot shakes a little
function callOut(pg, it) {
  const pl = pg.gs.place[findKey(it)], spot = pl ? pl.spot : it.spot;
  const from = it.clue && pg.C(it.clue) && pg.C(it.clue).body.visible ? it.clue : spot;
  const call = it.call || {};
  if (call.say) pg.say(from, call.say, `call_${findKey(it)}`, call.who || it.item || spot);
  if (call.sound) pg.sfx(call.sound);
  pg.later(300, () => { pg.wobble(spot, 0.03, 0.7); if (it.clue && pg.C(it.clue) && pg.C(it.clue).body.visible) pg.hop(it.clue, 0.03); });
}

// ---------- えらぶ（クイズ）: one question, or "questions" one after another ----------
const quizOf = (g) => (g.questions && g.questions.length ? g.questions.map((q) => ({ ...g, ...q, questions: undefined })) : [g]);
const answersOf = (q) => (q.answer === undefined || q.answer === null || q.answer === '' ? null : [].concat(q.answer));
const quizTotal = (g) => quizOf(g).reduce((n, q) => n + (answersOf(q) ? answersOf(q).length : 1), 0);

// ---------- the games ----------
// each: init(pg, g), tap(pg, g, id, hit) → true when the game used the touch, and optionally
// update(pg, g, dt), play(pg, g) (story time is over), grab / rub (finger moving over a piece)
export const GOALS = {
  // さがす: "items": [{ "spot": the piece to touch, "item": the hidden piece that comes out, … }] — all found → cleared
  //   "area": [x1, y1, x2, y2] — only this part of the spot finds it (page pixels: 屋台の のれん・台の下 …)
  //   "places": [{ "spot", "area", "at": [x, y], "peek": [x, y], "flip": true }] — it hides at one of these places,
  //       another one each time the page is played ("at": where its feet are while it hides, behind the spot)
  //   "clue": a small hidden picture (ちらっと 見える 手がかり) shown at the place's "peek" — touching it finds it too
  //   "call": { "say": "いちろう〜", "after": 10 } — not found for a while (or after 3 misses): it calls out, its place shakes
  //   "comeOut": "front" — comes out from behind the spot and stands on the ground a little in front of it (人・ねこ);
  //              "here" — peeks out where it is (とりが 木に・星が 雲に). Not written: "front" when it stands on the ground
  //              (its feet about where the spot stands), "here" when it is up in the spot, flies or glows
  //   goal "misses": [{ "spot", "area", "react" }] — something else is there (ヨーヨーが ぽよーん …);
  //   goal "miss": what a spot with nothing there does (default: it shakes, "いないみたい")
  find: {
    init(pg, g) {
      pg.gs.found = {}; pg.gs.place = {}; pg.gs.callAt = {}; pg.gs.misses = 0;
      for (const it of g.items) {
        if (it.item && pg.C(it.item)) pg.hide(it.item);
        if (it.clue && pg.C(it.clue)) pg.hide(it.clue);
        if (it.places && it.places.length && it.item && pg.C(it.item)) {
          const pl = it.places[Math.floor(Math.random() * it.places.length)];
          pg.gs.place[findKey(it)] = pl;
          hideAt(pg, it, pl);
        }
      }
    },
    play(pg, g) {
      for (const it of g.items) {
        const k = findKey(it);
        if (it.clue && pg.C(it.clue) && !pg.gs.found[k]) { pg.show(it.clue); pg.gs.clueT = pg.time + 2; }
        if (it.call) pg.gs.callAt[k] = pg.time + (it.call.after ?? 10);
      }
    },
    update(pg, g) {
      if (pg.gs.done || !pg.playing || !pg.open) return;
      for (const it of g.items) {
        const k = findKey(it);
        if (pg.gs.found[k]) continue;
        // the clue picture moves a little now and then, so it can be noticed
        if (it.clue && pg.C(it.clue) && pg.C(it.clue).body.visible && pg.time > (pg.gs.clueT || 0)) { pg.gs.clueT = pg.time + 3.5 + Math.random() * 2; pg.wobble(it.clue, 0.06, 0.6); }
        if (it.call && pg.gs.callAt[k] !== undefined && (pg.time > pg.gs.callAt[k] || pg.gs.misses >= 3)) {
          pg.gs.misses = 0; pg.gs.callAt[k] = pg.time + (it.call.every ?? it.call.after ?? 10);
          callOut(pg, it);
        }
      }
    },
    tap(pg, g, id, hit) {
      const at = hit && hit.at;
      const inArea = (a) => !a || !at || (at[0] >= a[0] && at[0] <= a[2] && at[1] >= a[1] && at[1] <= a[3]);
      const it = g.items.find((x) => {
        const k = findKey(x); if (pg.gs.found[k]) return false;
        if (x.clue && id === x.clue) return true;
        const pl = pg.gs.place[k];
        return pl ? id === pl.spot && inArea(pl.area) : id === x.spot && inArea(x.area);
      });
      if (!it) {
        if (pg.gs.done) return false;
        if (g.items.some((x) => x.item === id || x.clue === id)) return false;   // a found one: its own touch reaction
        const ms = (g.misses || []).find((m) => m.spot === id && inArea(m.area));
        if (ms) { pg.gs.misses++; progressed(pg); react(pg, id, ms.react || {}, hit, { free: true }); return true; }
        // a place to look, with nothing (left) there
        const looking = g.items.some((x) => !pg.gs.found[findKey(x)] && (x.spot === id || (x.places || []).some((p) => p.spot === id)));
        if (!looking) return false;
        pg.gs.misses++; progressed(pg);
        if (g.miss) react(pg, id, g.miss, hit, { free: true });
        else { pg.wobble(id, 0.035, 0.6); pg.sfx('po'); pg.ono(g.missWord || 'いないみたい', hit && hit.point ? hit.point.clone().add(pg.up.clone().multiplyScalar(0.02)) : id, '#7a5aa0'); }
        return true;
      }
      const key = findKey(it), pl = pg.gs.place[key], spot = pl ? pl.spot : it.spot;
      pg.gs.found[key] = true; progressed(pg); pg.gs.misses = 0;
      pg.gs.foundIds = { ...(pg.gs.foundIds || {}), [it.item || it.spot]: true };   // for "if": { "found": … }
      if (it.clue && pg.C(it.clue)) { pg.burst(it.clue, 10, 0.7); pg.hide(it.clue); }
      if (it.spotMove && moveOf(pg, it.spotMove)) moveOf(pg, it.spotMove)(pg, spot);
      else pg.wobble(spot, 0.06, 0.9);
      if (it.item && pg.C(it.item)) pg.later(250, () => { comeOut(pg, it, spot); pg.sfx(it.sound || 'pon'); });
      if (it.swap) pg.spin(spot, 'y', 1, 1.2, () => pg.swap(spot, altKey(pg, spot, it.swap)));
      pg.sfx('kirarin');
      if (it.word !== false) pg.ono(it.word || 'みつけた！', pg.top(spot, 1.1), it.color || '#e8b21f');
      const sayer = it.who || it.item || spot;
      const by = it.who && pg.C(it.who) ? it.who : (it.item || spot);   // the bubble comes from the one who speaks
      if (it.say) pg.later(it.item ? 1300 : 800, () => pg.say(by, it.say, by, sayer));
      if (it.get) pg.later(1400, () => pg.getItem(it.get));   // もちもの
      if (it.react) react(pg, spot, it.react, null, { free: true }); // anything else (an effect, a mark, a light …)
      const n = Object.keys(pg.gs.found).length;
      pg.progress(n, g.items.length);
      if (g.count) setCount(g.count, n);
      pg.later(400, () => pg.sfx('found'));
      if (n === g.items.length) pg.later(it.item ? 2200 : 1500, () => goalDone(pg, g));
      return true;
    },
  },
  gather: {
    init(pg) { pg.gs.ready = {}; },
    update(pg, g) {
      if (pg.gs.done || pg.gs.finishing) return;
      const W = param(g, 'seconds');
      for (const [id, t] of Object.entries(pg.gs.ready)) {
        const frac = 1 - (pg.time - t) / W;
        if (frac > 0) { pg.setGauge(`g_${id}`, frac, frac < 0.3); continue; }
        delete pg.gs.ready[id]; pg.removeGauge(`g_${id}`);
        const r = g.react && g.react[id];
        if (r && r.swap) pg.swap(id, pg.C(id).m.tex[0]);
        pg.sfx('undo');
        const u = g.undo && g.undo[id];
        if (u) react(pg, id, noSwap(u), null, { free: true });
        else pg.ono(g.undoWord || 'あれれ？', id, '#7a5aa0');
        pg.progress(Object.keys(pg.gs.ready).length, g.targets.length);
        if (!pg.gs.told) { pg.gs.told = true; pg.toast(`じかんぎれ！ ${W}びょうの うちに ぜんぶ タッチしてね`, 3200); }
      }
    },
    tap(pg, g, id) {
      if (!g.targets.includes(id) || pg.gs.done || pg.gs.finishing) return false;
      const fresh = !pg.gs.ready[id];
      pg.gs.ready[id] = pg.time;
      if (fresh) {
        progressed(pg);
        pg.gauge(`g_${id}`, 'ring', id, g.readyWord || 'OK', '#5fc46a');
        const r = g.react && g.react[id];
        if (r && r.swap) pg.swap(id, altKey(pg, id, r.swap));
        if (r) react(pg, id, noSwap(r), null, { free: true });
        else { pg.hop(id, 0.05); if (isCast(id)) pg.sfx('meow', id); else pg.sfx('pon'); }
      } else {
        const a = g.again && g.again[id];
        if (a) { react(pg, id, noSwap(a), null, { free: true }); if (!a.sound) pg.sfx('ready'); }
        else { pg.wobble(id, 0.04, 0.6); pg.sfx('ready'); }
      }
      pg.setGauge(`g_${id}`, 1);
      const n = Object.keys(pg.gs.ready).length;
      pg.progress(n, g.targets.length);
      if (n === g.targets.length) {
        pg.gs.finishing = true;
        pg.later(600, () => { g.targets.forEach((t) => pg.removeGauge(`g_${t}`)); goalDone(pg, g); });
      }
      return true;
    },
  },
  // なんども タッチ: "target" again and again until the power bar is full.
  //   "team": ["ma", "hi", …] — みんなで: everyone in the team must be touched first (each keeps going for "seconds",
  //   like gather); only then does the target move. Touching the target keeps the team going.
  //   per team member: "react" (first touch), "again", "undo" (got tired), "win" (when the target moves)
  mash: {
    init(pg) { pg.gs.power = 0; pg.gs.ready = {}; },
    update(pg, g, dt) {
      if (pg.gs.done || pg.gs.moving) return;
      if (g.team) {
        const W = param(g, 'seconds');
        for (const [id, t] of Object.entries(pg.gs.ready)) {
          const frac = 1 - (pg.time - t) / W;
          if (frac > 0) { pg.setGauge(`m_${id}`, frac, frac < 0.3); continue; }
          // got tired: this one stops, and the power is lost
          delete pg.gs.ready[id]; pg.removeGauge(`m_${id}`);
          const r = g.react && g.react[id];
          if (r && r.swap) pg.swap(id, pg.C(id).m.tex[0]);
          pg.sfx('undo');
          const u = g.undo && g.undo[id];
          if (u) react(pg, id, noSwap(u), null, { free: true }); else pg.ono('ふぅ…', id, '#7a5aa0');
          if (pg.labels.gauges.mash) { pg.gs.power = 0; pg.removeGauge('mash'); }
          pg.progress(Object.keys(pg.gs.ready).length, g.team.length);
          if (!pg.gs.toldTired) { pg.gs.toldTired = true; pg.toast('つかれちゃった！ もういちど みんなを タッチ', 3000); }
        }
      }
      if (!pg.gs.power) return;
      if (pg.time - (pg.gs.lastTap || 0) < 0.8) return; // only drains when you stop tapping
      pg.gs.power = Math.max(0, pg.gs.power - (g.decay ?? 0.04) * dt);
      pg.setGauge('mash', pg.gs.power);
    },
    tap(pg, g, id) {
      if (pg.gs.done || pg.gs.moving) return g.team && g.team.includes(id) && !pg.gs.done ? true : (id === g.target && !pg.gs.done);
      // みんなで: a team member joins in
      if (g.team && g.team.includes(id)) {
        const fresh = !pg.gs.ready[id];
        pg.gs.ready[id] = pg.time; progressed(pg);
        if (fresh) {
          pg.gauge(`m_${id}`, 'ring', id, g.readyWord || 'OK', '#ff8fb1');
          const r = g.react && g.react[id];
          if (r && r.swap) pg.swap(id, altKey(pg, id, r.swap));
          if (r) react(pg, id, noSwap(r), null, { free: true }); else { pg.hop(id, 0.04); pg.sfx(isCast(id) ? 'meow' : 'pon', id); }
        } else {
          const a = g.again && g.again[id];
          if (a) react(pg, id, noSwap(a), null, { free: true }); else { pg.wobble(id, 0.03, 0.6); pg.sfx('ready'); }
        }
        pg.setGauge(`m_${id}`, 1);
        const n = Object.keys(pg.gs.ready).length;
        pg.progress(n, g.team.length);
        if (n === g.team.length && !pg.labels.gauges.mash) {
          pg.gauge('mash', 'bar', g.target, g.gauge || 'ちから', '#ff5a4a', 1.08); pg.setGauge('mash', pg.gs.power);
          pg.toast('いまだ！ なんども タッチ！', 2600); pg.sfx('ready');
        }
        return true;
      }
      if (id !== g.target) return false;
      // みんなで: not everyone is pushing yet → it does not move
      if (g.team && Object.keys(pg.gs.ready).length < g.team.length) {
        pg.shake(g.target, 0.006, 0.7); pg.sfx('gugu'); pg.onoAround(g.stuckWord || 'びくとも しない', g.target, '#7a5aa0');
        if (!pg.gs.toldTeam) { pg.gs.toldTeam = true; pg.toast('まずは みんなを タッチ！', 2600); }
        return true;
      }
      if (g.team) for (const t of g.team) { pg.gs.ready[t] = pg.time; pg.wobble(t, 0.025, 0.3); } // cheering keeps everyone going
      if (!pg.labels.gauges.mash) pg.gauge('mash', 'bar', g.target, g.gauge || 'ちから', '#ff5a4a', 1.08);
      pg.gs.lastTap = pg.time; progressed(pg);
      pg.gs.power = Math.min(1, pg.gs.power + 1 / param(g, 'times') + 1e-6);
      pg.setGauge('mash', pg.gs.power);
      // each touch: the target shakes, or does "tapMove" (a kit move or this page's own move)
      if (g.tapMove && moveOf(pg, g.tapMove)) moveOf(pg, g.tapMove)(pg, g.target, null, g); else pg.shake(g.target, 0.006, 0.3);
      pg.sfx(g.sound || 'gu');
      pg.onoAround(pick(g.word || ['グッ', 'グイッ'], nextIdx(pg, 'mash')), g.target, g.color || '#e8756a');
      if (pg.gs.power >= 1) {
        pg.gs.moving = true;
        pg.removeGauge('mash');
        (g.team || []).forEach((t, i) => {
          pg.removeGauge(`m_${t}`);
          const w = g.win && g.win[t];
          if (w) pg.later(250 + i * 90, () => react(pg, t, w, null, { free: true }));
        });
        const away = g.doneMove || 'rollAway';
        const c = pg.C(g.target), b = c.body, hh = c.h / 2;
        if (away === 'rollAway') { pg.sfx('gorogoro'); pg.tween(1.4, (t) => { const k = 1 - Math.pow(1 - t, 2), a = -Math.PI * 2 * k; b.rotation.z = a; b.position.x = 0.2 * k + hh * Math.sin(a); b.position.y = hh * (1 - Math.cos(a)); }); }
        else if (away === 'flyAway') { pg.sfx('boing'); pg.tween(1.2, (t) => { b.position.y = t * t * 0.5; b.rotation.z = t * 2; }, () => pg.hide(g.target)); }
        else if (away === 'pop') { pg.sfx('pon'); pg.burst(g.target, 30, 1.4); pg.hide(g.target); }
        else if (away !== 'none' && moveOf(pg, away)) moveOf(pg, away)(pg, g.target, null, g);   // a move of the kit or of this page
        pg.later(g.team && g.win ? 2400 : 1200, () => goalDone(pg, g));   // (a team falls over and gets up first)
      }
      return true;
    },
  },
  // じゅんばんに タッチ: "targets" in order; a wrong one wobbles (with "strict", it starts again)
  order: {
    init(pg) { pg.gs.next = 0; },
    tap(pg, g, id) {
      const i = g.targets.indexOf(id);
      if (i < 0 || pg.gs.done) return false;
      if (i < pg.gs.next) return false; // already done → its normal touch reaction
      if (i === pg.gs.next) {
        pg.gs.next++; progressed(pg);
        const r = g.react && g.react[id];
        if (r) react(pg, id, r, null, { free: true }); else { pg.hop(id, 0.05); pg.sfx('pon'); }
        pg.ono(pick(g.words || [String(i + 1)], i), pg.top(id, 1.05), g.color || '#e8b21f');
        pg.gauge(`o_${id}`, 'ring', id, String(i + 1), '#5fc46a'); pg.setGauge(`o_${id}`, 1);
        pg.progress(pg.gs.next, g.targets.length);
        if (pg.gs.next === g.targets.length) pg.later(900, () => { g.targets.forEach((t) => pg.removeGauge(`o_${t}`)); goalDone(pg, g); });
      } else {
        pg.wobble(id, 0.06, 0.8); pg.sfx('undo'); pg.ono(g.wrongWord || 'ちがうよ', id, '#7a5aa0');
        if (param(g, 'strict') && pg.gs.next > 0) {
          g.targets.forEach((t) => pg.removeGauge(`o_${t}`));
          pg.gs.next = 0; pg.progress(0, g.targets.length);
          pg.toast(g.again || 'さいしょから もういちど', 2200);
        }
      }
      return true;
    },
  },
  // えらぶ（クイズ）: "question", "options" (pieces), "answer"
  //   no "answer": any one is right (えらぶだけ). "remember": "gift" keeps what was chosen for later pages ("{gift}" in texts)
  // えらぶ（クイズ）: "question", "options", "answer" — or "answer": [ … ] (several are right: find them all),
  //   or "questions": [{ "question", "answer", "options", "right", "wrong" }, …] asked one after another (all right → cleared).
  //   No "answer": whatever is chosen is the choice ("remember": what was chosen, for other pages)
  choose: {
    init(pg) { pg.gs.q = 0; pg.gs.got = {}; pg.gs.right = 0; },
    play(pg, g) { pg.later(500, () => ask(pg, quizOf(g)[pg.gs.q] || g)); },
    tap(pg, g, id) {
      const Q = quizOf(g), q = Q[pg.gs.q];
      if (!q || pg.gs.done || !(q.options || []).includes(id)) return false;
      if (pg.gs.next) return true;   // (the next question is coming)
      const ans = answersOf(q);
      if (!ans || ans.includes(id)) {
        if (ans && pg.gs.got[id]) { pg.hop(id, 0.04, 0.6); pg.ono('もう みつけたよ', id, '#7a5aa0'); return true; }
        pg.gs.got[id] = true; pg.gs.right++; pg.gs.chosen = id; progressed(pg);
        if (!ans && q.remember) remember(q.remember, id, (q.names && q.names[id]) || itemOf(id).name);
        const r = (q.react && q.react[id]) || q.right;   // "react": { "<option>": { … } } for each one, or "right" for any
        if (r) react(pg, id, r, null, { free: true }); else { pg.hop(id, 0.08, 0.75); pg.sfx('kirarin'); }
        if (!(r && r.word)) pg.ono(q.rightWord || (ans ? 'せいかい！' : 'これに きめた！'), pg.top(id, 1.1), '#e8b21f'); pg.burst(id, 20, 1.2);
        pg.progress(pg.gs.right, quizTotal(g));
        const left = ans ? ans.filter((a) => !pg.gs.got[a]).length : 0;
        if (left > 0) { pg.later(700, () => pg.toast(`あと ${left}つ！`, 1800)); return true; }
        if (pg.gs.q + 1 < Q.length) {   // the next question
          pg.gs.next = true;
          pg.later(1900, () => { pg.gs.q++; pg.gs.got = {}; pg.gs.next = false; pg.toast(`${pg.gs.q + 1}もんめ`, 1400); pg.later(300, () => ask(pg, Q[pg.gs.q])); });
        } else pg.later(900, () => goalDone(pg, g));
      } else {
        const w = q.wrong && q.wrong[id];
        if (w) react(pg, id, w, null, { free: true });
        else { pg.wobble(id, 0.06, 0.8); pg.sfx('undo'); pg.ono(q.wrongWord || 'ちがうみたい', id, '#7a5aa0'); }
      }
      return true;
    },
  },
  // でてきたら タッチ: "targets" (hidden pieces) come out one by one and go back; touch them while they are out.
  //   "style": "rise" (下から ぴょこっ: もぐら) / "swim" (よこから 泳いで来て もぐる: 金魚) / "fly" (ふわっと 飛んで来て 光る: ほたる)
  //   "behind": the front pieces they hide behind (穴・水そうの ふち・草) — touching those also catches one nearby
  //   "into": a piece the caught ones go into and stay (金魚ばち・かご・びん)
  //   "tool": 道具と手 (tool.js);  "count": "fish" — the number caught, for other pages ({fish}, "if": { "fish": 3 })
  pop: popGame('pop'),
  // おちてくる ものを キャッチ: "targets" fall from the sky; touch them before they reach the ground (same options as pop)
  fall: popGame('fall'),
  // そだてる: tap "target" "times" times for each of the "stages" (pictures <target>@<stage>)
  grow: {
    init(pg) { pg.gs.stage = 0; pg.gs.n = 0; },
    tap(pg, g, id) {
      if (id !== g.target || pg.gs.done) return false;
      const times = param(g, 'times', 'growTimes'), stages = g.stages || [];
      if (!pg.labels.gauges.grow) pg.gauge('grow', 'bar', g.target, g.gauge || 'そだつ', '#5fc46a', 1.08);
      pg.gs.n++; progressed(pg);
      pg.pulse(id, 1.08, 0.6); pg.sfx(g.sound || 'pon');
      pg.setGauge('grow', pg.gs.n / times);
      if (pg.gs.n < times) return true;
      pg.gs.n = 0; const s = stages[pg.gs.stage++];
      pg.spin(id, 'y', 1, 1.0, () => pg.swap(id, altKey(pg, id, s)));
      pg.sfx('kirarin'); pg.later(350, () => pg.burst(id, 18, 1.1));
      if (g.words) pg.onoAround(pick(g.words, pg.gs.stage - 1), id, g.color || '#5fc46a');
      pg.progress(pg.gs.stage, stages.length); pg.setGauge('grow', 0);
      if (pg.gs.stage >= stages.length) { pg.removeGauge('grow'); pg.later(1000, () => goalDone(pg, g)); }
      return true;
    },
  },
  // きせかえ: each tap shows the next look ("looks": { id: [alt, alt] }); match "answer" to clear
  dressup: {
    init(pg) { pg.gs.look = {}; pg.gs.seen = {}; },
    tap(pg, g, id) {
      const looks = g.looks[id];
      if (!looks || pg.gs.done) return false;
      const list = ['', ...looks], i = ((pg.gs.look[id] || 0) + 1) % list.length;
      pg.gs.look[id] = i;
      if (g.keep) keepLook(id, list[i]);   // the same look on the other pages
      (pg.gs.seen[id] = pg.gs.seen[id] || new Set()).add(i);
      pg.spin(id, 'y', 1, 0.8, () => pg.swap(id, i === 0 ? pg.C(id).m.tex[0] : altKey(pg, id, list[i])));
      pg.sfx(g.sound || 'pon');
      const ids = Object.keys(g.answer || g.looks);
      const ok = g.answer ? ids.filter((t) => lookMatches(pg, g, t)).length : ids.filter((t) => (pg.gs.seen[t] || new Set()).size >= g.looks[t].length).length;
      pg.progress(ok, ids.length);
      if (ok === ids.length) { progressed(pg); pg.later(800, () => goalDone(pg, g)); }
      return true;
    },
  },
  // こする・はらう: rub "targets" with a finger (taps help a little too) until they are clean
  rub: {
    init(pg) { pg.gs.rubbed = {}; pg.gs.cleared = {}; },
    grab(pg, g, id) { return g.targets.includes(id) && !pg.gs.done && !pg.gs.cleared[id]; },
    rub(pg, g, id, hit, px) { if (g.targets.includes(id) && !pg.gs.done) { progressed(pg); rubAdd(pg, g, id, px / param(g, 'amount', 'rub'), hit); } },
    tap(pg, g, id, hit) {
      if (!g.targets.includes(id) || pg.gs.done) return false;
      if (pg.gs.cleared[id]) return false;
      progressed(pg); rubAdd(pg, g, id, 0.15, hit);
      return true;
    },
  },
};

Object.assign(GOALS, MORE_GAMES);

// ---------- each frame: the game, then the hint ----------
export function goalUpdate(pg, g, dt) {
  const G = GOALS[g.type];
  if (G.update) G.update(pg, g, dt);
  const wait = param(g, 'hintAfter');
  if (!wait || pg.gs.done || !pg.playing || !pg.open) return;
  if (pg.gs.lastMove === undefined) pg.gs.lastMove = pg.time;
  const since = Math.max(pg.gs.lastMove, pg.gs.lastHint ?? -Infinity);
  if (pg.time - since > wait) { pg.gs.lastHint = pg.time; showHint(pg, g); }
}
