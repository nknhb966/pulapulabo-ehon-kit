// 1ページ「やねの うえ」：主人公（ミミ・おつきさま）と、みつける ともだちの動き。
// さわったときの反応や遊びは page.json に書いてあり、ここの動きを "move" で名前で使います。
// どの動きも「ためて → 大きく動いて → 気持ちが見える」ひと続き。何秒かかるかを返します（その間は もう一度さわっても反応しない）。
// はやさは「少し ゆっくり〜ふつう」（小さな子が 目で追える はやさ。1回まわるのに 1秒くらい）。

// しゃがむ（ためる）：たてに ちぢんで もどる
const squash = (pg, id, k = 0.12, dur = 0.4) => {
  const b = pg.C(id).body;
  pg.tween(dur, (t) => { const u = Math.sin(Math.PI * t); b.scale.set(1 + u * k * 0.5, 1 - u * k, 1); }, () => b.scale.set(1, 1, 1));
};

export default {
  moves: {
    // ミミ「こんばんは」：ちょっと しゃがんで → ぴょん → ゆっくり ぺこり（2.1 秒）
    catHello(pg, id) {
      const b = pg.C(id).body;
      squash(pg, id);
      pg.later(350, () => pg.hop(id, 0.05, 0.7));
      pg.later(1100, () => pg.tween(1.0, (t) => { b.rotation.x = Math.sin(Math.PI * t) * 0.45; }, () => { b.rotation.x = 0; }));
      return 2.1;
    },
    // ミミ「にゃーん♪」：ためて → 大きく とんで くるんと回る → ぴょんぴょん（2.3 秒）
    catJoy(pg, id) {
      squash(pg, id, 0.16);
      pg.later(350, () => { pg.hop(id, 0.09, 0.9); pg.spin(id, 'y', 1, 1.1); });
      pg.later(1500, () => pg.hop(id, 0.03, 0.4, 2));
      return 2.3;
    },
    // ミミ「みんな どこ？」：左を見て、右を見て（きょろきょろ）、首を かしげる（2.0 秒）
    catLook(pg, id) {
      const b = pg.C(id).body;
      pg.tween(2.0, (t) => {
        b.rotation.y = t < 0.35 ? Math.sin(t / 0.35 * Math.PI) * 0.6 : t < 0.7 ? -Math.sin((t - 0.35) / 0.35 * Math.PI) * 0.6 : 0;
        b.rotation.z = t > 0.7 ? Math.sin((t - 0.7) / 0.3 * Math.PI) * 0.15 : 0;
      }, () => { b.rotation.y = 0; b.rotation.z = 0; });
      return 2.0;
    },
    // ミミ（クリアのあと）：右へ ぴょん、左へ ぴょん、くるんと回って 大ジャンプ（3.2 秒）
    catDance(pg, id) {
      const c = pg.C(id), b = c.body, bs = pg.base(c);
      const step = (dx, at) => pg.later(at, () => { const x0 = b.position.x; pg.tween(0.5, (t) => { b.position.x = x0 + (bs.x + dx - x0) * t; }); pg.hop(id, 0.04, 0.5); });
      step(0.02, 0); step(-0.02, 550); step(0, 1100);
      pg.later(1600, () => pg.spin(id, 'y', 1, 0.9));
      pg.later(2400, () => pg.hop(id, 0.09, 0.8));
      return 3.2;
    },
    // おつきさま：ゆったり ゆれて、ふくらむように かがやく（2.6 秒）
    moonSmile(pg, id) {
      const b = pg.C(id).body;
      pg.tween(2.6, (t) => {
        b.rotation.z = Math.sin(t * Math.PI * 2) * 0.1 * (1 - t * 0.4);
        const s = 1 + Math.sin(Math.PI * t) * 0.08; b.scale.set(s, s, 1);
      }, () => { b.rotation.z = 0; b.scale.set(1, 1, 1); });
      pg.later(800, () => pg.burst(id, 10, 0.6, ['#fff6c9', '#ffffff']));
      return 2.6;
    },
    // うさぎ（みつかった）：ぴょーん、ぴょん、ぴょっ（だんだん小さく。1.75 秒）
    rabbitHop3(pg, id) {
      pg.hop(id, 0.08, 0.7);
      pg.later(700, () => pg.hop(id, 0.05, 0.55));
      pg.later(1250, () => pg.hop(id, 0.025, 0.45));
      return 1.75;
    },
    // ふくろう（みつかった）：首を ゆっくり くるっ くるっと まわして、ぴょん（2.2 秒）
    owlTurn(pg, id) {
      const b = pg.C(id).body;
      pg.tween(1.6, (t) => { b.rotation.y = Math.sin(t * Math.PI * 2) * 0.9; }, () => { b.rotation.y = 0; });
      pg.later(1650, () => pg.hop(id, 0.04, 0.55));
      return 2.2;
    },
    // ほしのこ（みつかった）：くるんと 1回 ゆっくり まわって、ぽんっと ふくらむ（2.0 秒）
    starTwirl(pg, id) {
      pg.spin(id, 'z', 1, 1.4);
      pg.later(1400, () => { pg.pulse(id, 1.25, 0.6); pg.burst(id, 12, 0.8); });
      return 2.0;
    },
  },
};
