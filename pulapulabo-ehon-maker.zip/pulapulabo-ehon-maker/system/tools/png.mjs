// npm run png                    → the book's pictures as PNG, to draw your own pictures over in a drawing app (guide/09)
//                                  out/<book>_png/ and out/<book>_png.zip (the same, in one ZIP)
//   はじめに読んでね.txt   what each file is, and how to draw and put them back
//   _ガイド.png            the 5 rows for 奥行き and the story box, to lay over a drawing
//   p1/_下絵.png           the page as printed, to trace over
//   p1/_background.png, p1/cat.png, p1/cat@happy.png …   every picture, 2400 × 1800
//   cover.png, cast/…, items/…
// Put the drawn pictures back with: npm run put-png -- <folder or ZIP>
//
// npm run png -- --book <id>       another book
// npm run png -- --page p1,p3      only some pages (cover / cast / items are left out then)
// npm run png -- --width 3200      another size (4:3; the default is 2400 × 1800)
// (npm run svg makes the same set with SVG pictures, for vector apps — lib/shitae.mjs)
import { args, config, loadBook } from './lib/common.mjs';
import { makeShitae } from './lib/shitae.mjs';

const A = args();
const B = loadBook(A.book || config().book);
const only = typeof A.page === 'string' ? A.page.split(',').map((s) => s.trim()).filter(Boolean) : null;
if (only) for (const id of only) if (!B.pages.some((p) => p.id === id)) { console.error(`\n  ページ「${id}」がありません。ページ: ${B.pages.map((p) => p.id).join(', ')}\n`); process.exit(1); }
await makeShitae(B, { kind: 'png', width: A.width, only });
